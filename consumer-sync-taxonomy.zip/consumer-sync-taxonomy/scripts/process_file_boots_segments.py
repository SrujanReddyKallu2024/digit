# %%
import re
import pandas as pd

from pyspark.sql.functions import trim, lit, first

from utils.spark_session import get_spark_session
from utils.tools import inner_join
from utils.records import check_record_retention

import logging
# %%
def process_data(spark=None):
    if spark is None:
        spark = get_spark_session("Process Interim Boots")

    logging.getLogger(__name__)

    input_path = r"hdfs:///user/unity/match2/digitaltaxonomy/input/F35_*_P60_consview.csv"
    boots_segments_lookup_path = r"file:///data/digitaltaxonomy/base/Boots_Model_Segments_lookup.xlsx"
    df_pre = spark.read.csv(input_path, header=True, sep="|")

    mosaic = '7' #TODO: Possibly take this out

    df = df_pre.select("cb_key_db_person", "mailable_postcode", f"p_mosaic_uk_{mosaic}_shopper_type")

    boots_lookup = pd.read_excel(boots_segments_lookup_path)
    boots_lookup = boots_lookup.astype(str)
    boots_lookup = spark.createDataFrame(boots_lookup)

    boots_lookup = boots_lookup.select("Segment Code", "Official Name", "Tier")
    boots_lookup = boots_lookup.withColumn("Official Name", trim(boots_lookup["Official Name"]))

    boots_lookup = boots_lookup.withColumn("seg_y", lit("Y"))

    # Transpose lookup
    key_cols = ["Segment Code", "seg_y"]
    data_cols = ["Official Name"]
    
    for column in data_cols:
        boots_lookup = boots_lookup.withColumn(column, boots_lookup[column].cast("STRING"))
    
    stack_expr = ", ".join([f"'{column}', `{column}`" for column in data_cols])
    boots_lookup = boots_lookup.selectExpr(*[f"`{key}`" for key in key_cols], f"stack({len(data_cols)}, {stack_expr}) as (Name, Value)")
    
    # Group by official name
    boots_lookup = boots_lookup.groupBy("Segment Code").pivot("Value").agg(first("seg_y"))

    join = inner_join(df, boots_lookup, join_condition=df[f"p_mosaic_uk_{mosaic}_shopper_type"] == boots_lookup["Segment Code"])
    join = join.drop("Segment Code", f"p_mosaic_uk_{mosaic}_shopper_type", "mailable_postcode")

    new_cols = [re.sub(r"[ ,&:*-]", "_", column) for column in join.columns]
    df = join.toDF(*new_cols)

    check_record_retention(df_pre, df, 90, "Boots Segments Processing")

    logging.info(f"Processed the interim boots segments file")
    return df

if __name__ == "__main__":
    process_data()