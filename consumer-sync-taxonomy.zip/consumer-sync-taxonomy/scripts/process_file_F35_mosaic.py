# %%
from pyspark.sql.functions import col, substring

from utils.spark_session import get_spark_session
from utils.records import check_record_retention

import logging
# %%
def process_data(spark=None):
    if spark is None:
        spark = get_spark_session('Process F35 MosaicSuite')

    logging.getLogger(__name__)
    input_path = r'hdfs:///user/unity/match2/digitaltaxonomy/input/F35_MosaicSuite_*.txt'

    # Read in the F35_MosaicSuite
    df_pre = spark.read.csv(input_path, header = True, sep = '|')

    # Derive group and type cols
    df = df_pre.withColumn('p_mosaic_8_uk_group', substring(col('p_mosaic_uk8_type'), 1, 1))
    df = df.withColumn('mosaic_uk_8_type_for_matching', substring(col('p_mosaic_uk8_type'), 2, 2))

    df = df.withColumn('p_mosaic_fin_group', substring(col('p_mosaic_fin_type'), 1, 1))
    df = df.withColumn('mosaic_fin_type_for_matching', substring(col('p_mosaic_fin_type'), 2, 2))

    df = df.select('cb_key_db_person', 'p_mosaic_8_uk_group', 'mosaic_uk_8_type_for_matching', 'p_mosaic_fin_group', 'mosaic_fin_type_for_matching')

    check_record_retention(df_pre, df, 90, "F35 MosaicSuite Processing")

    logging.info(f'Processed F35 MosaicSuite')
    return df

# %%
if __name__ == '__main__':
    process_data()