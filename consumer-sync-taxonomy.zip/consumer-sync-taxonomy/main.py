# %%
import os
import json
import logging
import pandas as pd
import importlib.util
from datetime import datetime

from pyspark.sql import SparkSession
from pyspark.sql.functions import expr, monotonically_increasing_id, when, col, datediff, to_date, current_date, lit, substring, regexp_replace, trim
from pyspark.sql.types import IntegerType, StringType

from utils.dynamic_flag import dynamic_flag
from utils.tools import inner_join, left_anti_join

from pathlib import Path

script_dir = str(Path(os.path.dirname(__file__)).resolve())

# %%
# Initialise and configure logging
log_dir = f"{script_dir}/logs"
os.makedirs(log_dir, exist_ok=True)

log_filename = os.path.join(log_dir, f"log_{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}.log")

logging.basicConfig(
    filename=log_filename,
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

# %%
start_time = datetime.now()

logging.info("Process started, initating Spark session")

# Boot up Spark session
try:
    spark = (
        SparkSession.builder \
        .appName("Digital Taxonomy") \
        .getOrCreate()
    )
except Exception as e:
    logging.error(f"An error occurred: {e}")

# %%
# Read in main file
try:
    logging.info("Reading in main F35 file and performing initial processing")

    df = spark.read.csv(r"hdfs:///user/unity/match2/digitaltaxonomy/input/F35_*_P60_consview.csv", sep="|", header=True)
    df_copy = df
    df = df.withColumn("MU_RecordID", monotonically_increasing_id() + 1).withColumn("Person_Mailable_flag", lit(""))
    columns = ["MU_RecordID"] + [col for col in df.columns if col != "MU_RecordID"]

    df = df.select(columns)

    df = df.withColumn(
    "Stage",
    when(col("cb_address_mailable_flag") != "Y", "Mailable")
    .when(col("p_prospectable_flag") != "Y", "Prospectable")
    .when(col("cb_name_title").isNull() | (col("cb_name_title") == ""), "Blank title")
    .when(
        (col("p_prospectable_date_of_birth").isNotNull()) & 
        (col("p_prospectable_date_of_birth") != "") & 
        (datediff(current_date(), to_date(col("p_prospectable_date_of_birth"), 'yyyyMMdd')) < 6574), 
        "Over 18"
    )
    .when(
        (col("P_NA_CONTRIBUTOR_SOURCES").substr(1, 3) == "A04") | 
        (col("P_NA_CONTRIBUTOR_SOURCES").substr(1, 3) == "A05") | 
        (col("P_NA_CONTRIBUTOR_SOURCES").substr(1, 3) == "A30"), 
        "Unwanted Contributors"
    )
    .otherwise("")
    )

    df = df.filter(col("Stage") == "")
    dropped_cv = df.filter(col("Stage") != "")
    dropped_cv = dropped_cv.withColumn("Count", lit(None).cast(IntegerType()))

    df = df.drop("Stage")
except Exception as e:
    logging.error(f"An error occurred: {e}")

# %%
mailable_universe_config = f"{script_dir}/config/mailable_universe.json"

# Initialize an empty DataFrame for unmatching_df
unmatching_df = spark.createDataFrame([], df.schema).withColumn("Count", lit(None).cast(IntegerType()))
unmatching_df = unmatching_df.withColumn("Stage", lit(None).cast(StringType()))

# Flagging records
try:
    logging.info("Performing mailable flags")
    final_matching, final_unmatching = dynamic_flag(mailable_universe_config, df, unmatching_df, inner_join, left_anti_join) #TODO: final_unmatching now yet used anywhere, can be leveraged for reporting
except Exception as e:
    logging.error(f"An error occurred: {e}")

# %%
try:
    logging.info("Performing ad-hoc suppressions")
    ad_hoc_sups = spark.read.option("header", "true").csv(r"hdfs:////user/unity/match2/digitaltaxonomy/input/ADHOC_SUPPRESSION.csv")
    
    join_column = "cb_key_db_person"
    ad_hoc_sups = ad_hoc_sups.withColumnRenamed(join_column, f"{join_column}_1")
    
    mu_l = left_anti_join(final_matching, ad_hoc_sups, join_condition=final_matching[join_column] == ad_hoc_sups[f"{join_column}_1"])
    mailable_universe = (mu_l).drop("MU_RecordID", "cb_key_db_person_1", "A13_Sup_File", "F35_Suppressions", "LSO_Suppressions")
    mailable_universe = mailable_universe.select("cb_key_db_person").withColumn("Person_Mailable_flag", lit("Y"))
except Exception as e:
    logging.error(f"An error occurred: {e}")

# %%
try:
    logging.info("Joining suppressions back to main file")
    join_column = 'cb_key_db_person'
    mailable_universe = mailable_universe.withColumnRenamed(join_column, f"{join_column}_1")
    
    join = inner_join(df_copy, mailable_universe, join_condition=df_copy[join_column] == mailable_universe[f"{join_column}_1"])
    join = join.drop(f"{join_column}_1")
    
    left_anti_join = left_anti_join(df_copy, mailable_universe, join_condition=df_copy[join_column] == mailable_universe[f"{join_column}_1"])
    
    union = join.unionByName(left_anti_join, allowMissingColumns=True)
except Exception as e:
    logging.error(f"An error occurred: {e}")

# %%
try:
    logging.info("Reducing main file schema based on cv_vars.json")
    # Load columns from JSON file
    with open(f"{script_dir}/config/cv_vars.json", "r") as f:
        column_data = json.load(f)
    
    # Extract column list from JSON
    required_columns = column_data.get("columns", [])
    
    # Filter DataFrame to keep only valid columns
    available_columns = [col for col in required_columns if col in df.columns]
    
    # Reduce DataFrame to specified columns
    reduced_union = union.select(available_columns)
except Exception as e:
    logging.error(f"An error occurred: {e}")

# %%
try:
    logging.info("Performing additional pre-processing prior to joining additional audiences")
    reduced_union = reduced_union.withColumnRenamed('cb_address_postcode_area', 'Postcode Area')
    reduced_union = reduced_union.withColumnRenamed('cb_address_postcode_outcode', 'Postcode District')
    reduced_union = reduced_union.withColumnRenamed('cb_address_postcode_sector', 'Postcode Sector')

    reduced_union = reduced_union.withColumn('p_fss_4_group', substring(col('p_fss_4_type'), 1, 1)) #TODO: Could make these dynamic for when fss changes
    reduced_union = reduced_union.withColumn('p_fss_4_type_Two_byte', substring(col('p_fss_4_type'), 2, 2)) #TODO: Could make these dynamic for when fss changes
    
    reduced_union = reduced_union.withColumn('p_mosaic_7_uk_group', substring(col('p_mosaic_uk_7_type'), 1, 1)) #TODO: Could make these dynamic for when mosaic changes
    reduced_union = reduced_union.withColumn('mosaic_uk_7_type_for_matching', substring(col('p_mosaic_uk_7_type'), 2, 2)) #TODO: Could make these dynamic for when mosaic changes

    reduced_union = reduced_union.withColumn('Pcode_To_Match', trim(regexp_replace(reduced_union['mailable_postcode'], ' ', '')))
except Exception as e:
    logging.error(f"An error occurred: {e}")

# %%
def load_processing_scripts(spark, script_folder):
    """Dynamically loads and executes all process_* scripts, returning DataFrames."""
    processed_dfs = {}

    for filename in os.listdir(script_folder):
        if filename.startswith("process_") and filename.endswith(".py"):
            module_name = filename[:-3]
            module_path = os.path.join(script_folder, filename)

            # Load module dynamically
            spec = importlib.util.spec_from_file_location(module_name, module_path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)

            # Execute process_data if available
            if hasattr(module, "process_data"):
                processed_dfs[module_name] = module.process_data(spark)

    return processed_dfs

# %%
def main():
    with open(f"{script_dir}/config/config.json") as f:
        config = json.load(f)

    processed_dfs = load_processing_scripts(spark, f"{script_dir}/scripts")

    final_df = reduced_union

    for file_config in config["files"]:
        file_name = file_config["name"]
        main_col = file_config["join_column_main"]
        file_col = file_config["join_column_file"]

        if file_name not in processed_dfs:
            logging.warning(f"Skipping {file_name} as it was not found in processed_dfs")
            continue

        df = processed_dfs[file_name]
        # common_cols = set(final_df.columns) & set(df.columns)

        # for column_name in common_cols:
        #     df = df.withColumnRenamed(file_col, f"{file_col}_right")

        if main_col == file_col:
            df = df.withColumnRenamed(file_col, f"{file_col}_right")
            file_col = f"{file_col}_right"
            joined_df = final_df.join(df, final_df[main_col] == df[file_col], how="left")
        joined_df = final_df.join(df, final_df[main_col] == df[file_col], how="left")
        final_df = joined_df

    return final_df

if __name__ == "__main__":
    try:
        logging.info(f"Preprocessing audiences and joining to main file")
        final_df = main()
    except Exception as e:
        logging.error(f"An error occurred: {e}")

# %%
try:
    logging.info("Creating C-vars from existing columns...")

    rules = pd.read_excel(rf"{script_dir}/config/taxonomy.xlsx", dtype=str)
    existing_columns = final_df.columns

    invalid_rules = []
    c_vars = []

    for _, row in rules.iterrows():
        new_col = row["new_column"]
        source_col = row["source_column"]
        condition_type = row["condition_type"]

        c_vars.append(row["new_column"])

        # Check if the source column exists in the dataset
        source_cols = [col.strip() for col in source_col.split(",")]
        if not all(col in existing_columns for col in source_cols):
            invalid_rules.append({"new_column": new_col, "error": f" Missing source column(s) {source_col}."})
            continue

        # CASE-based conditions
        if condition_type == "CASE":
            case_expr = row["case_expression"]
            try:
                final_df = final_df.withColumn(new_col, expr(case_expr)) # Apply the CASE statement
            except Exception as e:
                invalid_rules.append({"new_column": new_col, "error": f"Invalid CASE expression: {e}"})

        # Simple condition (if condition is met, assign true_value; otherwise, false_value)
        elif condition_type == "Simple":
            condition_expr = row["condition"]
            true_value = row["true_value"]
            false_value = row["false_value"]
            false_value = '' if pd.isna(false_value) or false_value.strip() == "" else false_value.strip()

            if not condition_expr or not true_value:
                invalid_rules.append({"new_column": new_col, "error": "Missing Condition or True Value for Simple condition"})

            try:
                final_df = final_df.withColumn(new_col, expr(f"CASE WHEN {condition_expr} THEN {true_value} ELSE {false_value} END"))
            except Exception as e:
                invalid_rules.append({"new_column": new_col, "error": f"Invalid Simple condition: {e}"})

        # Direct Assignment (new column = existing column)
        elif condition_type == "Direct":
            direct_assignment = row["direct_assignment"]

            if direct_assignment not in existing_columns:
                invalid_rules.append({"new_column": new_col, "error": f"Direct assignment column '{direct_assignment}' missing"})
                continue

            if new_col not in final_df.columns:
                final_df = final_df.withColumnRenamed(direct_assignment, new_col)
            else:
                final_df = final_df.withColumn(new_col, col(direct_assignment))
except Exception as e:
    logging.error(f"An error occurred: {e}")

if invalid_rules:
    pd.DataFrame(invalid_rules).to_csv(f"{script_dir}/output/invalid_rules.csv", index=False)
    logging.warning("Some rules were invalid. Check 'invalid_rules.csv' in the output folder for details")

# %%
try:
    logging.info("Reducing main file schema based on final_vars.json & leaving all C-vars")
    # Load columns from JSON file
    with open(f"{script_dir}/config/final_vars.json", "r") as f:
        column_data = json.load(f)
    
    # Extract column list from JSON
    required_columns = column_data.get("columns", [])
    
    # Filter DataFrame to keep only valid columns
    base_columns = [col for col in required_columns if col in final_df.columns]
    final_columns = base_columns + c_vars

    # Reduce DataFrame to specified columns
    digital_taxonomy = final_df.select(final_columns)
except Exception as e:
    logging.error(f"An error occurred: {e}")

# %%
try:
    logging.info("Writing PySpark file")
    digital_taxonomy.write.option("delimiter", "|").option("header", "true").mode("overwrite").csv("hdfs:///user/unity/match2/digitaltaxonomy/interim/pyspark_output")
    logging.info("PySpark file written successfully")
except Exception as e:
    logging.error(f"An error occurred: {e}")

# %%
spark.stop()