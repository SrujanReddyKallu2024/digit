from pyspark.sql import DataFrame

import logging

logger = logging.getLogger(__name__)

def check_record_retention(df_before: DataFrame, df_after: DataFrame, min_retention_pct: float, label: str = "") -> DataFrame:
    count_before = df_before.count()
    count_after = df_after.count()

    if count_before == 0:
        logger.warning(f"{label} - Input DataFrame is empty.")
        return

    retention_pct = (count_after / count_before) * 100 if count_before else 0

    if retention_pct < min_retention_pct:
        logger.error(
            f"{label} - Retention rate below threshold: "
            f"{retention_pct:.2f}% retained "
            f"({count_after:,} out of {count_before:,})"
        )
        raise ValueError(f"Retention rate below threshold of {min_retention_pct}%")
    else:
        logger.info(
            f"{label} - Retention rate within acceptable range: "
            f"{retention_pct:.2f}% retained "
            f"({count_after:,} out of {count_before:,})"
        )