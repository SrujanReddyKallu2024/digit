from pyspark.sql import DataFrame
from collections import Counter

def join_dataframes(
    df1: DataFrame,
    df2: DataFrame,
    join_condition,
    join_type: str = "inner"
) -> DataFrame:
    """
    This function serves to join two PySpark DataFrames.

    Args:
        df1 (DataFrame): First DataFrame.
        df2 (DataFrame): Second DataFrame.
        join_condition: Join condition (e.g., df["col1"] == df2["col2"]).
        join_type (str): Type of join ("inner", "left_anti", "right_anti", etc.).

    Returns:
        DataFrame: Result of the join.
    """
    return df1.join(df2, join_condition, join_type)

def inner_join(df1: DataFrame, df2: DataFrame, join_condition) -> DataFrame:
    """
    Performs an inner join.
    """
    return join_dataframes(df1, df2, join_condition, join_type="inner")

def left_join(df1: DataFrame, df2: DataFrame, join_condition) -> DataFrame:
    """
    Performs a left join.
    """
    return join_dataframes(df1, df2, join_condition, join_type="left")

def inner_join(df1: DataFrame, df2: DataFrame, join_condition) -> DataFrame:
    """
    Performs an inner join. This mimics the J output anchor of an Alteryx join tool.
    """
    return join_dataframes(df1, df2, join_condition, join_type="inner")

def right_join(df1: DataFrame, df2: DataFrame, join_condition) -> DataFrame:
    """
    Performs a right join.
    """
    return join_dataframes(df1, df2, join_condition, join_type="right")

def left_anti_join(df1: DataFrame, df2: DataFrame, join_condition) -> DataFrame:
    """
    Performs a left anti join. This mimics the L output anchor of an Alteryx join tool.
    """
    return join_dataframes(df1, df2, join_condition, join_type="left_anti")

def right_anti_join(df1: DataFrame, df2: DataFrame, join_condition) -> DataFrame:
    """
    Performs a right anti join. This mimics the R output anchor of an Alteryx join tool.
    """
    return join_dataframes(df1, df2, join_condition, join_type="right_anti")