import os
from datetime import datetime
import subprocess
from pathlib import Path
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib
import sys
import pyspark.sql.functions as F
import logging
import logging.handlers
import fnmatch


ALLOWED_FILE_EXTENSIONS = [".csv", ".parquet", ".txt", ".gz", ".tsv"] #file extensions that can be read by this script

class LogConfig(object):
    LOGLEVEL = logging.DEBUG
    FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    LOGFILE = 'output.log'
    LOGSIZE = 10000000
    LOGLEVEL_FILE = logging.DEBUG

    # easy overwrite logfile name
    def __init__(self, altfilename='output.log'):
        self.LOGFILE = altfilename

    # generate the logging object
    def generate_logger(self, name):
        # initializing logger properties
        formatter = logging.Formatter(self.FORMAT)
        logger = logging.getLogger(name)
        logger.setLevel(logging.DEBUG)
        handler = logging.StreamHandler()
        handler.setLevel(self.LOGLEVEL)
        handler.setFormatter(formatter)
        # Add the log message handler to the logger
        file_handler = logging.handlers.RotatingFileHandler(self.LOGFILE,
                                                            maxBytes=self.LOGSIZE,
                                                            backupCount=5,
                                                            )
        file_handler.setFormatter(formatter)
        file_handler.setLevel(self.LOGLEVEL_FILE)
        logger.addHandler(file_handler)
        logger.addHandler(handler)
        return logger


def get_creation_date(input_path):
    """
    gets last modified date for a file in HDFS
    """    
    command = "hdfs dfs -stat '%y' " + input_path
    proc = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding='UTF-8')        
    last_modified_date = [i.replace("\n", "") for i in proc.stdout.readlines()][-1]
    return last_modified_date


def get_size(input_path, islocal):
    """
    gets the size of input spark files(folders)
    returns: string
    """
    if islocal=="True":    
        if os.path.isdir(input_path):               
            all_file_sizes = [os.path.getsize(os.path.join(input_path,i)) for i in os.listdir(input_path)]
            full_size = sum(all_file_sizes)    
        elif os.path.isfile(input_path):
            full_size = os.path.getsize(input_path)
        for unit in ['bytes', 'K', 'M', 'G', 'T']:
            if full_size < 1024.0:
                return f"{full_size:.2f} {unit}"
            full_size /= 1024.0
    else:        
        command = "hdfs dfs -du -s -h " + input_path
        proc = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding='UTF-8')        
        for line in proc.stdout.readlines():
            line = line.replace("\n", "")
            unit = line.split(' ')[1]
            if unit=='':
                unit = 'bytes'
            full_size = line.split(' ')[0]+' '+unit            
            return full_size



def get_valid_files(input_folder, file_pattern, islocal):
    """
    Get all valid files for reading in pyspark
    """
    if islocal=="True":
        valid_files = [
            os.path.join(input_folder, i) for i in os.listdir(input_folder) 
            if set(Path(i).suffixes).intersection(ALLOWED_FILE_EXTENSIONS)
        ] 
    else:
        files=[]
        grep_cmd = "grep " + " ".join([f"-e {val.split('.')[-1]}" for val in ALLOWED_FILE_EXTENSIONS])
        cmd = f"hdfs dfs -ls -t {input_folder} | {grep_cmd} " + "| awk '{print $8}'"
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, encoding='UTF8')
        for line in proc.stdout.readlines():
            line = line.replace("\n", "")
            if 'Picked' not in line:
                files.append(line)
        valid_files = [i for i in files if i and ("Picked" not in i)]
    if len(valid_files)!=0 and file_pattern:
        valid_files = [i for i in valid_files if fnmatch.fnmatch(os.path.basename(i), file_pattern)]
    return valid_files


def check_path_exists(file_path, islocal):
    """
    check if file exists in local or HDFS path
    """
    if sys.platform[:3] != "win" and islocal!="True":
        cmd = ["hdfs", "dfs", "-test", "-e", file_path]
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding="utf-8")
        proc.communicate()
        if proc.returncode != 0:
            return False
        else :
            return True
    else:
        import os
        if not os.path.exists(file_path):
            return False
        else:
            return True


def check_and_read_file(ctx, filepath, file_ext, delim=None):
    """
    To check for valid file extensions and read it via spark
    """
    if file_ext == "csv" or file_ext == "gz":
        if delim:
            input_df = ctx.read.csv(filepath, sep="|", header=True)
        else:
            input_df = ctx.read.csv(filepath, header=True)
        return input_df        
    elif file_ext == "parquet":
        input_df = ctx.read.parquet(filepath)
        return input_df
    elif file_ext == "txt":
        input_df = ctx.read.csv(filepath, sep="|", header=True)
        return input_df
    elif file_ext == "tsv":
        input_df = ctx.read.csv(filepath, sep="\t", header=True)
        return input_df        
    else:        
        return False


def check_dfs_equal(df1, df2):
    """
    checks if given spark dataframes are equal or not
    """    
    df1 = df1.sort(df1.columns)
    df2 = df2.sort(df2.columns)
    if df1.dtypes == df2.dtypes:
        if df1.collect() == df2.collect():
            return True
        else:
            return False
    else:
        return False
    

def get_greeting():
    """
    gets the greeting based on time of day
    """
    now_time = datetime.now()
    if (now_time.hour>=12) & (now_time.hour<17):
        return "Good afternoon,"
    elif (now_time.hour>=17):
        return "Good evening,"
    else:
        return "Good morning,"


def send_email(email_to, body, email_subject, mask):
    """
    email formatted for both stats and alerts
    """
    # email variables    
    greeting = get_greeting()
    EMAIL_FROM = 'pipeline_monitor@experian.com'    
    EMAIL_CC = ''
    SMTP_SERVER = "relay.uk.experian.local"
    msg = MIMEMultipart('alternative')
    if body==False:
        body = "No stats generated, please check logs."    
    msg_body = f"""\
        <!DOCTYPE html>
        <html>
          <head></head>
          <body>
            <p>{greeting}</p>            
            {body}
            <br>
            <p style='margin-bottom:0;'>Thanks and regards</p>
            <p style="margin : 0; padding-top:0;">Experian Match Team</p>
          </body>
        </html>
    """
    body_part = MIMEText(msg_body, 'html')
    msg['Subject'] = mask + ": " + email_subject
    msg['From'] = EMAIL_FROM
    msg['To'] = email_to
    msg.attach(body_part)    
    smtp = smtplib.SMTP(SMTP_SERVER)
    smtp.sendmail(EMAIL_FROM, email_to.split(","), msg.as_string())
    smtp.quit()