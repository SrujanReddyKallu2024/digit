#!/bin/bash

# BASE PATHS
DATA_FROM_STS="/data/data_from_sts"
HDFS_BASE_PATH="/user/unity/match2"
DATA_FROM_STS_BACKUP="/data/data_from_sts_backup"
DATA_TO_STS="/data/data_to_sts"
DATA_TO_STS_TEMP="/data/data_to_sts/temp"
QUEUE1="andy"
QUEUE2="adam"
QUEUE3="unity"
REPO_DIR="/home/unity/consumer-sync-taxonomy"
LOGS_DIR="${REPO_DIR}/logs"
MAILLIST="emsactivatealerts@experian.com"

if [ $# -eq 0 ]; then
    RUNDATE=$(date +%Y-%m-%d)
else
    RUNDATE=$1
fi

RUNMONTH=$(date -d "$RUNDATE" +%Y-%m)
TAX_LOCK_FILE="/tmp/dtaxonomy.lock"
DT_DATE_FORMAT=$(date -d $RUNDATE +"%B%y")

# INPUT PATHS
LOCAL_STS_INPUT_PATH="/data/digitaltaxonomy/input"
LOCAL_ADHOC_INPUT_PATH="/data/data_from_sts/internal/misc"
LOCAL_INPUT_PATH="/data/digitaltaxonomy/base"
HDFS_INPUT_PATH="${HDFS_BASE_PATH}/digitaltaxonomy/input"
HDFS_BKP_PATH="${HDFS_BASE_PATH}/digitaltaxonomy/backup"

# OUTPUT PATHS
HDFS_OUTPUT_PATH="${HDFS_BASE_PATH}/digitaltaxonomy/output"
HDFS_INTERIM_PATH="${HDFS_BASE_PATH}/digitaltaxonomy/interim"
LOCAL_TEMP_PATH="/data/data_to_sts/temp/taxonomy"
LOCAL_PROC_PATH="/data/data_from_sts/internal"
LOCAL_CD_OUT_PATH="/data/data_to_sts/client_services"
LOCAL_INTERNAL_TAX_PATH="/data/data_from_sts/internal"


