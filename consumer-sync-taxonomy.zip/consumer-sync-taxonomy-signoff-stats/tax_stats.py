from pyspark.sql import functions as F
from pyspark.sql import DataFrame

def summarize_columns_fast(columns_to_check=[], null_like_tokens=None, use_approx_distinct=False, normalize_strings=True):
	preprocessed_path = 'hdfs:///user/unity/match2/digitaltaxonomy/interim/pyspark_output/part-00199-b594e974-c3b0-48f5-b429-f49c366842fa-c000.csv' # /match2/digitaltaxonomy/interim/pyspark_output'
	df = spark.read.csv(preprocessed_path, header=True, inferSchema=True, sep='|')
	#
	if not columns_to_check:
		columns_to_check = df.columns
		#
	if null_like_tokens is None:
		null_like_tokens = ["", "null", "na", "n/a", "none", "undefined"]
	#
	tokens = [t.strip().lower() for t in null_like_tokens]
	#
	# Precompute total rows once
	total_rows = df.count()
	#
	agg_exprs = []
	# Build aggregation expressions in a single pass
	for c in columns_to_check:
		# Normalized string view (safe across types)
		c_str = F.lower(F.trim(F.col(c).cast("string"))) if normalize_strings else F.col(c).cast("string")
		# NaN detection for numeric columns
		is_nan = F.isnan(F.col(c).cast("double"))
		#
		# Explicit null-like predicate
		is_null_like = (F.col(c).isNull() | is_nan | c_str.isin(tokens) | (c_str == F.lit(""))) # kept explicit even if "" is in tokens
		# Distinct count excluding null-like
		if use_approx_distinct: distinct_expr = F.approx_count_distinct(F.when(~is_null_like, c_str)).alias(f"{c}_distinct")
		else:
			distinct_expr = F.countDistinct(F.when(~is_null_like, c_str)).alias(f"{c}_distinct")
		#
		# Non-null & null counts (explicit)
		non_null_expr = F.sum(F.when(~is_null_like, F.lit(1)).otherwise(F.lit(0))).alias(f"{c}_non_null")
		null_expr	 = F.sum(F.when( is_null_like, F.lit(1)).otherwise(F.lit(0))).alias(f"{c}_null")
		#
		# Min/Max excluding null-like (keep original type)
		min_expr = F.min(F.when(~is_null_like, F.col(c))).alias(f"{c}_min")
		max_expr = F.max(F.when(~is_null_like, F.col(c))).alias(f"{c}_max")
		#
		agg_exprs += [distinct_expr, non_null_expr, null_expr, min_expr, max_expr]
	#
	# One aggregation job
	agg_row = df.agg(*agg_exprs).collect()[0]
	#
	# Assemble small summary rows (one per column)
	summary_rows = []
	for c in columns_to_check:
		distinct_values = int(agg_row[f"{c}_distinct"] or 0)
		non_null_values = int(agg_row[f"{c}_non_null"] or 0)
		null_values = int(agg_row[f"{c}_null"] or 0)
		min_value = agg_row[f"{c}_min"]
		max_value = agg_row[f"{c}_max"]
		data_type = df.schema[c].dataType.simpleString()
		null_percentage = round((null_values / total_rows) * 100, 2) if total_rows > 0 else 0.0
		#
		summary_rows.append((
			c, distinct_values, min_value, max_value, data_type,
			non_null_values, null_values, null_percentage
		))
	#
	# Create summary DataFrame
	summary_df = df.sql_ctx.createDataFrame(
		summary_rows,
		["column_name", "distinct_values", "min_value", "max_value", "data_type",
		 "non_null_values", "null_values", "null_percentage"]
	)
	#return summary_df
	summary_df.show()
# hdfs:///user/unity/match2/digitaltaxonomy/interim/pyspark_output/part-00186-b594e974-c3b0-48f5-b429-f49c366842fa-c000.csv

from pyspark.sql import functions as F
from datetime import datetime

def summarize_columns_fast_no_collect(
	columns_to_check=[],
	null_like_tokens=None,
	use_approx_distinct=True,
	normalize_strings=True
):
	preprocessed_path = 'hdfs:///user/unity/match2/digitaltaxonomy/interim/pyspark_output/part-00186-b594e974-c3b0-48f5-b429-f49c366842fa-c000.csv' # /match2/digitaltaxonomy/interim/pyspark_output'
	df = spark.read.csv(preprocessed_path, header=True, inferSchema=True, sep='|')
	if not columns_to_check:
		columns_to_check = df.columns
	if null_like_tokens is None:
		null_like_tokens = ["", "null", "na", "n/a", "none", "undefined"]
	tokens = [t.strip().lower() for t in null_like_tokens]
	# Build aggregation expressions for a single pass
	agg_exprs = [F.count(F.lit(1)).alias("_total_rows")]  # compute total rows inside the agg
	for c in columns_to_check:
		# Normalized string view (safe across types)
		c_str = F.lower(F.trim(F.col(c).cast("string"))) if normalize_strings else F.col(c).cast("string")
		# NaN detection for numeric columns
		is_nan = F.isnan(F.col(c).cast("double"))
		# Explicit null-like predicate
		is_null_like = (
			F.col(c).isNull() |
			is_nan |
			c_str.isin(tokens) |
			(c_str == F.lit(""))
		)
		#
		# Distinct count excluding null-like
		if use_approx_distinct:
			distinct_expr = F.approx_count_distinct(F.when(~is_null_like, c_str)).alias(f"{c}_distinct")
		else:
			distinct_expr = F.countDistinct(F.when(~is_null_like, c_str)).alias(f"{c}_distinct")
		#
		# Non-null & null counts (explicit)
		non_null_expr = F.sum(F.when(~is_null_like, F.lit(1)).otherwise(F.lit(0))).alias(f"{c}_non_null")
		null_expr	 = F.sum(F.when( is_null_like, F.lit(1)).otherwise(F.lit(0))).alias(f"{c}_null")
		#
		# Min/Max excluding null-like (keep original type)
		min_expr = F.min(F.when(~is_null_like, F.col(c))).alias(f"{c}_min")
		max_expr = F.max(F.when(~is_null_like, F.col(c))).alias(f"{c}_max")
		#
		#Min/Max lenght
		min_len_expr = F.min(F.length(F.col(c))).alias(f"{c}_min_len")
		max_len_expr = F.max(F.length(F.col(c))).alias(f"{c}_max_len")
		#
		agg_exprs += [distinct_expr, non_null_expr, null_expr, min_expr, max_expr, min_len_expr, max_len_expr]
	#
	# === Single aggregation job (returns a 1-row DataFrame) ===
	agg_df = df.agg(*agg_exprs)
	#
	# Build an array of structs (one struct per column) and explode -> tall output
	structs = []
	for c in columns_to_check:
		structs.append(
			F.struct(
				F.lit(c).alias("column_name"),
				F.col(f"{c}_distinct").cast("long").alias("distinct_values"),
				F.col(f"{c}_min").alias("min_value"),
				F.col(f"{c}_max").alias("max_value"),
				F.lit(df.schema[c].dataType.simpleString()).alias("data_type"),
				F.col(f"{c}_non_null").cast("long").alias("non_null_values"),
				F.col(f"{c}_null").cast("long").alias("null_values"),
				F.col(f"{c}_min_len").cast("string").alias("min_lenght"),
				F.col(f"{c}_max_len").cast("string").alias("max_lenght"),
				F.round(
					F.when(F.col("_total_rows") > 0,
						   F.col(f"{c}_null") / F.col("_total_rows") * F.lit(100.0))
					 .otherwise(F.lit(0.0)), 2
				).alias("null_percentage")
			)
		)
	#
	summary_df = (
		agg_df
		.select(F.explode(F.array(*structs)).alias("m"))
		.select("m.*")
	)
	#return summary_df
	summary_df.show()
	today = datetime.now()
	year = today.year
	month = today.month
	day = today.day
	summary_df.write.option("delimiter", "|").option("header", "true").csv(f"hdfs:///user/unity/datascience/petar/training/summary/taxonomy_stats_{year}_{month}_{day}.csv")