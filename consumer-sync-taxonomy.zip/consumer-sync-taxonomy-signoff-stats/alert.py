from pyspark.sql import functions as F

from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from pathlib import PurePosixPath
from datetime import datetime

import subprocess
import smtplib
import os
import pandas as pd

today = datetime.now()
column_stats_path = f"hdfs:///user/unity/datascience/petar/taxonomy/column_summary/"
excel_report_path = f"hdfs:///user/unity/datascience/petar/taxonomy/excel_summary/taxnomy_comparison_{today.year:02d}_{today.month:02d}_{today.day:02d}.xslx"

emoji= dict()
emoji['pass']   = '✔'
emoji['fail']   = '❌'
emoji['green']  = '🟢'
emoji['amber']  = '🟡'
emoji['red']    = '🔴'
emoji['clock']  = '🕒'

# Function to apply triffic lights to stats
def traffic_lights(x):
	if x> 0:
		y= emoji['green']
	elif x< 0:
		y= emoji['red']
	else:
		y= emoji['amber']
	return y

#send_email('petar.todorov@experian.com','/data/petar/training/taxonomy_comparison_2025_12_11.csv','Test','test')
def send_email(email_to, file_path, email_subject, custom_msg_body):
	# email variables
	EMAIL_FROM = 'petar.todorov@experian.com'
	EMAIL_CC = ''
	if custom_msg_body:
		msg_body = custom_msg_body
	else:
		msg_body = f"Stats compilation failed."
	#
	MESSAGE_BODY = msg_body
	#
	SMTP_SERVER = "relay.uk.experian.local"
	#
	msg = MIMEMultipart()
	body_part = MIMEText(MESSAGE_BODY, 'plain')
	msg['Subject'] = email_subject
	msg['From'] = EMAIL_FROM
	msg['To'] = email_to
	# Add body to email
	msg.attach(body_part)
	#
	if 'taxonomy_comparison' in file_path:
		path_split = file_path.split('/')
		file_name = path_split[-1]
		with open(file_path, 'rb') as f:
			attachment = MIMEApplication(f.read(), _subtype='csv')
	else:
		file_name = None
	#
	if file_name:
		attachment.add_header('Content-Disposition', 'attachment', filename=file_name)
		msg.attach(attachment)
	#
	smtp = smtplib.SMTP(SMTP_SERVER)
	smtp.sendmail(EMAIL_FROM, email_to.split(","), msg.as_string())
	smtp.quit()

def list_hdfs_paths_files_and_dirs(hdfs_dir: str) -> list[str]:
	"""List files and directories in an HDFS directory using `hdfs dfs -ls`."""
	res = subprocess.run(["hdfs", "dfs", "-ls", hdfs_dir],
						 check=True, capture_output=True, text=True)
	lines = [ln for ln in res.stdout.splitlines() if ln.strip()]
	lines = [ln for ln in lines if not ln.startswith("Found ")]
	paths = []
	for ln in lines:
		parts = ln.split()
		if not parts:
			continue
		# First field begins with '-' for files, 'd' for directories
		if parts[0].startswith("-") or parts[0].startswith("d"):
			paths.append(parts[-1])
	return paths

def top_n_by_basename_files_and_dirs(hdfs_dir: str, n: int = 2) -> list[str]:
	"""Return top-n entries (files or directories) by lexicographic basename."""
	paths = list_hdfs_paths_files_and_dirs(hdfs_dir)
	sorted_paths = sorted(paths, key=lambda p: PurePosixPath(p).name, reverse=True)
	return sorted_paths[:n]
	
def add_change_flags(df,pct_cutoff=20.0,abs_count_cutoff=50,abs_pct_point_cutoff=5.0,pct_points_scale=1.0):
    """
    Adds flag and reason columns for changes between prev_* and curr_* with safe handling of prev==0.

    Columns expected (already in df):
      - prev_distinct_values, curr_distinct_values, diff_distinct_values
      - prev_non_null_values, curr_non_null_values, diff_non_null_values
      - prev_null_values, curr_null_values, diff_null_values
      - prev_null_percentage, curr_null_percentage, diff_null_percentage
    """
    #
    # Ensure types are numeric
    int_cols = [
        "prev_distinct_values","curr_distinct_values","diff_distinct_values",
        "prev_non_null_values","curr_non_null_values","diff_non_null_values",
        "prev_null_values","curr_null_values","diff_null_values",
    ]
    pct_cols = ["prev_null_percentage","curr_null_percentage","diff_null_percentage"]
    #
    df2 = df
    for c in int_cols:
        if c in df2.columns:
            df2 = df2.withColumn(c, F.col(c).cast("long"))
    for c in pct_cols:
        if c in df2.columns:
            # rescale if needed (e.g., 0–1 -> 0–100)
            df2 = df2.withColumn(c, (F.col(c) * F.lit(pct_points_scale)).cast("double"))
    #
    # Helper to build flags for count-based metrics
    def build_count_flags(prev_col, curr_col, diff_col, prefix):
        prev = F.col(prev_col)
        curr = F.col(curr_col)
        diff = F.col(diff_col)
        #
        # Robust % change: only compute when prev != 0
        pct_change = F.when(prev != 0, (curr - prev) * F.lit(100.0) / prev)
        #
        reason = (
            F.when((prev == 0) & (curr != 0), F.lit("prev_zero_to_nonzero"))
             .when((prev != 0) & (curr == 0), F.lit("drop_to_zero"))
             .when(F.abs(diff) >= F.lit(abs_count_cutoff), F.lit("abs_count_exceeds"))
             .when(F.abs(pct_change) >= F.lit(pct_cutoff), F.lit("relative_pct_exceeds"))
             .otherwise(F.lit(None))
        )
        flag = reason.isNotNull()
        #
        return (
            df2
            .withColumn(f"robust_pct_change_{prefix}", pct_change)  # may be null if prev==0
            .withColumn(f"flag_{prefix}_change", flag)
            .withColumn(f"reason_{prefix}", reason)
        )
    #
    # Distinct values
    df2 = build_count_flags(
        "prev_distinct_values", "curr_distinct_values", "diff_distinct_values", "distinct_values"
    )
    #
    # Non-null values
    df2 = build_count_flags(
        "prev_non_null_values", "curr_non_null_values", "diff_non_null_values", "non_null_values"
    )
    #
    # Null values
    df2 = build_count_flags(
        "prev_null_values", "curr_null_values", "diff_null_values", "null_values"
    )
    #
    # Null percentage (use absolute percentage point change as primary)
    prevp = F.col("prev_null_percentage")
    currp = F.col("curr_null_percentage")
    diffp = F.col("diff_null_percentage")
    #
    pct_change_null_pct = F.when(prevp != 0, (currp - prevp) * F.lit(100.0) / prevp)
    #
    reason_null_pct = (
        F.when((prevp == 0) & (currp > 0), F.lit("prev_zero_to_nonzero_pct"))
         .when((prevp > 0) & (currp == 0), F.lit("drop_to_zero_pct"))
         .when(F.abs(diffp) >= F.lit(abs_pct_point_cutoff), F.lit("abs_pct_points_exceeds"))
         # Optionally consider relative % change of % (less common, but kept for completeness)
         .when(F.abs(pct_change_null_pct) >= F.lit(pct_cutoff), F.lit("relative_pct_exceeds"))
         .otherwise(F.lit(None))
    )
    flag_null_pct = reason_null_pct.isNotNull()
    #
    df2 = (
        df2
        .withColumn("robust_pct_change_null_percentage", pct_change_null_pct)
        .withColumn("flag_null_percentage_change", flag_null_pct)
        .withColumn("reason_null_percentage", reason_null_pct)
    )
    #
    # Final breach flag if any metric breached
    df2 = df2.withColumn(
        "breach_any",
        F.col("flag_distinct_values_change")
        | F.col("flag_non_null_values_change")
        | F.col("flag_null_values_change")
        | F.col("flag_null_percentage_change")
    )
    #
    return df2
    
    
def alert():
    # Declear variables
    stats_comparison_path = top_n_by_basename_files_and_dirs(column_stats_path, n=1 )
    alert_stats = ["column_name", "prev_null_values", "curr_null_values", "pct_change_null_values"] # all stats every month. If there's a problem a diffrent title + different mailling list
    columns_to_check = ["C000063", "C000064"]
    
    email_subject_success = "***DTS*** Digital Taxonomy Stats"
    email_to_success = "emsactivate@experian.com,Petar.Todorov@experain.com,Andrew.Griffin@experian.com"
    
    email_subject_fail = "***DTS*** FAILED: Digital Taxonomy Stats"
    email_to_fail = "emsactivate@experian.com,Petar.Todorov@experain.com,Andrew.Griffin@experian.com,Robin.Potter@experain.com,Sujit.Nair@experian.com,Fabio.Zancani@experian.com"

    start_time = datetime.now()

    df = spark.read.csv(stats_comparison_path[0], header=True, inferSchema=True, sep='|')
    df = df.fillna(0)

    # Create email body head
    alert_string = "--- FILES ------------------------------------------------------------------------------------------\n\n"
    alert_string = alert_string + f"Stats: {stats_comparison_path}\n\n"
    alert_string = alert_string + "--- QUICK STATS ---------------------------------------------------------------------------------\n\n"

    # Filter only the taxonomy columns included in the email
    string_df = df.filter(F.col("column_name").isin(columns_to_check)).select(*alert_stats)

    # Fill in the email body with the stats line by line
    for column in columns_to_check:
        line = ""
        null_num = df.filter(F.col("column_name") == column).select(F.col("curr_null_values")).first()[0]
        pct_change = df.filter(F.col("column_name") == column).select(F.col("pct_change_null_values")).first()[0]
        line = line + f"{traffic_lights(pct_change)} {column} number of nulls: [{null_num}] ({pct_change}%)\n\n"
        alert_string = alert_string + line


    end_time = datetime.now()
    duration = str(end_time-start_time).split('.')[0]

    df = df.withColumn(
        "absolute_pct_change",
        F.greatest(
            F.abs(F.col("pct_change_null_values")),
            F.abs(F.col("pct_change_non_null_values"))
        )
    )

    alert_columns = df.select(F.collect_list("column_name")).first()[0]
    flagged_df = add_change_flags(
        df,
        pct_cutoff=10.0,           # e.g., 25% relative change
        abs_count_cutoff=1000000,      # e.g., 100 records delta
        abs_pct_point_cutoff=10,  # e.g., 2.5 percentage points
        pct_points_scale=1.0       # set to 100.0 if your null % are stored as 0–1
    )
    flagged_df = flagged_df.filter(F.col("breach_any") == "true").select(
        "column_name", "breach_any",
        "flag_distinct_values_change","reason_distinct_values",
        "flag_non_null_values_change","reason_non_null_values",
        "flag_null_values_change","reason_null_values",
        "flag_null_percentage_change","reason_null_percentage"
    )

    if flagged_df.rdd.isEmpty(): # Send out "no issues" email
        alert_string = alert_string + f"--- TOTAL TIME TAKEN ---------------------------------------------------------------------------\n\n{duration}"
        send_email(email_to_success, excel_report_path, email_subject_success, alert_string)
    else: # Send out alert email and raise flag to stop the process
        alert_string = alert_string + f"--- Issues ---------------------------------------------------------------------------\n\n"
        alert_string = alert_string + f"High null percentage change in column(s): {alert_columns}\n\nCheck attached file\n\n"
        alert_string = alert_string + f"--- TOTAL TIME TAKEN ---------------------------------------------------------------------------\n\n{emoji['clock']} {duration}"
        # Convert report to pandas dataframe so it can be writen as excel file
        df_pandas = df_spark.toPandas()
        # Save to Excel
        df_pandas.to_excel(excel_report_path, index=False, engine='xlsxwriter')
        send_email(email_to_fail, excel_report_path, email_subject_fail, alert_string)

   

alert()