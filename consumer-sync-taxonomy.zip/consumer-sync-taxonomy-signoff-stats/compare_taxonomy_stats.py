from pyspark.sql import functions as F
from pyspark.sql.functions import DataFrame
from datetime import datetime
from pathlib import PurePosixPath
import subprocess

today = datetime.now()

column_stats_path = 'hdfs:///user/unity/datascience/petar/taxonomy/column_stats/'
distinct_stats_path = 'hdfs:///user/unity/datascience/petar/taxonomy/distinct_stats/'
column_output_path = f"hdfs:///user/unity/datascience/petar/training/column_summary/taxonomy_comparison_{today.year}_{today.month:02d}_{today.day:02d}.csv"
distinct_output_path = f"hdfs:///user/unity/datascience/petar/training/distinct_summary/taxonomy_comparison_{today.year}_{today.month:02d}_{today.day:02d}.csv"

def list_hdfs_paths_files_and_dirs(hdfs_dir: str) -> list[str]:
	"""List files and directories in an HDFS directory using `hdfs dfs -ls`."""
	res = subprocess.run(["hdfs", "dfs", "-ls", hdfs_dir],
						 check=True, capture_output=True, text=True)
	lines = [ln for ln in res.stdout.splitlines() if ln.strip()]
	lines = [ln for ln in lines if not ln.startswith("Found ")]
	paths = []
	for ln in lines:
		parts = ln.split()
		if not parts:
			continue
		# First field begins with '-' for files, 'd' for directories
		if parts[0].startswith("-") or parts[0].startswith("d"):
			paths.append(parts[-1])
	return paths


def top_n_by_basename_files_and_dirs(hdfs_dir: str, n: int = 2) -> list[str]:
	"""Return top-n entries (files or directories) by lexicographic basename."""
	paths = list_hdfs_paths_files_and_dirs(hdfs_dir)
	sorted_paths = sorted(paths, key=lambda p: PurePosixPath(p).name, reverse=True)
	return sorted_paths[:n]


def hdfs_getmerge(hdfs_dir: str, local_file: str, append_newline: bool = False) -> None:
	"""
	Use `hdfs	Use `hdfs dfs -getmerge` to merge files in an HDFS directory into a local file.
	:param hdfs_dir: HDFS directory containing the files to merge.
	:param local_file: Local path for the merged output file.
	:param append_newline: Add newline between files (same as -nl flag).
	"""
	cmd = ["hdfs", "dfs", "-getmerge"]
	if append_newline:
		cmd.append("-nl")
	cmd.extend([hdfs_dir, local_file])
	subprocess.run(cmd, check=False, capture_output=False)


def compare_summary_keep_all_changes_subset(prev_df: DataFrame, curr_df: DataFrame):
	#
	recent_stats = top_n_by_basename_files_and_dirs(column_stats_path)
	#
	prev_df = spark.read.csv(recent_stats[1], header=True, inferSchema=True, sep='|')
	curr_df = spark.read.csv(recent_stats[0], header=True, inferSchema=True, sep='|')
	metrics_to_compare = ["distinct_values", "non_null_values", "null_values", "null_percentage"]
	#
	# Determine all columns present 
	all_cols = [
		"column_name",
		"distinct_values",
		"min_value",
		"max_value",
		"data_type",
		"non_null_values",
		"null_values",
		"null_percentage",
	]
	#
	# Prune to known columns (plus column_name) found in each DF to minimize shuffle width, but still keep all we expect
	prev_slim = prev_df.select(*[c for c in all_cols if c in prev_df.columns])
	curr_slim = curr_df.select(*[c for c in all_cols if c in curr_df.columns])
	#
	# Prefix columns to preserve both sides post-join
	prev_r = prev_slim.select(*[F.col(c).alias(f"prev_{c}") for c in prev_slim.columns])
	curr_r = curr_slim.select(*[F.col(c).alias(f"curr_{c}") for c in curr_slim.columns])
	#
	# Full outer join on column_name
	joined = curr_r.join(
		prev_r,
		on=F.col("curr_column_name") == F.col("prev_column_name"),
		how="full_outer"
	)
	#
	# Unified key & presence flags
	out = joined.withColumn(
		"column_name",
		F.coalesce(F.col("curr_column_name"), F.col("prev_column_name"))
	).withColumn(
		"new_field",  F.col("prev_column_name").isNull()
	).withColumn(
		"old_field", F.col("curr_column_name").isNull()
	)
	#
	# Numeric diffs & percent changes ONLY for the selected metrics
	for m in metrics_to_compare:
		out = out.withColumn(
			f"diff_{m}",
			F.col(f"curr_{m}").cast("double") - F.col(f"prev_{m}").cast("double")
		).withColumn(
			f"pct_change_{m}",
			F.when(
				(F.col(f"prev_{m}").cast("double").isNotNull()) & (F.col(f"prev_{m}").cast("double") != 0),
				(F.col(f"curr_{m}").cast("double") - F.col(f"prev_{m}").cast("double")) /
				F.col(f"prev_{m}").cast("double") * F.lit(100.0)
			)
		)
	#
	# Total Change
	out = out.withColumn(
			f"total_change",
			((F.col(f"curr_null_values")+F.col(f"curr_non_null_values"))/(F.col(f"prev_null_values")+F.col(f"prev_non_null_values")) - 1) * 100
		)
	#
	# Columns we don't need
	exluded_columns = ["column_name", "pct_change_distinct_values"]
	#
	# Final selection:
	#  - Keep prev_* and curr_* for ALL expected columns
	#  - Include change flags and diffs ONLY for the selected metrics
	prev_cols = [f"prev_{c}" for c in all_cols if c in prev_slim.columns and c not in exluded_columns]
	curr_cols = [f"curr_{c}" for c in all_cols if c in curr_slim.columns and c not in exluded_columns]
	changed_cols = [f"changed_{m}" for m in metrics_to_compare]
	diff_cols = [f"diff_{m}" for m in metrics_to_compare]
	pct_cols = [f"pct_change_{m}" for m in metrics_to_compare]
	#
	select_cols = ["column_name", "new_field", "old_field", "total_change"] + \
				  prev_cols + curr_cols + diff_cols + pct_cols
	#
	#out.select(*select_cols).show()
	#
	out.select(*select_cols).write.option("delimiter", "|").option("header", "true").csv(column_output_path)
	#
	#hdfs_dir = f"hdfs:///user/unity/datascience/petar/taxonomy/comparison/taxonomy_comparison_{year}_{month:02d}_{day:02d}.csv"
	#local_dir = f"/data/petar/training/taxonomy_comparison_{year}_{month:02d}_{day:02d}.csv"
	#
	#hdfs_getmerge(hdfs_dir, local_dir)
    
    

from pyspark.sql import functions as F

def build_value_counts_with_percentage(columns=None, include_nulls=False, separator="_"):
    recent_stats = top_n_by_basename_files_and_dirs(distinct_stats_path)
    if columns is None:
        columns = df.columns

    kv_structs = [F.struct(F.lit(c).alias("col_name"), F.col(c).alias("col_value")) for c in columns]
    stacked = (df
        .select(F.explode(F.array(*kv_structs)).alias("kv"))
        .select("kv.col_name", "kv.col_value"))

    if include_nulls:
        stacked = stacked.withColumn("col_value", F.when(F.col("col_value").isNull(), F.lit("<NULL>")).otherwise(F.col("col_value")))
    else:
        stacked = stacked.where(F.col("col_value").isNotNull())

    stacked = stacked.withColumn("col_value_str", F.col("col_value").cast("string"))
    stacked = stacked.withColumn("column_value", F.concat_ws(separator, F.col("col_name"), F.col("col_value_str")))

    counts_df = stacked.groupBy("col_name", "column_value").agg(F.count("*").alias("count"))
    totals_df = counts_df.groupBy("col_name").agg(F.sum("count").alias("total_count"))
    result = (counts_df
        .join(totals_df, on="col_name", how="inner")
        .withColumn("percentage", F.col("count") / F.col("total_count") * F.lit(100.0))
        .select("col_name", "column_value", "count", "percentage"))
    #return result
    result.select(*select_cols).write.option("delimiter", "|").option("header", "true").csv(distinct_output_path)