"""
Propensities Segments Processing Script

Processes propensities segments data for Digital Taxonomy.
"""

import os
import sys
import datetime
import argparse
import logging
import json
import boto3
from typing import Dict
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import lit, col, when, input_file_name
from timeit import default_timer as timer

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

logger = logging.getLogger(__name__)

SCRIPT_CODE = "PROPENSITIES"

def get_delimiter_for_file(file_key: str, delimiter_config: dict = None) -> str:
    """
    Get the delimiter for a specific file type.
    
    Args:
        file_key: Key identifying the file type
        delimiter_config: Delimiter configuration dictionary
        
    Returns:
        Delimiter to use for the file (defaults to "|")
    """

    
    return delimiter_config.get(file_key, "|")

def inner_join(df1: DataFrame, df2: DataFrame, join_condition) -> DataFrame:
    """Perform inner join between two DataFrames."""
    return df1.join(df2, join_condition, "inner")

def left_join(df1: DataFrame, df2: DataFrame, join_condition) -> DataFrame:
    """Perform left join between two DataFrames."""
    return df1.join(df2, join_condition, "left")

# ----------------------------------------------------------------------
# PROCESSING FUNCTIONS
# ----------------------------------------------------------------------

def process_cutoffs(spark: SparkSession, data_file_path: str, cutoffs_file_path: str, 
                   old_prefix: str, delimiter: str, output_folder: str):
    """Process cutoffs data."""
    logger.info(f"Processing cutoffs: {data_file_path}")
    
    data_df = spark.read.option("header", 'true').option("delimiter", f"{delimiter}").csv(data_file_path)
    rules_df = spark.read.option("header", 'true').csv(cutoffs_file_path)
        
    rules_dict = {row[rules_df.columns[0]]: row[rules_df.columns[1]] for row in rules_df.collect()}

    for var, cutoff in rules_dict.items():
        if var in data_df.columns:
            new_var = var.replace(old_prefix, "FLAG")
            data_df = data_df.withColumn(new_var, when(col(var) >= cutoff, "Y").otherwise(""))

    data_df.write.mode("overwrite").option("header", True).parquet(output_folder)
    logger.info(f"Cutoffs processing complete for {output_folder}")

def process_files(spark: SparkSession, input_csv_path: str, flagged_parquet_path: str, 
                 old_prefix: str, output_path: str):
    """Process files for propensities."""
    logger.info(f"Processing files: {input_csv_path}")
    
    # Get current month for MC column
    current_month = spark.sql("SELECT date_format(current_date(), 'MM') as month").collect()[0].month
    mc_column_value = f"MC_{current_month}"
    
    # Read CSV
    df = spark.read.csv(input_csv_path, sep=",", header=True)
    df = df.withColumn("FileName", input_file_name())
    df = df.withColumn("Calculation", lit(mc_column_value))

    logger.info(f" process_files CSV columns: {df.columns}")

    # Melt dataframe
    melt_columns = [col for col in df.columns if col != "cb_Key_Household"]
    stack_expr = f"stack({len(melt_columns)}, " + ", ".join([f"'{col}', {col}" for col in melt_columns]) + ") as (Name, Value)"
    df_melted = df.selectExpr("cb_Key_Household", stack_expr)
    
    # Filter for current MC column
    df_pivoted = df_melted.withColumn("Current_MC", when(col("Name") == mc_column_value, col("Name")).otherwise(""))
    df_filtered = df_pivoted.filter(col("Current_MC").isNotNull() & (col("Current_MC") != "")).drop("Name")
    df_filtered = df_filtered.withColumnRenamed("Value", "MCMATCH")
    unique = df_filtered.dropDuplicates(["cb_Key_Household"])
    
    # Read flagged parquet
    flagged = spark.read.parquet(flagged_parquet_path)
    
    # Perform join
    join_condition = unique["MCMATCH"] == flagged["MC"]
    join = inner_join(unique, flagged, join_condition)

    join = join.drop(*[y for y in join.columns if y.startswith(old_prefix)])
    renamed_cols = [col(col_name).alias(col_name[:-len('_millitile')] if col_name.endswith('_millitile') else col_name) for col_name in join.columns]
    join = join.select(*renamed_cols)
    join = join.toDF(*[col.replace("FLAG", old_prefix) if col.startswith("FLAG") else col for col in join.columns])

    # Write output
    join.write.mode("overwrite").parquet(output_path)
    logger.info(f"Files processing complete for {output_path}")

# ----------------------------------------------------------------------
# ARGUMENT PARSING
# ----------------------------------------------------------------------

def create_parser():
    """Create argument parser for the script."""
    parser = argparse.ArgumentParser(description="Process Propensities Segments data for EMR")
    
    parser.add_argument("--f35_input_path", type=str, required=True,
                      help="S3 path to F35 consview input data")
    parser.add_argument("--f45_input_path", type=str, required=True,
                      help="S3 path to F45 CBAF utility input data")    
    parser.add_argument("--config_path", type=str, required=True,
                      help="JSON string containing propensities configuration")
    parser.add_argument("--prop_millitiles_path", type=str, required=True,
                      help="S3 path to Propensities millitiles data")
    parser.add_argument("--cons_dynamics_path", type=str, required=True,
                      help="S3 path to Consumer Dynamics millitiles data")
    parser.add_argument("--output_path", type=str, required=True,
                      help="S3 path for output data")
    parser.add_argument("--mosaic_version", type=str, default="7",
                      help="Mosaic version to use (default: 7)")
    parser.add_argument("--delimiter_config", type=str, required=False,
                      help="JSON string containing delimiter configuration")
    
    return parser

# ----------------------------------------------------------------------
# MAIN PROCESSING FUNCTION
# ----------------------------------------------------------------------

def process_data(spark: SparkSession, f35_input_path: str, f45_input_path: str, 
                config_path: str, prop_millitiles_path: str, cons_dynamics_path: str,
                output_path: str, mosaic_version: str = "7", delimiter_config: dict = None) -> DataFrame:
    """
    Main data processing logic following the pattern of the original script.
    """
    start_time = timer()
    
    logger.info(f"Starting Propensities Segments processing")
    logger.info(f"F35 Input path: {f35_input_path}")
    logger.info(f"F45 Input path: {f45_input_path}")
    logger.info(f"Config path: {config_path}")
    logger.info(f"Mosaic version: {mosaic_version}")
    try:
        # Parse the config JSON string
        logger.info("Parsing propensities configuration from JSON string")
        params = json.loads(config_path)
        
        # Process iterations from config
        logger.info("Processing cutoffs iterations")
        for iteration in params['iterations']:
            data_file_path = iteration['data_file_path']
            cutoffs_file_path = iteration['cutoffs_file_path']
            old_prefix = iteration['old_prefix']
            output_folder = iteration['output_folder']
            delimiter = iteration['delimiter']

            process_cutoffs(spark, data_file_path, cutoffs_file_path, old_prefix, delimiter, output_folder)

        logger.info("Processing files iterations")
        for iteration in params['iterations2']:
            input_csv_path = iteration['input_csv_path']
            flagged_parquet_path = iteration['flagged_parquet_path']
            old_prefix = iteration['old_prefix']
            output_path_iter = iteration['output_path']

            process_files(spark, input_csv_path, flagged_parquet_path, old_prefix, output_path_iter)

        # Read main data files with appropriate delimiters
        logger.info("Reading F35 and F45 data")
        f35_delimiter = get_delimiter_for_file("f35_input", delimiter_config)
        logger.info(f"Using delimiter '{f35_delimiter}' for F35 file")
        df = spark.read.csv(f35_input_path, sep=f35_delimiter, header=True)
        df = df.select("cb_key_db_person", "cb_key_household", "mailable_postcode")
        initial_count = df.count()
        logger.info(f"F35 data count: {initial_count:,} rows")

        f45_delimiter = get_delimiter_for_file("f45_input", delimiter_config)
        logger.info(f"Using delimiter '{f45_delimiter}' for F45 file")
        f45 = spark.read.option("header", "true").option("sep", f45_delimiter).csv(f45_input_path)
        f45 = f45.select("mailable_postcode", f"pc_mosaic_uk_{mosaic_version}_type")

        # Join F35 and F45
        logger.info("Joining F35 and F45 data")
        join_condition = f45["mailable_postcode"] == df["mailable_postcode"]
        join = inner_join(f45, df, join_condition)

        # Read millitiles data
        logger.info("Reading propensities and consumer dynamics millitiles")
        prop_millitiles = spark.read.parquet(prop_millitiles_path)
        cons_dynamics_millitiles = spark.read.parquet(cons_dynamics_path)

        # Clean and prepare millitiles data
        cols_to_drop = ['MCMATCH', 'Current_MC', 'MC']
        prop_millitiles = prop_millitiles.drop(*cols_to_drop).withColumnRenamed("cb_Key_Household", "cb_Key_Household_1")
        cons_dynamics_millitiles = cons_dynamics_millitiles.drop(*cols_to_drop).withColumnRenamed("cb_Key_Household", "cb_Key_Household_1")

        # Join with millitiles data
        logger.info("Joining with propensities millitiles")
        df = left_join(join, prop_millitiles, join["cb_key_household"] == prop_millitiles["cb_Key_Household_1"])
        df = df.drop("cb_Key_Household_1")
        
        logger.info("Joining with consumer dynamics millitiles")
        df = inner_join(df, cons_dynamics_millitiles, df["cb_key_household"] == cons_dynamics_millitiles["cb_Key_Household_1"])
        df = df.drop("cb_Key_Household_1", "mailable_postcode", "cb_key_household")

        final_count = df.count()
        logger.info(f"Final processed count: {final_count:,} rows")
        
        # Write output to S3
        logger.info(f"Writing output to S3: {output_path}")
        df.write.mode("overwrite").parquet(output_path)
        
        # Verify output
        output_df = spark.read.parquet(output_path)
        output_count = output_df.count()
        logger.info(f"Verified output count: {output_count:,} rows")
        
        
        end_time = timer()
        processing_time = str(datetime.timedelta(seconds=round(end_time - start_time, 0)))
        logger.info(f"Propensities Segments processing completed successfully in {processing_time}")
        
        return df
        
    except Exception as e:
        logger.error(f"Error processing Propensities Segments data: {str(e)}")
        raise

# ----------------------------------------------------------------------
# MAIN FUNCTION
# ----------------------------------------------------------------------

def main():
    """Main entry point for the script."""
    start_time = timer()
    
    # Parse arguments
    parser = create_parser()
    args, unknown = parser.parse_known_args()
    
    if unknown:
        logger.warning(f"Unknown arguments: {unknown}")
    
    # Parse delimiter configuration
    delimiter_config = {}
    if hasattr(args, 'delimiter_config') and args.delimiter_config:
        try:
            delimiter_config = json.loads(args.delimiter_config)
            logger.info(f"Using delimiter configuration: {delimiter_config}")
        except Exception as e:
            logger.warning(f"Failed to parse delimiter config: {e}. Using defaults.")
    
    # Initialize Spark Session
    spark = (SparkSession.builder
        .appName("Process Propensities Segments EMR")
        .config("spark.sql.adaptive.enabled", "true")
        .config("spark.sql.adaptive.coalescePartitions.enabled", "true")
        .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
        .getOrCreate())
    
    spark.sparkContext.setLogLevel("WARN")
    
    logger.info("Starting Process Propensities Segments EMR job")
    
    try:
        # Process the data
        result_df = process_data(
            spark=spark,
            f35_input_path=args.f35_input_path,
            f45_input_path=args.f45_input_path,
            config_path=args.config_path,
            prop_millitiles_path=args.prop_millitiles_path,
            cons_dynamics_path=args.cons_dynamics_path,
            output_path=args.output_path,
            mosaic_version=args.mosaic_version,
            delimiter_config=delimiter_config
        )
        
        # Calculate total time
        end_time = timer()
        total_time = str(datetime.timedelta(seconds=round(end_time - start_time, 0)))
        
        logger.info(f"Job completed successfully in {total_time}")
        logger.info("Process Propensities Segments EMR job finished")
        
        # Exit successfully
        sys.exit(0)
        
    except Exception as e:
        logger.error(f"Process failed: {type(e).__name__}: {str(e)}", exc_info=True)
        sys.exit(1)
    
    finally:
        if spark:
            spark.stop()

if __name__ == "__main__":
    main()