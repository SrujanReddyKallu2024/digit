"""
Script Name: process_file_auto_segments_emr.py
Description: EMR-compatible version of process_file_auto_segments for processing Auto Segments data.
             This version is designed to run with S3 paths via EMR Serverless.
Date: July 28, 2025
"""

# ----------------------------------------------------------------------
# STANDARD IMPORTS
# ----------------------------------------------------------------------

import os
import sys
import datetime
import argparse
import logging
import json
import boto3
import pandas as pd
from typing import Dict
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import length, col, isnan, substring, concat_ws, collect_list, when
from timeit import default_timer as timer

# Configure root logger
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

logger = logging.getLogger(__name__)

# ----------------------------------------------------------------------
# SCRIPT CONFIGURATION
# ----------------------------------------------------------------------

SCRIPT_CODE = "AUTOSEG"

# ----------------------------------------------------------------------
# ARGUMENT PARSING
# ----------------------------------------------------------------------

def create_parser():
    """Create argument parser for the script."""
    parser = argparse.ArgumentParser(description="Process Auto Segments data for EMR")
    
    parser.add_argument("--input_path", type=str, required=True,
                      help="S3 path to Excel file with Auto Segment data")
    parser.add_argument("--output_path", type=str, required=True,
                      help="S3 path for output data")
    
    return parser

# ----------------------------------------------------------------------
# MAIN PROCESSING FUNCTION
# ----------------------------------------------------------------------

def process_data(spark: SparkSession, input_path: str, output_path: str) -> DataFrame:
    """
    Main data processing logic following the pattern of the original script.
    
    Args:
        spark: SparkSession
        input_path: S3 path to input Excel data
        output_path: S3 path for output
    
    Returns:
        Processed DataFrame
    """
    start_time = timer()
    
    logger.info(f"Starting Auto Segments processing")
    logger.info(f"Input path: {input_path}")
    logger.info(f"Output path: {output_path}")
    
    try:        # Read Excel file directly from S3 into memory
        try:
            logger.info(f"Reading Excel file from S3: {input_path}")
            bucket = input_path.split("/")[2]
            key = "/".join(input_path.split("/")[3:])
            s3 = boto3.client('s3')
            object = s3.get_object(Bucket=bucket, Key=key)["Body"]
            if input_path.endswith(".xlsx"):
                import io
                excel_bytes = object.read()
                rules = pd.read_excel(io.BytesIO(excel_bytes), sheet_name="Auto Segment Selections NEW")
            else:
                raise ValueError(f"File {input_path} is not an Excel file (.xlsx)")
        except Exception as e:
            logger.error(f"Error reading Excel file from S3 {input_path}: {str(e)}")
            raise
        rules = rules.astype(str)
        initial_count = len(rules)
        logger.info(f"Initial Excel data count: {initial_count:,} rows")

        columns_to_drop = ["Segment Group No.", "Group name", "Segment name"]
        df_pandas = rules.drop(columns=columns_to_drop)

        # Convert to Spark df
        logger.info("Converting to Spark DataFrame")
        df = spark.createDataFrame(df_pandas)
        df = df.withColumnRenamed("C-number", "Segment")

        # Transpose
        logger.info("Performing transpose operation")
        key_cols = ["Segment"]
        to_excl = ["Segment", "S-Number"]
        data_cols = [col for col in df.columns if col not in to_excl]

        for column in data_cols:
            auto_segments = df.withColumn(column, df[column].cast("STRING"))

        stack_expr = ", ".join([f"'{column}', `{column}`" for column in data_cols])
        auto_segments = auto_segments.selectExpr(*[f"`{key}`" for key in key_cols], f"stack({len(data_cols)}, {stack_expr}) as (Name, Value)")

        # Drop and rename columns
        logger.info("Processing columns and filtering")
        auto_segments = auto_segments.withColumnRenamed("Value", "Mosaic").drop("Name")
        auto_segments = auto_segments.filter(length(auto_segments.Mosaic) <= 3)

        # Filter out nulls & NaN values
        auto_segments = auto_segments.filter(
            (col("Segment").isNotNull()) &
            (~isnan(col("Segment"))) &
            (col("Mosaic").isNotNull()) & 
            (~isnan(col("Mosaic"))))

        # Add and reformat columns
        logger.info("Reformatting columns")
        auto_segments = auto_segments.withColumn("Value", col("Segment"))
        auto_segments = auto_segments.withColumn("Mosaic", substring(col('Mosaic'), 2, 2))

        # Group by official name
        logger.info("Grouping and pivoting data")
        auto_segments = auto_segments.groupBy("Mosaic").pivot("Segment").agg(concat_ws(", ", collect_list("Value")))

        # Replace any non empty value of the df with "Y"
        logger.info("Replacing non-empty values with 'Y'")
        df = auto_segments.select([when(col(c).isNotNull() & (col(c) != ""), "Y").otherwise(col(c)).alias(c) if c != "Mosaic" else col(c) for c in auto_segments.columns])

        final_count = df.count()
        logger.info(f"Final processed count: {final_count:,} rows")
        
        # Write output to S3
        logger.info(f"Writing output to S3: {output_path}")
        df.write.mode("overwrite").parquet(output_path)
        
        # Verify output
        output_df = spark.read.parquet(output_path)
        output_count = output_df.count()
        logger.info(f"Verified output count: {output_count:,} rows")
        
        # No local file cleanup needed; file read directly from S3
        
        
        end_time = timer()
        processing_time = str(datetime.timedelta(seconds=round(end_time - start_time, 0)))
        logger.info(f"Auto Segments processing completed successfully in {processing_time}")
        
        return df
        
    except Exception as e:
        logger.error(f"Error processing Auto Segments data: {str(e)}")
        raise

# ----------------------------------------------------------------------
# MAIN FUNCTION
# ----------------------------------------------------------------------

def main():
    """Main entry point for the script."""
    start_time = timer()
    
    # Parse arguments
    parser = create_parser()
    args, unknown = parser.parse_known_args()
    
    if unknown:
        logger.warning(f"Unknown arguments: {unknown}")
    
    # Initialize Spark Session
    spark = (SparkSession.builder
        .appName("Process Auto Segments EMR")
        .config("spark.sql.adaptive.enabled", "true")
        .config("spark.sql.adaptive.coalescePartitions.enabled", "true")
        .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
        .getOrCreate())
    
    spark.sparkContext.setLogLevel("WARN")
    
    logger.info("Starting Process Auto Segments EMR job")
    
    try:
        # Process the data
        result_df = process_data(
            spark=spark,
            input_path=args.input_path,
            output_path=args.output_path
        )
        
        # Calculate total time
        end_time = timer()
        total_time = str(datetime.timedelta(seconds=round(end_time - start_time, 0)))
        
        logger.info(f"Job completed successfully in {total_time}")
        logger.info("Process Auto Segments EMR job finished")
        
        # Exit successfully
        sys.exit(0)
        
    except Exception as e:
        logger.error(f"Process failed: {type(e).__name__}: {str(e)}", exc_info=True)
        sys.exit(1)
    
    finally:
        if spark:
            spark.stop()

if __name__ == "__main__":
    main()