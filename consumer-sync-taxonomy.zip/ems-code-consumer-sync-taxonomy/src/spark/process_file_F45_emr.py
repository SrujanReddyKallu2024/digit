"""
F45 CBAF Utility Data Processing Script

Processes F45 CBAF utility data for Digital Taxonomy.
"""

import os
import sys
import datetime
import argparse
import logging
import json
import boto3
from typing import Dict
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import trim, regexp_replace
from timeit import default_timer as timer

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

logger = logging.getLogger(__name__)

SCRIPT_CODE = "F45"

def get_delimiter_for_file(file_key: str, delimiter_config: dict = None) -> str:
    """
    Get the delimiter for a specific file type.
    
    Args:
        file_key: Key identifying the file type
        delimiter_config: Delimiter configuration dictionary
        
    Returns:
        Delimiter to use for the file (defaults to "|")
    """

    
    return delimiter_config.get(file_key, "|")

def create_parser():
    """Create command line argument parser."""
    parser = argparse.ArgumentParser(description="Process F45 data for EMR")
    
    parser.add_argument("--input_path", type=str, required=True,
                      help="S3 path to F45 input data")
    parser.add_argument("--output_path", type=str, required=True,
                      help="S3 path for output data")
    parser.add_argument("--delimiter_config", type=str, required=False,
                      help="JSON string containing delimiter configuration")
    
    return parser

def process_data(spark: SparkSession, input_path: str, output_path: str, delimiter_config: dict = None) -> DataFrame:
    """Main data processing logic for F45 CBAF utility data."""
    start_time = timer()
    
    logger.info(f"Starting F45 processing")
    logger.info(f"Input path: {input_path}")
    logger.info(f"Output path: {output_path}")
    
    try:
        # Read input data with appropriate delimiter
        logger.info("Reading F45 CBAF utility data")
        f45_delimiter = get_delimiter_for_file("f45_input", delimiter_config)
        logger.info(f"Using delimiter '{f45_delimiter}' for F45 file")
        df = spark.read.option("header", "true").option("sep", f45_delimiter).csv(input_path)
        initial_count = df.count()
        logger.info(f"Initial data count: {initial_count:,} rows")
        
        # Remove mailable_postcode column
        logger.info("Dropping mailable_postcode column")
        df = df.drop("mailable_postcode")
        
        # Process postcode field for matching
        logger.info("Processing postcode field for matching")
        df = df.withColumn('Pcode_To_Match', trim(regexp_replace(df['postcode_bs_standard_8bytes'], ' ', '')))
        
        final_count = df.count()
        logger.info(f"Final processed count: {final_count:,} rows")
        
        # Write output to S3
        logger.info(f"Writing output to S3: {output_path}")
        df.write.mode("overwrite").parquet(output_path)
        
        # Verify output
        output_df = spark.read.parquet(output_path)
        output_count = output_df.count()
        logger.info(f"Verified output count: {output_count:,} rows")
        
        
        end_time = timer()
        processing_time = str(datetime.timedelta(seconds=round(end_time - start_time, 0)))
        logger.info(f"F45 processing completed successfully in {processing_time}")
        
        return df
        
    except Exception as e:
        logger.error(f"Error processing F45 data: {str(e)}")
        raise

def main():
    """Main entry point for the script."""
    start_time = timer()
    
    # Parse arguments
    parser = create_parser()
    args, unknown = parser.parse_known_args()
    
    if unknown:
        logger.warning(f"Unknown arguments: {unknown}")
    
    # Parse delimiter configuration
    delimiter_config = {}
    if hasattr(args, 'delimiter_config') and args.delimiter_config:
        try:
            delimiter_config = json.loads(args.delimiter_config)
            logger.info(f"Using delimiter configuration: {delimiter_config}")
        except Exception as e:
            logger.warning(f"Failed to parse delimiter config: {e}. Using defaults.")
    
    # Initialize Spark Session
    spark = (SparkSession.builder
        .appName("Process F45 EMR")
        .config("spark.sql.adaptive.enabled", "true")
        .config("spark.sql.adaptive.coalescePartitions.enabled", "true")
        .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
        .getOrCreate())
    
    spark.sparkContext.setLogLevel("WARN")
    
    logger.info("Starting Process F45 EMR job")
    
    try:
        # Process the data
        result_df = process_data(
            spark=spark,
            input_path=args.input_path,
            output_path=args.output_path,
            delimiter_config=delimiter_config
        )
        
        # Calculate total time
        end_time = timer()
        total_time = str(datetime.timedelta(seconds=round(end_time - start_time, 0)))
        
        logger.info(f"Job completed successfully in {total_time}")
        logger.info("Process F45 EMR job finished")
        
        sys.exit(0)
        
    except Exception as e:
        logger.error(f"Process failed: {type(e).__name__}: {str(e)}", exc_info=True)
        sys.exit(1)
    
    finally:
        if spark:
            spark.stop()

if __name__ == "__main__":
    main()