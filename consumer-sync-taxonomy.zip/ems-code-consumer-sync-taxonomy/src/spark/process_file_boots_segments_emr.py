"""
Boots Segments Processing Script

Processes Boots segments data for Digital Taxonomy.
"""

import os
import sys
import datetime
import argparse
import logging
import json
import boto3
import re
import pandas as pd
from typing import Dict
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import trim, lit, first, col
from timeit import default_timer as timer

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

logger = logging.getLogger(__name__)

SCRIPT_CODE = "BOOTS"

def get_delimiter_for_file(file_key: str, delimiter_config: dict = None) -> str:
    """
    Get the delimiter for a specific file type.
    
    Args:
        file_key: Key identifying the file type
        delimiter_config: Delimiter configuration dictionary
        
    Returns:
        Delimiter to use for the file (defaults to "|")
    """
    
    return delimiter_config.get(file_key, "|")

def inner_join(df1: DataFrame, df2: DataFrame, join_condition) -> DataFrame:
    """Perform inner join between two DataFrames."""
    return df1.join(df2, join_condition, "inner")

def create_parser():
    """Create command line argument parser."""
    parser = argparse.ArgumentParser(description="Process Boots Segments data for EMR")
    
    parser.add_argument("--f35_input_path", type=str, required=True,
                      help="S3 path to F35 consview input data")
    parser.add_argument("--boots_lookup_path", type=str, required=True,
                      help="S3 path to Boots Model Segments lookup Excel file")
    parser.add_argument("--output_path", type=str, required=True,
                      help="S3 path for output data")
    parser.add_argument("--mosaic_version", type=str, default="7",
                      help="Mosaic version to use (default: 7)")
    parser.add_argument("--delimiter_config", type=str, required=False,
                      help="JSON string containing delimiter configuration")
    
    return parser

def process_data(spark: SparkSession, f35_input_path: str, boots_lookup_path: str, 
                output_path: str, mosaic_version: str = "7", delimiter_config: dict = None) -> DataFrame:
    """Main data processing logic for Boots segments data."""
    start_time = timer()
    
    logger.info(f"Starting Boots Segments processing")
    logger.info(f"F35 Input path: {f35_input_path}")
    logger.info(f"Boots lookup path: {boots_lookup_path}")
    logger.info(f"Output path: {output_path}")
    logger.info(f"Mosaic version: {mosaic_version}")
    
    try:
        # Read F35 data with appropriate delimiter
        logger.info("Reading F35 consview data")
        f35_delimiter = get_delimiter_for_file("f35_input", delimiter_config)
        logger.info(f"Using delimiter '{f35_delimiter}' for F35 file")
        df = spark.read.csv(f35_input_path, header=True, sep=f35_delimiter)
        initial_count = df.count()
        logger.info(f"F35 data count: {initial_count:,} rows")
        
        # Select required columns
        logger.info("Selecting required columns from F35")
        df = df.select("cb_key_db_person", "mailable_postcode", f"p_mosaic_uk_{mosaic_version}_shopper_type")
          # Read Boots lookup Excel file directly from S3 into memory
        try:
            logger.info(f"Reading Boots lookup Excel file from S3: {boots_lookup_path}")
            bucket = boots_lookup_path.split("/")[2]
            key = "/".join(boots_lookup_path.split("/")[3:])
            s3 = boto3.client('s3')
            object = s3.get_object(Bucket=bucket, Key=key)["Body"]
            if boots_lookup_path.endswith(".xlsx"):
                import io
                excel_bytes = object.read()
                boots_lookup_pandas = pd.read_excel(io.BytesIO(excel_bytes))
            else:
                raise ValueError(f"File {boots_lookup_path} is not an Excel file (.xlsx)")
        except Exception as e:
            logger.error(f"Error reading Excel file from S3 {boots_lookup_path}: {str(e)}")
            raise
        boots_lookup_pandas = boots_lookup_pandas.astype(str)
        
        # Convert to Spark DataFrame
        boots_lookup = spark.createDataFrame(boots_lookup_pandas)
        boots_lookup = boots_lookup.select("Segment Code", "Official Name", "Tier")
        boots_lookup = boots_lookup.withColumn("Official Name", trim(boots_lookup["Official Name"]))
        boots_lookup = boots_lookup.withColumn("seg_y", lit("Y"))

        # Transpose lookup
        logger.info("Transposing lookup data")
        key_cols = ["Segment Code", "seg_y"]
        data_cols = ["Official Name"]
        
        for column in data_cols:
            boots_lookup = boots_lookup.withColumn(column, boots_lookup[column].cast("STRING"))
        
        stack_expr = ", ".join([f"'{column}', `{column}`" for column in data_cols])
        boots_lookup = boots_lookup.selectExpr(*[f"`{key}`" for key in key_cols], f"stack({len(data_cols)}, {stack_expr}) as (Name, Value)")
        
        # Group by official name
        logger.info("Grouping by segment code")
        boots_lookup = boots_lookup.groupBy("Segment Code").pivot("Value").agg(first("seg_y"))

        # Perform join
        logger.info("Joining F35 data with Boots lookup")
        join = inner_join(df, boots_lookup, join_condition=df[f"p_mosaic_uk_{mosaic_version}_shopper_type"] == boots_lookup["Segment Code"])
        join = join.drop("Segment Code", f"p_mosaic_uk_{mosaic_version}_shopper_type", "mailable_postcode")

        # Clean column names
        logger.info("Cleaning column names")
        new_cols = [re.sub(r"[ ,&:*-]", "_", column) for column in join.columns]
        df = join.toDF(*new_cols)

        final_count = df.count()
        logger.info(f"Final processed count: {final_count:,} rows")
        
        # Write output to S3
        logger.info(f"Writing output to S3: {output_path}")
        df.write.mode("overwrite").parquet(output_path)
        
        # Verify output
        output_df = spark.read.parquet(output_path)
        output_count = output_df.count()
        logger.info(f"Verified output count: {output_count:,} rows")
        
        # No local file cleanup needed; file read directly from S3
        
        
        end_time = timer()
        processing_time = str(datetime.timedelta(seconds=round(end_time - start_time, 0)))
        logger.info(f"Boots Segments processing completed successfully in {processing_time}")
        
        return df
        
    except Exception as e:
        logger.error(f"Error processing Boots Segments data: {str(e)}")
        raise

# ----------------------------------------------------------------------
# MAIN FUNCTION
# ----------------------------------------------------------------------

def main():
    """Main entry point for the script."""
    start_time = timer()
    
    # Parse arguments
    parser = create_parser()
    args, unknown = parser.parse_known_args()
    
    if unknown:
        logger.warning(f"Unknown arguments: {unknown}")
    
    # Parse delimiter configuration
    delimiter_config = {}
    if hasattr(args, 'delimiter_config') and args.delimiter_config:
        try:
            delimiter_config = json.loads(args.delimiter_config)
            logger.info(f"Using delimiter configuration: {delimiter_config}")
        except Exception as e:
            logger.warning(f"Failed to parse delimiter config: {e}. Using defaults.")
    
    # Initialize Spark Session
    spark = (SparkSession.builder
        .appName("Process Boots Segments EMR")
        .config("spark.sql.adaptive.enabled", "true")
        .config("spark.sql.adaptive.coalescePartitions.enabled", "true")
        .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
        .getOrCreate())
    
    spark.sparkContext.setLogLevel("WARN")
    
    logger.info("Starting Process Boots Segments EMR job")
    
    try:
        # Process the data
        result_df = process_data(
            spark=spark,
            f35_input_path=args.f35_input_path,
            boots_lookup_path=args.boots_lookup_path,
            output_path=args.output_path,
            mosaic_version=args.mosaic_version,
            delimiter_config=delimiter_config
        )
        
        # Calculate total time
        end_time = timer()
        total_time = str(datetime.timedelta(seconds=round(end_time - start_time, 0)))
        
        logger.info(f"Job completed successfully in {total_time}")
        logger.info("Process Boots Segments EMR job finished")
        
        # Exit successfully
        sys.exit(0)
        
    except Exception as e:
        logger.error(f"Process failed: {type(e).__name__}: {str(e)}", exc_info=True)
        sys.exit(1)
    
    finally:
        if spark:
            spark.stop()

if __name__ == "__main__":
    main()