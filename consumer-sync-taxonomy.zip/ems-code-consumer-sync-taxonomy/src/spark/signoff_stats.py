"""
Signoff Stats Module for Digital Taxonomy

This module provides functions to:
1. Compute column-level statistics from a DataFrame
2. Load previous month's stats from S3
3. Compare current stats with previous
4. Validate against thresholds
5. Save stats to S3

Used by main_emr.py to validate output before writing to client delivery.
"""

import logging
import json
import io
from datetime import datetime
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass

import boto3
import pandas as pd
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F

logger = logging.getLogger(__name__)

# Default thresholds (matches on-prem alert.py)
DEFAULT_THRESHOLDS = {
    "pct_cutoff": 10.0,                # Relative % change threshold
    "abs_count_cutoff": 1000000,       # Absolute count change threshold (1M records)
    "abs_pct_point_cutoff": 10.0,      # Absolute percentage point change
    "max_row_count_change": 5.0,       # Max allowed % change in row count
}

# Columns that MUST have 0% nulls
CRITICAL_COLUMNS = [
    "cb_key_db_person",
]

# Columns to check for alerts (matching on-prem columns_to_check)
# These columns are highlighted in alert emails
ALERT_COLUMNS = [
    "C000063",  # Consumer prospectable flag
    "C000064",  # Household prospectable flag
]

# Traffic light emojis for alerts
EMOJI = {
    "pass": "✔",
    "fail": "❌",
    "green": "🟢",
    "amber": "🟡",
    "red": "🔴",
    "clock": "🕒",
}


def traffic_lights(x):
    """Apply traffic light emoji based on value (matches on-prem)."""
    if x > 0:
        return EMOJI["green"]
    elif x < 0:
        return EMOJI["red"]
    else:
        return EMOJI["amber"]


def add_change_flags(
    comparison: Dict,
    pct_cutoff: float = 10.0,
    abs_count_cutoff: int = 1000000,
    abs_pct_point_cutoff: float = 10.0
) -> Dict:
    """
    Add flag and reason for each column's changes.
    
    Matches on-prem alert.py add_change_flags() function.
    
    For each column adds:
    - flag_distinct_values_change, reason_distinct_values
    - flag_non_null_values_change, reason_non_null_values
    - flag_null_values_change, reason_null_values
    - flag_null_percentage_change, reason_null_percentage
    - breach_any (True if any flag is True)
    
    Args:
        comparison: Comparison dictionary from compare_stats()
        pct_cutoff: Relative % change threshold (default 10%)
        abs_count_cutoff: Absolute count change threshold (default 1M)
        abs_pct_point_cutoff: Absolute % point change threshold (default 10)
    
    Returns:
        Updated comparison dict with flags and reasons
    """
    def build_count_flags(prev_val, curr_val, diff_val, prefix):
        """Build flags for count-based metrics."""
        flag = False
        reason = None
        robust_pct_change = None
        
        # Calculate robust % change (only when prev != 0)
        if prev_val != 0:
            robust_pct_change = ((curr_val - prev_val) / prev_val) * 100
        
        # Check breach conditions
        if prev_val == 0 and curr_val != 0:
            flag = True
            reason = "prev_zero_to_nonzero"
        elif prev_val != 0 and curr_val == 0:
            flag = True
            reason = "drop_to_zero"
        elif abs(diff_val) >= abs_count_cutoff:
            flag = True
            reason = "abs_count_exceeds"
        elif robust_pct_change is not None and abs(robust_pct_change) >= pct_cutoff:
            flag = True
            reason = "relative_pct_exceeds"
        
        return {
            f"flag_{prefix}_change": flag,
            f"reason_{prefix}": reason,
            f"robust_pct_change_{prefix}": robust_pct_change
        }
    
    # Process each column
    for col_name, col_data in comparison["columns"].items():
        if col_data.get("status") != "compared":
            # For new/removed columns, just set breach flags
            col_data["breach_any"] = col_data.get("status") in ["new_column", "removed"]
            continue
        
        flags = {}
        
        # Distinct values flags
        flags.update(build_count_flags(
            col_data.get("prev_distinct_values", 0),
            col_data.get("curr_distinct_values", 0),
            col_data.get("diff_distinct_values", 0),
            "distinct_values"
        ))
        
        # Non-null values flags
        flags.update(build_count_flags(
            col_data.get("prev_non_null_values", 0),
            col_data.get("curr_non_null_values", 0),
            col_data.get("diff_non_null_values", 0),
            "non_null_values"
        ))
        
        # Null values flags
        flags.update(build_count_flags(
            col_data.get("prev_null_values", 0),
            col_data.get("curr_null_values", 0),
            col_data.get("diff_null_values", 0),
            "null_values"
        ))
        
        # Null percentage flags (uses percentage point change)
        prev_pct = col_data.get("null_pct", {}).get("previous", 0)
        curr_pct = col_data.get("null_pct", {}).get("current", 0)
        diff_pct = col_data.get("null_pct", {}).get("diff", 0)
        
        flag_null_pct = False
        reason_null_pct = None
        robust_pct_change_null_pct = None
        
        if prev_pct != 0:
            robust_pct_change_null_pct = ((curr_pct - prev_pct) / prev_pct) * 100
        
        if prev_pct == 0 and curr_pct > 0:
            flag_null_pct = True
            reason_null_pct = "prev_zero_to_nonzero_pct"
        elif prev_pct > 0 and curr_pct == 0:
            flag_null_pct = True
            reason_null_pct = "drop_to_zero_pct"
        elif abs(diff_pct) >= abs_pct_point_cutoff:
            flag_null_pct = True
            reason_null_pct = "abs_pct_points_exceeds"
        elif robust_pct_change_null_pct is not None and abs(robust_pct_change_null_pct) >= pct_cutoff:
            flag_null_pct = True
            reason_null_pct = "relative_pct_exceeds"
        
        flags["flag_null_percentage_change"] = flag_null_pct
        flags["reason_null_percentage"] = reason_null_pct
        flags["robust_pct_change_null_percentage"] = robust_pct_change_null_pct
        
        # breach_any - True if any flag is True
        flags["breach_any"] = (
            flags.get("flag_distinct_values_change", False) or
            flags.get("flag_non_null_values_change", False) or
            flags.get("flag_null_values_change", False) or
            flags.get("flag_null_percentage_change", False)
        )
        
        # Add all flags to column data
        col_data.update(flags)
    
    return comparison


@dataclass
class ValidationResult:
    """Result of stats validation."""
    passed: bool
    reasons: List[str]
    current_stats: Dict
    previous_stats: Optional[Dict]
    comparison: Optional[Dict]



def compute_column_stats(df: DataFrame, columns_to_check: List[str] = None, 
                          null_like_tokens: List[str] = None,
                          use_approx_distinct: bool = True) -> Dict:
    """
    Compute statistics for each column in the DataFrame.
    
    Matches on-prem tax_stats.py functionality:
    - distinct_values
    - min_value, max_value
    - data_type
    - non_null_values, null_values, null_percentage
    - min_length, max_length
    - NaN detection
    - null_like_tokens handling
    
    Args:
        df: Spark DataFrame to compute stats for
        columns_to_check: Optional list of columns to check. If None, checks all.
        null_like_tokens: Values to treat as null. Default: ["", "null", "na", "n/a", "none", "undefined"]
        use_approx_distinct: Use approximate distinct count for speed (default: True)
    
    Returns:
        Dictionary with stats for each column
    """
    logger.info("Computing column statistics (matching on-prem tax_stats.py)...")
    
    if columns_to_check is None:
        columns_to_check = df.columns
    
    if null_like_tokens is None:
        null_like_tokens = ["", "null", "na", "n/a", "none", "undefined"]
    
    tokens = [t.strip().lower() for t in null_like_tokens]
    
    # Build aggregation expressions for all columns in single pass
    # Include total row count in the aggregation
    agg_exprs = [F.count(F.lit(1)).alias("_total_rows")]
    
    for col_name in columns_to_check:
        # Normalized string view (safe across types)
        c_str = F.lower(F.trim(F.col(col_name).cast("string")))
        
        # NaN detection for numeric columns
        is_nan = F.isnan(F.col(col_name).cast("double"))
        
        # Explicit null-like predicate (matches on-prem)
        is_null_like = (
            F.col(col_name).isNull() |
            is_nan |
            c_str.isin(tokens) |
            (c_str == F.lit(""))
        )
        
        # Distinct count excluding null-like
        if use_approx_distinct:
            distinct_expr = F.approx_count_distinct(
                F.when(~is_null_like, c_str)
            ).alias(f"{col_name}__distinct")
        else:
            distinct_expr = F.countDistinct(
                F.when(~is_null_like, c_str)
            ).alias(f"{col_name}__distinct")
        
        # Non-null & null counts
        non_null_expr = F.sum(
            F.when(~is_null_like, F.lit(1)).otherwise(F.lit(0))
        ).alias(f"{col_name}__non_null")
        
        null_expr = F.sum(
            F.when(is_null_like, F.lit(1)).otherwise(F.lit(0))
        ).alias(f"{col_name}__null")
        
        # Min/Max excluding null-like (preserve original type)
        min_expr = F.min(F.when(~is_null_like, F.col(col_name))).alias(f"{col_name}__min")
        max_expr = F.max(F.when(~is_null_like, F.col(col_name))).alias(f"{col_name}__max")
        
        # Min/Max length
        min_len_expr = F.min(F.length(F.col(col_name))).alias(f"{col_name}__min_len")
        max_len_expr = F.max(F.length(F.col(col_name))).alias(f"{col_name}__max_len")
        
        agg_exprs.extend([distinct_expr, non_null_expr, null_expr, min_expr, max_expr, min_len_expr, max_len_expr])
    
    # Execute single aggregation
    logger.info(f"Computing stats for {len(columns_to_check)} columns...")
    agg_result = df.agg(*agg_exprs).collect()[0]
    
    total_rows = int(agg_result["_total_rows"] or 0)
    logger.info(f"Total rows: {total_rows:,}")
    
    # Build stats dictionary
    stats = {
        "total_rows": total_rows,
        "computed_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "columns": {}
    }
    
    for col_name in columns_to_check:
        non_null = int(agg_result[f"{col_name}__non_null"] or 0)
        null_count = int(agg_result[f"{col_name}__null"] or 0)
        distinct = int(agg_result[f"{col_name}__distinct"] or 0)
        null_pct = round((null_count / total_rows) * 100, 2) if total_rows > 0 else 0.0
        
        # Get data type from schema
        try:
            data_type = df.schema[col_name].dataType.simpleString()
        except:
            data_type = "unknown"
        
        # Get min/max values (convert to string for JSON serialization)
        min_val = agg_result[f"{col_name}__min"]
        max_val = agg_result[f"{col_name}__max"]
        min_len = agg_result[f"{col_name}__min_len"]
        max_len = agg_result[f"{col_name}__max_len"]
        
        stats["columns"][col_name] = {
            "distinct_values": distinct,
            "min_value": str(min_val) if min_val is not None else None,
            "max_value": str(max_val) if max_val is not None else None,
            "data_type": data_type,
            "non_null_values": non_null,
            "null_count": null_count,
            "null_percentage": null_pct,
            "min_length": int(min_len) if min_len is not None else None,
            "max_length": int(max_len) if max_len is not None else None,
        }
    
    logger.info("Column statistics computed successfully")
    return stats


def get_previous_month(current_yyyymm: str) -> str:
    """
    Get previous month in YYYYMM format.
    Handles year rollback (e.g., 202601 -> 202512).
    """
    year = int(current_yyyymm[:4])
    month = int(current_yyyymm[4:])
    
    if month == 1:
        return f"{year - 1}12"
    else:
        return f"{year}{month - 1:02d}"


def load_previous_stats(stats_bucket: str, previous_month: str) -> Optional[Dict]:
    """
    Load previous month's stats from S3.
    
    Args:
        stats_bucket: S3 bucket name
        previous_month: YYYYMM format
    
    Returns:
        Stats dictionary or None if not found
    """
    from botocore.exceptions import ClientError
    
    stats_key = f"taxonomy_signoff/{previous_month}/output_stats.json"
    
    logger.info(f"Loading previous stats from s3://{stats_bucket}/{stats_key}")
    
    try:
        s3 = boto3.client("s3")
        response = s3.get_object(Bucket=stats_bucket, Key=stats_key)
        stats = json.loads(response["Body"].read().decode("utf-8"))
        logger.info(f"Loaded previous stats: {stats['total_rows']:,} rows")
        return stats
    except ClientError as e:
        error_code = e.response.get('Error', {}).get('Code', '')
        if error_code == 'NoSuchKey' or error_code == '404':
            logger.warning(f"No previous stats found for {previous_month} (first run)")
        else:
            logger.warning(f"Could not load previous stats: {error_code} - {e}")
        return None
    except Exception as e:
        logger.warning(f"Could not load previous stats: {e}")
        return None


def save_stats(stats: Dict, stats_bucket: str, current_month: str) -> str:
    """
    Save current stats to S3.
    
    Args:
        stats: Stats dictionary to save
        stats_bucket: S3 bucket name
        current_month: YYYYMM format
    
    Returns:
        S3 path where stats were saved
    """
    stats_key = f"taxonomy_signoff/{current_month}/output_stats.json"
    
    logger.info(f"Saving stats to s3://{stats_bucket}/{stats_key}")
    
    s3 = boto3.client("s3")
    s3.put_object(
        Bucket=stats_bucket,
        Key=stats_key,
        Body=json.dumps(stats, indent=2),
        ContentType="application/json"
    )
    
    return f"s3://{stats_bucket}/{stats_key}"


def compare_stats(current: Dict, previous: Dict) -> Dict:
    """
    Compare current stats with previous stats.
    
    Matches on-prem compare_taxonomy_stats.py:
    - Row count comparison
    - Per-column: null_values, non_null_values diffs
    - total_change calculation
    - new_field / old_field detection
    
    Returns:
        Dictionary with comparison results
    """
    comparison = {
        "row_count": {
            "previous": previous["total_rows"],
            "current": current["total_rows"],
            "diff": current["total_rows"] - previous["total_rows"],
            "pct_change": round(
                ((current["total_rows"] - previous["total_rows"]) / previous["total_rows"]) * 100, 2
            ) if previous["total_rows"] > 0 else 0
        },
        "columns": {}
    }
    
    # Compare each column
    for col_name, curr_col_stats in current["columns"].items():
        prev_col_stats = previous["columns"].get(col_name)
        
        if prev_col_stats is None:
            # New column (new_field in on-prem)
            comparison["columns"][col_name] = {
                "status": "new_column",
                "new_field": True,
                "old_field": False,
                "current_null_pct": curr_col_stats["null_percentage"]
            }
            continue
        
        # Calculate changes (matching on-prem metrics)
        # Null values
        prev_null = prev_col_stats.get("null_count", 0)
        curr_null = curr_col_stats.get("null_count", 0)
        diff_null = curr_null - prev_null
        pct_change_null = round(
            ((curr_null - prev_null) / prev_null) * 100, 2
        ) if prev_null > 0 else (100.0 if curr_null > 0 else 0.0)
        
        # Non-null values
        prev_non_null = prev_col_stats.get("non_null_values", 0)
        curr_non_null = curr_col_stats.get("non_null_values", 0)
        diff_non_null = curr_non_null - prev_non_null
        
        # Distinct values
        prev_distinct = prev_col_stats.get("distinct_values", 0)
        curr_distinct = curr_col_stats.get("distinct_values", 0)
        diff_distinct = curr_distinct - prev_distinct
        pct_change_distinct = round(
            ((curr_distinct - prev_distinct) / prev_distinct) * 100, 2
        ) if prev_distinct > 0 else 0
        
        # Null percentage
        null_pct_diff = curr_col_stats["null_percentage"] - prev_col_stats["null_percentage"]
        
        # Total change (matches on-prem formula)
        # ((curr_null + curr_non_null) / (prev_null + prev_non_null) - 1) * 100
        prev_total = prev_null + prev_non_null
        curr_total = curr_null + curr_non_null
        total_change = round(
            ((curr_total / prev_total) - 1) * 100, 2
        ) if prev_total > 0 else 0
        
        comparison["columns"][col_name] = {
            "status": "compared",
            "new_field": False,
            "old_field": False,
            "total_change": total_change,
            # Null values metrics
            "prev_null_values": prev_null,
            "curr_null_values": curr_null,
            "diff_null_values": diff_null,
            "pct_change_null_values": pct_change_null,
            # Non-null values metrics
            "prev_non_null_values": prev_non_null,
            "curr_non_null_values": curr_non_null,
            "diff_non_null_values": diff_non_null,
            # Distinct values metrics
            "prev_distinct_values": prev_distinct,
            "curr_distinct_values": curr_distinct,
            "diff_distinct_values": diff_distinct,
            "pct_change_distinct_values": pct_change_distinct,
            # Null percentage metrics
            "null_pct": {
                "previous": prev_col_stats["null_percentage"],
                "current": curr_col_stats["null_percentage"],
                "diff": round(null_pct_diff, 2)
            },
            "distinct": {
                "previous": prev_distinct,
                "current": curr_distinct,
                "pct_change": pct_change_distinct
            }
        }
    
    # Check for removed columns (old_field in on-prem)
    for col_name in previous["columns"]:
        if col_name not in current["columns"]:
            comparison["columns"][col_name] = {
                "status": "removed",
                "new_field": False,
                "old_field": True
            }
    
    return comparison


def validate_thresholds(
    current_stats: Dict,
    previous_stats: Optional[Dict],
    comparison: Optional[Dict],
    thresholds: Dict = None,
    critical_columns: List[str] = None
) -> ValidationResult:
    """
    Validate stats against thresholds.
    
    Thresholds (matches on-prem alert.py):
    - pct_cutoff: Relative % change threshold
    - abs_count_cutoff: Absolute count change threshold
    - abs_pct_point_cutoff: Absolute percentage point change
    - max_row_count_change: Max % change in row count
    
    Returns:
        ValidationResult with pass/fail and reasons
    """
    if thresholds is None:
        thresholds = DEFAULT_THRESHOLDS
    
    if critical_columns is None:
        critical_columns = CRITICAL_COLUMNS
    
    reasons = []
    flagged_columns = []
    
    # Threshold values
    pct_cutoff = thresholds.get("pct_cutoff", 10.0)
    abs_count_cutoff = thresholds.get("abs_count_cutoff", 1000000)
    abs_pct_point_cutoff = thresholds.get("abs_pct_point_cutoff", 10.0)
    max_row_change = thresholds.get("max_row_count_change", 5.0)
    
    # Check critical columns for zero nulls
    for col_name in critical_columns:
        if col_name in current_stats["columns"]:
            null_pct = current_stats["columns"][col_name]["null_percentage"]
            if null_pct > 0:
                reasons.append(
                    f"{EMOJI['red']} CRITICAL: {col_name} has {null_pct}% nulls (must be 0%)"
                )
                flagged_columns.append(col_name)
    
    # If we have previous stats, check changes
    if previous_stats and comparison:
        # Check row count change
        row_pct_change = comparison["row_count"]["pct_change"]
        row_pct_change_abs = abs(row_pct_change)
        
        if row_pct_change_abs > max_row_change:
            emoji = EMOJI["red"] if row_pct_change < 0 else EMOJI["amber"]
            reasons.append(
                f"{emoji} Row count changed by {row_pct_change:+.2f}% "
                f"(threshold: ±{max_row_change}%)"
            )
        
        # Check each column
        for col_name, col_comparison in comparison["columns"].items():
            if col_comparison.get("status") == "compared":
                prev_null = previous_stats["columns"].get(col_name, {}).get("null_count", 0)
                curr_null = current_stats["columns"].get(col_name, {}).get("null_count", 0)
                null_diff = curr_null - prev_null
                null_pct_diff = col_comparison["null_pct"]["diff"]
                
                # Check for breach conditions (matching on-prem alert.py logic)
                reason_code = None
                
                # Condition 1: Previous was 0, now non-zero
                if prev_null == 0 and curr_null > 0:
                    reason_code = "prev_zero_to_nonzero"
                    reasons.append(
                        f"{EMOJI['red']} {col_name}: Nulls went from 0 to {curr_null:,}"
                    )
                    flagged_columns.append(col_name)
                
                # Condition 2: Was non-zero, dropped to 0
                elif prev_null > 0 and curr_null == 0:
                    reason_code = "drop_to_zero"
                    # This might be good, log as info
                    logger.info(f"{col_name}: Nulls dropped from {prev_null:,} to 0")
                
                # Condition 3: Absolute count exceeds threshold
                elif abs(null_diff) >= abs_count_cutoff:
                    reason_code = "abs_count_exceeds"
                    emoji = EMOJI["red"] if null_diff > 0 else EMOJI["green"]
                    reasons.append(
                        f"{emoji} {col_name}: Null count changed by {null_diff:+,} "
                        f"(threshold: ±{abs_count_cutoff:,})"
                    )
                    flagged_columns.append(col_name)
                
                # Condition 4: Relative % change exceeds threshold
                elif prev_null > 0:
                    pct_change = ((curr_null - prev_null) / prev_null) * 100
                    if abs(pct_change) >= pct_cutoff:
                        reason_code = "relative_pct_exceeds"
                        emoji = EMOJI["red"] if pct_change > 0 else EMOJI["green"]
                        reasons.append(
                            f"{emoji} {col_name}: Null count changed by {pct_change:+.1f}% "
                            f"({prev_null:,} → {curr_null:,})"
                        )
                        flagged_columns.append(col_name)
                
                # Condition 5: Absolute percentage point change
                if abs(null_pct_diff) >= abs_pct_point_cutoff:
                    if reason_code is None:  # Don't double-report
                        reason_code = "abs_pct_points_exceeds"
                        emoji = EMOJI["red"] if null_pct_diff > 0 else EMOJI["green"]
                        reasons.append(
                            f"{emoji} {col_name}: Null % changed by {null_pct_diff:+.1f} points "
                            f"({col_comparison['null_pct']['previous']:.1f}% → {col_comparison['null_pct']['current']:.1f}%)"
                        )
                        flagged_columns.append(col_name)
            
            elif col_comparison.get("status") == "removed":
                reasons.append(f"{EMOJI['red']} Column {col_name} was removed from output")
                flagged_columns.append(col_name)
    
    passed = len(reasons) == 0
    
    if passed:
        logger.info(f"{EMOJI['pass']} All validation checks PASSED")
    else:
        logger.warning(f"{EMOJI['fail']} Validation FAILED with {len(reasons)} issue(s)")
        for reason in reasons:
            logger.warning(f"  {reason}")
    
    return ValidationResult(
        passed=passed,
        reasons=reasons,
        current_stats=current_stats,
        previous_stats=previous_stats,
        comparison=comparison
    )


def validate_output(
    df: DataFrame,
    stats_bucket: str,
    current_month: str,
    columns_to_check: List[str] = None,
    thresholds: Dict = None,
    critical_columns: List[str] = None
) -> ValidationResult:
    """
    Main function to validate DataFrame output.
    
    This is the primary function called from main_emr.py.
    
    Args:
        df: DataFrame to validate
        stats_bucket: S3 bucket for storing/loading stats
        current_month: Current month in YYYYMM format
        columns_to_check: Optional list of columns to validate
        thresholds: Optional custom thresholds
        critical_columns: Optional list of columns that must have 0% nulls
    
    Returns:
        ValidationResult with pass/fail status and details
    """
    if thresholds is None:
        thresholds = DEFAULT_THRESHOLDS
    
    logger.info(f"Starting output validation for {current_month}")
    
    # 1. Compute current stats
    current_stats = compute_column_stats(df, columns_to_check)
    
    # 2. Load previous month stats
    previous_month = get_previous_month(current_month)
    previous_stats = load_previous_stats(stats_bucket, previous_month)
    
    # 3. Compare if previous exists
    comparison = None
    if previous_stats:
        comparison = compare_stats(current_stats, previous_stats)
        
        # 4. Add change flags (matches on-prem add_change_flags)
        comparison = add_change_flags(
            comparison,
            pct_cutoff=thresholds.get("pct_cutoff", 10.0),
            abs_count_cutoff=thresholds.get("abs_count_cutoff", 1000000),
            abs_pct_point_cutoff=thresholds.get("abs_pct_point_cutoff", 10.0)
        )
        
        logger.info("Comparison with previous month completed")
    else:
        logger.info("No previous stats - skipping comparison (first run)")
    
    # 5. Validate thresholds
    result = validate_thresholds(
        current_stats,
        previous_stats,
        comparison,
        thresholds,
        critical_columns
    )
    
    # 6. Save current stats if validation passed
    if result.passed:
        save_stats(current_stats, stats_bucket, current_month)
        logger.info("Current stats saved to S3")
    
    return result


def format_validation_email(result: ValidationResult, current_month: str, output_path: str = None) -> Dict:
    """
    Format validation result for email.
    
    Returns:
        Dictionary with subject and body for email
    """
    if result.passed:
        subject = f"✅ Digital Taxonomy {current_month} - Validation Passed"
        
        body_lines = [
            f"Digital Taxonomy for {current_month} has passed all validation checks.",
            "",
            f"📊 Summary:",
            f"  • Total Rows: {result.current_stats['total_rows']:,}",
        ]
        
        if output_path:
            body_lines.extend([
                "",
                f"📁 Output File:",
                f"  {output_path}",
            ])
        
        if result.comparison:
            row_change = result.comparison["row_count"]["pct_change"]
            body_lines.extend([
                "",
                f"📈 Comparison with Previous Month:",
                f"  • Row count change: {row_change:+.2f}%",
            ])
        else:
            body_lines.extend([
                "",
                "ℹ️ Note: First run - no previous month to compare.",
            ])
        
        body = "\n".join(body_lines)
        
    else:
        subject = f"❌ Digital Taxonomy {current_month} - VALIDATION FAILED"
        
        body_lines = [
            f"⚠️ Digital Taxonomy for {current_month} has FAILED validation.",
            "",
            "❌ FILE NOT DELIVERED TO CLIENT",
            "",
            "Reason(s):",
        ]
        
        for i, reason in enumerate(result.reasons, 1):
            body_lines.append(f"  {i}. {reason}")
        
        body_lines.extend([
            "",
            f"📊 Current Stats:",
            f"  • Total Rows: {result.current_stats['total_rows']:,}",
            "",
            "Action Required: Investigate source data and re-run.",
        ])
        
        body = "\n".join(body_lines)
    
    return {
        "subject": subject,
        "body": body,
        "passed": result.passed
    }
