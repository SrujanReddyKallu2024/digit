"""
Script Name: process_file_F35_mosaic_emr.py
Description: EMR-compatible version of process_file_F35_mosaic for processing F35 mosaic data.
             This version is designed to run with S3 paths via EMR Serverless.
Date: July 28, 2025
"""

# ----------------------------------------------------------------------
# STANDARD IMPORTS
# ----------------------------------------------------------------------

import json
import sys
import datetime
import argparse
import logging
from pyspark.sql import SparkSession, DataFrame
import pyspark.sql.functions as F
from timeit import default_timer as timer

# Configure root logger
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

logger = logging.getLogger(__name__)

# ----------------------------------------------------------------------
# SCRIPT CONFIGURATION
# ----------------------------------------------------------------------

SCRIPT_CODE = "F35_MOSAIC"

# ----------------------------------------------------------------------
# ARGUMENT PARSING
# ----------------------------------------------------------------------


def create_parser():
    """Create argument parser for the script."""
    parser = argparse.ArgumentParser(description="Process 20ci data for EMR")

    parser.add_argument(
        "--input_path", type=str, required=True, help="S3 path to files containing F35 mosaic data"
    )
    parser.add_argument("--output_path", type=str, required=True, help="S3 path for output data")
    parser.add_argument(
        "--delimiter_config",
        type=str,
        required=False,
        help="JSON string containing delimiter configuration",
    )
    return parser


def get_delimiter_for_file(file_key: str, delimiter_config: dict = None) -> str:
    """
    Get the delimiter for a specific file type.

    Args:
        file_key: Key identifying the file type
        delimiter_config: Delimiter configuration dictionary

    Returns:
        Delimiter to use for the file (defaults to "|")
    """

    return delimiter_config.get(file_key, "|")


# ----------------------------------------------------------------------
# MAIN PROCESSING FUNCTION
# ----------------------------------------------------------------------


def process_data(input_df: DataFrame) -> DataFrame:
    """
    Main data processing logic following the pattern of the original script.

    Args:
        input_df (DataFrame): Input DataFrame containing F35 mosaic data.

    Returns:
        Processed DataFrame
    """
    start_time = timer()

    logger.info("Starting F35 mosaic processing")

    try:

        # Derive group and type columns
        logger.info("Deriving group and type columns")
        output_df = input_df.select(
            "cb_key_db_person",
            F.substring(F.col("p_mosaic_uk8_type"), 1, 1).alias("p_mosaic_8_uk_group"),
            F.substring(F.col("p_mosaic_uk8_type"), 2, 2).alias("mosaic_uk_8_type_for_matching"),
            F.substring(F.col("p_mosaic_fin_type"), 1, 1).alias("p_mosaic_fin_group"),
            F.substring(F.col("p_mosaic_fin_type"), 2, 2).alias("mosaic_fin_type_for_matching"),
        )

        final_count = output_df.count()
        logger.info(f"Final processed count: {final_count:,} rows")

        # No local file cleanup needed; file read directly from S3

        end_time = timer()
        processing_time = str(datetime.timedelta(seconds=round(end_time - start_time, 0)))
        logger.info(f"F35 mosaic processing completed successfully in {processing_time}")

        return output_df

    except Exception as e:
        logger.error(f"Error processing F35 mosaic data: {str(e)}")
        raise


# ----------------------------------------------------------------------
# MAIN FUNCTION
# ----------------------------------------------------------------------


def read_input_df(
    name: str, path: str, spark: SparkSession, header: bool = True, delimiter: str = ","
) -> DataFrame:
    """Read input DataFrame from S3 path.

    Args:
        name: Name of the input data (for logging)
        path: S3 path to the input data
        spark: SparkSession object
        header: Boolean indicating if the input file has a header
        delimiter: Delimiter used in the input file

    Returns:
        DataFrame read from the specified S3 path
    """
    header = "true" if header else "false"
    try:
        logger.info(f"Reading {name} from S3: {path}")
        input_df = spark.read.option("header", header).option("sep", delimiter).csv(path)
    except FileNotFoundError as fnf_error:
        logger.error(f"{name} - {path} not found: {str(fnf_error)}")
        raise
    except Exception as e:
        logger.error(f"Error reading {name}: {str(e)}")
        raise
    input_count = input_df.count()
    logger.info(f"{name} count: {input_count:,} rows")
    return input_df


def main():
    """Main entry point for the script."""
    start_time = timer()

    # Parse arguments
    parser = create_parser()
    args, unknown = parser.parse_known_args()

    if unknown:
        logger.warning(f"Unknown arguments: {unknown}")

    # Parse delimiter configuration
    delimiter_config = {}
    if hasattr(args, "delimiter_config") and args.delimiter_config:
        try:
            delimiter_config = json.loads(args.delimiter_config)
            logger.info(f"Using delimiter configuration: {delimiter_config}")
        except Exception as e:
            logger.warning(f"Failed to parse delimiter config: {e}. Using defaults.")

    # Initialize Spark Session
    spark = (
        SparkSession.builder.appName("Process 20ci EMR")
        .config("spark.sql.adaptive.enabled", "true")
        .config("spark.sql.adaptive.coalescePartitions.enabled", "true")
        .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
        .getOrCreate()
    )

    spark.sparkContext.setLogLevel("WARN")

    logger.info("Starting Process F35 mosaic EMR job")

    try:
        # Read input data from S3
        delimiter = get_delimiter_for_file("f35_mosaic_input", delimiter_config or {})
        f35_mosaic_input_df = read_input_df(
            "F35 Mosaic Input", args.input_path, spark, delimiter=delimiter
        )

        # Process the data
        output_df = process_data(
            f35_mosaic_input_df,
        )

        # Write output to S3
        logger.info(f"Writing output to S3: {args.output_path}")
        output_df.write.mode("overwrite").parquet(args.output_path)

        # Verify output
        output_df = spark.read.parquet(args.output_path)
        output_count = output_df.count()
        logger.info(f"Verified output count: {output_count:,} rows")

        # Calculate total time
        end_time = timer()
        total_time = str(datetime.timedelta(seconds=round(end_time - start_time, 0)))

        logger.info(f"Job completed successfully in {total_time}")
        logger.info("Process F35 mosaic EMR job finished")

        # Exit successfully
        sys.exit(0)

    except Exception as e:
        logger.error(f"Process failed: {type(e).__name__}: {str(e)}", exc_info=True)
        sys.exit(1)

    finally:
        if spark:
            spark.stop()


if __name__ == "__main__":
    main()
