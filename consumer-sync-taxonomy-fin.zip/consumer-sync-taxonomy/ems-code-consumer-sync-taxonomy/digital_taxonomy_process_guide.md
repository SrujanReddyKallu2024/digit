# Digital Taxonomy - Complete Documentation

## Schedule

| Property | Value |
|----------|-------|
| **DAG Name** | `digital_taxonomy_processing` |
| **Schedule** | 12th of every month at 8:00 AM UTC |
| **Cron Expression** | `0 8 12 * *` |
| **Next Run Examples** | Dec 12, Jan 12, Feb 12, etc. |
| **Manual Trigger** | Available in Airflow UI anytime |

---

## Workflow Diagram

---

## All File Paths - Complete Reference

### Input Files (22 Total)

Files are read from **three different source locations** based on where they originate:

#### Data Office Files (10 files)
**Location:** `s3://[source-bucket]/internal/data_office/`

| # | File Name Pattern | Delimiter | Purpose |
|---|-------------------|-----------|---------|
| 1 | `F35_*_P50_consview.csv` | Pipe `\|` | Main consumer data (PRIMARY) |
| 2 | `F15_*_ChannelView_Prospectview.csv` | Pipe `\|` | Channel view data |
| 3 | `F45*.cbaf_utility_1.csv` | Comma `,` | CBAF utility data |
| 4 | `A40_*_address.csv` | Pipe `\|` | MPS Family address data |
| 5 | `A67_*_cbaf_address.csv` | Pipe `\|` | MPS Individual CBAF address |
| 6 | `A16_*_cbaf_utility.csv` | Pipe `\|` | NMR CBAF utility |
| 7 | `A08_*_abs_master.csv` | Pipe `\|` | ABS movers data |
| 8 | `A01_*_emsf_master.csv` | Pipe `\|` | EMSF master data |
| 9 | `A44_*_cbaf_address.csv` | Pipe `\|` | Mortascreen Plus data |
| 10 | `TwentyCI_Experian_Digital_*` | Tab `\t` | TwentyCI digital data |

#### Analytics Files (10 files)
**Location:** `s3://[source-bucket]/internal/analytics/`

| # | File Name Pattern | Delimiter | Purpose |
|---|-------------------|-----------|---------|
| 1 | `R45*.PostcodeDirectory*.csv` | Comma `,` | Postcode directory |
| 2 | `YouGov*.csv` | Comma `,` | YouGov survey data |
| 3 | `F35_MosaicSuite_*.txt` | Pipe `\|` | Mosaic suite segmentation |
| 4 | `ADHOC_SUPPRESSION.csv` | Comma `,` | Adhoc suppression list |
| 5 | `Boots_Model_Segments_lookup.xlsx` | N/A (Excel) | Boots model lookup |
| 6 | `Core_Propensities_Millitiles_UK*.txt` | Pipe `\|` | Core propensities millitiles |
| 7 | `Core_Propensities_FlagCutoffs_*.txt` | Pipe `\|` | Core propensities cutoffs |
| 8 | `Standard_Audiences*_millitiles.csv` | Comma `,` | Standard audiences millitiles |
| 9 | `Standard_Audiences*_cutoffs.csv` | Comma `,` | Standard audiences cutoffs |
| 10 | `mc_hh_Lookup*.csv` | Comma `,` | Household lookup |

#### Client Delivery Files (2 files)
**Location:** `s3://[client-delivery-bucket]/misc/`

| # | File Name Pattern | Delimiter | Purpose |
|---|-------------------|-----------|---------|
| 1 | `Digital_Taxonomy_Master_Layout_created_*.xlsx` | N/A (Excel) | Auto segments config |
| 2 | `UPRN_HH_Lookup.csv` | Comma `,` | 20CI UPRN household lookup |

---

### How Source Routing Works

The DAG automatically routes each file to its correct source location using `get_source_routing_config()`:

```python
# To change a file's source location, update this config in digital_taxonomy_dag.py:
def get_source_routing_config():
    return {
        "f35_input": "data_office",      # → source-bucket/internal/data_office
        "yougov_input": "analytics",     # → source-bucket/internal/analytics
        "auto_segments_excel": "client_delivery",  # → client-delivery-bucket/misc
        ...
    }
```

**Key Points:**
- ✅ Files are automatically routed based on their origin
- ✅ Easy to modify - just change the routing value in the config
- ✅ Environment-aware (works for UAT and PRD)

---

### Configuration Files (4 files)

**Configs are in CODE bucket** (deployed with DAG)

| File Name | Full S3 Path | Type | Purpose |
|-----------|--------------|------|---------|
| `cv_vars.json` | `s3://[code-bucket]/dags/ems-code-consumer-sync-taxonomy/config_aws/cv_vars.json` | JSON | Column variables configuration |
| `final_vars.json` | `s3://[code-bucket]/dags/ems-code-consumer-sync-taxonomy/config_aws/final_vars.json` | JSON | Final output columns configuration |
| `taxonomy.xlsx` | `s3://[code-bucket]/dags/ems-code-consumer-sync-taxonomy/config_aws/taxonomy.xlsx` | Excel | Taxonomy rules and column mappings |
| `config.json` | `s3://[code-bucket]/dags/ems-code-consumer-sync-taxonomy/config_aws/config.json` | JSON | Join configuration for multi-join |

**Example:**  
`s3://eec-aws-uk-ms-consumersync-uat-code-bucket/dags/ems-code-consumer-sync-taxonomy/config_aws/cv_vars.json`

---

### Interim Processing Outputs (11 files)

**Date Folder Format:** `YYYY-MM` (e.g., `2024-11` for November 2024)

| # | File Name | Full S3 Path | Format | Source Input |
|---|-----------|--------------|--------|--------------|
| 1 | `f15_processed.parquet` | `s3://[interim-bucket]/internal/taxonomy/taxonomy/processed/YYYY-MM/f15_processed.parquet` | Parquet | F15 input |
| 2 | `f45_processed.parquet` | `s3://[interim-bucket]/internal/taxonomy/taxonomy/processed/YYYY-MM/f45_processed.parquet` | Parquet | F45 input |
| 3 | `r45_processed.parquet` | `s3://[interim-bucket]/internal/taxonomy/taxonomy/processed/YYYY-MM/r45_processed.parquet` | Parquet | R45 input |
| 4 | `auto_segments_processed.parquet` | `s3://[interim-bucket]/internal/taxonomy/taxonomy/processed/YYYY-MM/auto_segments_processed.parquet` | Parquet | Auto segments Excel |
| 5 | `boots_segments_processed.parquet` | `s3://[interim-bucket]/internal/taxonomy/taxonomy/processed/YYYY-MM/boots_segments_processed.parquet` | Parquet | F35 + Boots lookup |
| 6 | `propensities_processed.parquet` | `s3://[interim-bucket]/internal/taxonomy/taxonomy/processed/YYYY-MM/propensities_processed.parquet` | Parquet | Propensities + F35 + F45 |
| 7 | `yougov_processed.parquet` | `s3://[interim-bucket]/internal/taxonomy/taxonomy/processed/YYYY-MM/yougov_processed.parquet` | Parquet | YouGov input |
| 8 | `20ci_processed.parquet` | `s3://[interim-bucket]/internal/taxonomy/taxonomy/processed/YYYY-MM/20ci_processed.parquet` | Parquet | 20CI input + lookup |
| 9 | `f35_mosaic_processed.parquet` | `s3://[interim-bucket]/internal/taxonomy/taxonomy/processed/YYYY-MM/f35_mosaic_processed.parquet` | Parquet | F35 Mosaic input |
| 10 | `Propensities_millitiles_flagged_HHkey/` | `s3://[interim-bucket]/internal/taxonomy/taxonomy/processed/YYYY-MM/Propensities_millitiles_flagged_HHkey/` | Parquet Dir | Core propensities |
| 11 | `ConsumerDynamics_millitiles_flagged_HHkey/` | `s3://[interim-bucket]/internal/taxonomy/taxonomy/processed/YYYY-MM/ConsumerDynamics_millitiles_flagged_HHkey/` | Parquet Dir | Standard audiences |

**Example for November 2024:**  
`s3://[interim-bucket]/internal/taxonomy/taxonomy/processed/2024-11/f15_processed.parquet`

---

### Final Output Paths (2 locations)

**No date folders** - Files named with month only

| Location | Full S3 Path |
|----------|--------------|
| **Source Bucket (Internal Archive)** | `s3://[source-bucket]/internal/taxonomy/digital_taxonomy_YYYYMM.txt` |
| **Output Bucket (Client Delivery)** | `s3://[output-bucket]/to_client_delivery/digital_taxonomy_YYYYMM.txt` |

**Example for November 2024:**
- Source: `s3://eec-aws-uk-ms-consumersync-uat-source-bucket/internal/taxonomy/digital_taxonomy_202411.txt`
- Output: `s3://eec-aws-uk-ms-consumersync-uat-output-bucket/to_client_delivery/digital_taxonomy_202411.txt`

**File Format Details:**
- **Delimiter:** Pipe `|`
- **Header:** First row contains column names
- **Encoding:** UTF-8
- **Structure:** Single text file (coalesced from partitions)

> [!IMPORTANT]
> **Special Processing Step: Part File Renaming**
> 
> Spark writes output as folders containing `part-00000` files. After the main processing completes, the [rename_output_files](file:///c:/Users/c13505e/OneDrive%20-%20EXPERIAN%20SERVICES%20CORP/ems-code-consumer-sync-taxonomy/src/dags/digital_taxonomy_dag.py#1106-1186) task automatically processes **BOTH output locations**:
> 1. Finds the `part-00000` file in the Spark output folder
> 2. Copies it to the final `.txt` file location (both source and output buckets)
> 3. Deletes the old folder with part files
> 4. **Result:** Clean single `.txt` files instead of folders
> 
> This ensures the final output is a single, properly named `.txt` file that's ready for client delivery.
> 
> **Example Transformation (applied to both locations):**
> - Spark creates: `s3://.../internal/taxonomy/digital_taxonomy_202411.txt/part-00000`
> - Task renames to: `s3://.../internal/taxonomy/digital_taxonomy_202411.txt`
> - Old folder deleted automatically

---

## Deployment Instructions

### Prerequisites
- Access to Airflow environment
- Access to S3 buckets (source, interim, output, code, logs, stats)
- Permissions to deploy code to code bucket
- Git repository access

### Step-by-Step Deployment

#### 1. **Prepare Your Changes**

Make changes to any of these files in your local repository:
- DAG file: [src/dags/digital_taxonomy_dag.py](file:///c:/Users/c13505e/OneDrive%20-%20EXPERIAN%20SERVICES%20CORP/ems-code-consumer-sync-taxonomy/src/dags/digital_taxonomy_dag.py)
- Main script: [src/spark/main_emr.py](file:///c:/Users/c13505e/OneDrive%20-%20EXPERIAN%20SERVICES%20CORP/ems-code-consumer-sync-taxonomy/src/spark/main_emr.py)
- Processing scripts: `src/spark/process_file_*.py`
- Stats script: [src/spark/get_stats_emr.py](file:///c:/Users/c13505e/OneDrive%20-%20EXPERIAN%20SERVICES%20CORP/ems-code-consumer-sync-taxonomy/src/spark/get_stats_emr.py)

#### 2. **Test Locally (Optional)**

```bash
# Run Python syntax check
python -m py_compile src/dags/digital_taxonomy_dag.py
python -m py_compile src/spark/main_emr.py

# Run linting
pylint src/dags/digital_taxonomy_dag.py
pylint src/spark/main_emr.py
```

#### 3. **Commit Changes to Git**

```bash
# Add your changes
git add src/dags/digital_taxonomy_dag.py
git add src/spark/main_emr.py
git add src/spark/process_file_*.py

# Commit with clear message
git commit -m "Update digital taxonomy processing - [brief description]"

# Push to repository
git push origin main
```

#### 4. **Deploy to UAT/Production**

**Follow the Standard Deployment Pattern:**

Open Command Prompt and run these commands exactly:

**For UAT Deployment:**
```batch
cd c:\Users\c13505e\OneDrive - EXPERIAN SERVICES CORP\ems-code-consumer-sync-taxonomy

set account=uat
set repo=ems-code-consumer-sync-taxonomy

REM Step 1: Create zip of spark files
call python -m zipfile -c %repo%.zip %repo%\src\spark\.

REM Step 2: Upload zip to code bucket
call aws --profile %account% s3 cp %repo%.zip s3://eec-aws-uk-ms-consumersync-%account%-code-bucket/zipped/%repo%.zip

REM Step 3: Upload spark scripts
call aws --profile %account% s3 cp --recursive %repo%/src/spark s3://eec-aws-uk-ms-consumersync-%account%-code-bucket/repos/%repo%/spark

REM Step 4: Upload DAGs
call aws --profile %account% s3 cp --recursive %repo%/src/dags/ s3://eec-aws-uk-ms-consumersync-%account%-code-bucket/dags/%repo%/
```

**For Production Deployment:**
```batch
cd c:\Users\c13505e\OneDrive - EXPERIAN SERVICES CORP\ems-code-consumer-sync-taxonomy

set account=prod
set repo=ems-code-consumer-sync-taxonomy

REM Step 1: Create zip of spark files
call python -m zipfile -c %repo%.zip %repo%\src\spark\.

REM Step 2: Upload zip to code bucket
call aws --profile %account% s3 cp %repo%.zip s3://eec-aws-uk-ms-consumersync-%account%-code-bucket/zipped/%repo%.zip

REM Step 3: Upload spark scripts
call aws --profile %account% s3 cp --recursive %repo%/src/spark s3://eec-aws-uk-ms-consumersync-%account%-code-bucket/repos/%repo%/spark

REM Step 4: Upload DAGs
call aws --profile %account% s3 cp --recursive %repo%/src/dags/ s3://eec-aws-uk-ms-consumersync-%account%-code-bucket/dags/%repo%/
```

**What Gets Deployed:**
- Zip file: `s3://eec-aws-uk-ms-consumersync-[account]-code-bucket/zipped/ems-code-consumer-sync-taxonomy.zip`
- Spark scripts: `s3://eec-aws-uk-ms-consumersync-[account]-code-bucket/repos/ems-code-consumer-sync-taxonomy/spark/`
- DAGs: `s3://eec-aws-uk-ms-consumersync-[account]-code-bucket/dags/ems-code-consumer-sync-taxonomy/`

#### 5. **Verify Deployment in Airflow**

1. **Open Airflow UI**
2. **Find DAG:** Search for `digital_taxonomy_processing`
3. **Check DAG Status:**
   - Should show as "Active" (not paused)
   - No syntax errors
   - Schedule shows: `0 8 12 * *` (12th of every month at 8 AM UTC)

4. **Review DAG Details:**
   - Click on the DAG name
   - Check "Code" tab to verify your changes are there
   - Check "Graph" view to see all tasks

#### 6. **Test the Deployment (Recommended)**

**Option A: Trigger Manual Test Run**
1. Go to Airflow UI
2. Click on DAG `digital_taxonomy_processing`
3. Click "Trigger DAG" button (play icon)
4. Configure parameters if needed:
   - `email_to`: Your test email address
5. Click "Trigger"
6. Monitor execution in "Graph" or "Grid" view

**Option B: Test with Custom Email**
```json
# In Airflow UI, trigger with config:
{
  "email_to": "your.email@experian.com"
}
```

#### 7. **Monitor First Run**

Watch these in Airflow UI:
- ✅ All input files found (check_inputs task)
- ✅ Stats collection completes (20 tasks)
- ✅ Processing tasks complete (9 tasks)
- ✅ Main processing completes
- ✅ Final output created in both S3 locations

**Check Logs:**
- Task logs in Airflow
- EMR logs in `s3://eec-aws-uk-ms-consumersync-[account]-logs-bucket/spark-logs/`

#### 8. **Verify Outputs**

```bash
# Check final outputs exist
aws --profile uat s3 ls s3://eec-aws-uk-ms-consumersync-uat-source-bucket/data_office/
aws --profile uat s3 ls s3://eec-aws-uk-ms-consumersync-uat-output-bucket/to_client_delivery/

# Check interim outputs
aws --profile uat s3 ls s3://eec-aws-uk-ms-consumersync-uat-interim-bucket/internal/taxonomy/taxonomy/processed/2024-11/

# Check stats
aws --profile uat s3 ls s3://eec-aws-uk-ms-consumersync-uat-stats-bucket/get_stats/2024-11-25/
```

#### 9. **Rollback (if needed)**

If deployment fails:

```batch
# Restore previous version from Git
git checkout HEAD~1 src/dags/digital_taxonomy_dag.py
git checkout HEAD~1 src/spark/main_emr.py

# Redeploy using the script
deploy_taxonomy.bat uat
```

### Deployment Checklist

- [ ] Code changes tested locally
- [ ] Changes committed to Git with clear message
- [ ] DAG file deployed to Airflow
- [ ] Spark scripts uploaded to code bucket
- [ ] DAG appears in Airflow UI without errors
- [ ] Schedule is correct: 12th of every month at 8 AM UTC
- [ ] Manual test run triggered
- [ ] All tasks complete successfully
- [ ] Output files created in both S3 locations
- [ ] Email alerts received
- [ ] Stats files generated
- [ ] Team notified of deployment

### Common Deployment Issues

| Issue | Solution |
|-------|----------|
| **DAG not appearing in Airflow** | Check DAG syntax, wait 1-2 mins for sync, check Airflow logs |
| **Import errors in DAG** | Verify shared libraries in code bucket, check import paths |
| **EMR job fails to start** | Check execution role permissions, verify code bucket paths |
| **File not found errors** | Verify S3 paths in code bucket, check file names match |
| **Permission denied** | Check IAM roles for S3 and EMR permissions |
| **Old code still running** | Clear Airflow DAG cache, restart Airflow scheduler |

### Configuration Changes (No Code Deployment Needed)

Some changes don't require code deployment:

**Input File Paths** - Update in DAG parameters
**Email Recipients** - Update DAG param `email_to`
**Schedule** - Modify `schedule_interval` in DAG definition

For these, just update the DAG file and redeploy to Airflow.

---

### Stats Collection Paths

All statistics are stored in the **stats bucket** with weekly folders.

| Path Type | Full S3 Path | Description |
|-----------|--------------|-------------|
| **Weekly Folder** | `s3://[stats-bucket]/get_stats/YYYY-MM-DD/` | Weekly folder (Monday date as base) |
| **Daily Input Stats** | `s3://[stats-bucket]/get_stats/YYYY-MM-DD/input_stats_YYYY-MM-DD.json` | Individual file statistics |
| **Alert Data** | `s3://[stats-bucket]/get_stats/YYYY-MM-DD/alert_data_YYYY-MM-DD.json` | Alert information if triggered |
| **Consolidated Stats** | `s3://[stats-bucket]/get_stats/YYYY-MM-DD/consolidated_stats_YYYY-MM-DD.csv` | All stats in CSV format |

**Example for Nov 27, 2024 (week starting Nov 25):**
- Weekly folder: `s3://[stats-bucket]/get_stats/2024-11-25/`
- Stats file: `s3://[stats-bucket]/get_stats/2024-11-25/input_stats_2024-11-27.json`

**Stats Collected for Each File:**
- Row count
- Column count
- File size
- Processing timestamp
- Data quality alerts (if any)

---

### EMR Spark Log Paths

All EMR Serverless job logs are stored in the **logs bucket**.

| Log Category | Full S3 Path | Purpose |
|--------------|--------------|---------|
| **F35 Stats** | `s3://[logs-bucket]/spark-logs/digital_taxonomy_f35_stats/` | F35 statistics collection logs |
| **F15 Stats** | `s3://[logs-bucket]/spark-logs/digital_taxonomy_f15_stats/` | F15 statistics collection logs |
| **F45 Stats** | `s3://[logs-bucket]/spark-logs/digital_taxonomy_f45_stats/` | F45 statistics collection logs |
| **R45 Stats** | `s3://[logs-bucket]/spark-logs/digital_taxonomy_r45_stats/` | R45 statistics collection logs |
| **YouGov Stats** | `s3://[logs-bucket]/spark-logs/digital_taxonomy_yougov_stats/` | YouGov statistics collection logs |
| **20CI Stats** | `s3://[logs-bucket]/spark-logs/digital_taxonomy_20ci_stats/` | 20CI statistics collection logs |
| **Other Stats** | `s3://[logs-bucket]/spark-logs/digital_taxonomy_[filename]_stats/` | Stats for A40, A67, A16, A08, A01, A44, etc. |
| **F15 Processing** | `s3://[logs-bucket]/spark-logs/digital_taxonomy_f15/` | F15 processing logs |
| **F45 Processing** | `s3://[logs-bucket]/spark-logs/digital_taxonomy_f45/` | F45 processing logs |
| **R45 Processing** | `s3://[logs-bucket]/spark-logs/digital_taxonomy_r45/` | R45 processing logs |
| **Auto Segments** | `s3://[logs-bucket]/spark-logs/digital_taxonomy_autosegments/` | Auto segments processing logs |
| **Boots Segments** | `s3://[logs-bucket]/spark-logs/digital_taxonomy_bootssegments/` | Boots segments processing logs |
| **Propensities** | `s3://[logs-bucket]/spark-logs/digital_taxonomy_propensities/` | Propensities processing logs |
| **YouGov Processing** | `s3://[logs-bucket]/spark-logs/digital_taxonomy_yougov/` | YouGov processing logs |
| **20CI Processing** | `s3://[logs-bucket]/spark-logs/digital_taxonomy_20ci/` | 20CI processing logs |
| **F35 Mosaic** | `s3://[logs-bucket]/spark-logs/digital_taxonomy_f35mosaic/` | F35 Mosaic processing logs |
| **Main Processing** | `s3://[logs-bucket]/spark-logs/digital_taxonomy_main/` | Main assembly processing logs |

---

### Code & Dependency Paths

All Python scripts and dependencies are stored in the **code bucket**.

| Code Type | Full S3 Path | Description |
|-----------|--------------|-------------|
| **Shared Code** | `s3://[code-bucket]/zipped/ems-code-shared.zip` | Shared utilities and libraries |
| **OpenPyXL Package** | `s3://[code-bucket]/packages/openpyxl.zip` | Excel file handling library |
| **FSSpec Package** | `s3://[code-bucket]/packages/fsspec.zip` | Filesystem interface library |
| **S3FS Package** | `s3://[code-bucket]/packages/s3fs.zip` | S3 filesystem library |
| **Stats Script** | `s3://[code-bucket]/repos/ems-code-consumer-sync-taxonomy/spark/get_stats_emr.py` | Statistics collection script |
| **F15 Processing** | `s3://[code-bucket]/repos/ems-code-consumer-sync-taxonomy/spark/process_file_F15_emr.py` | F15 processing script |
| **F45 Processing** | `s3://[code-bucket]/repos/ems-code-consumer-sync-taxonomy/spark/process_file_F45_emr.py` | F45 processing script |
| **R45 Processing** | `s3://[code-bucket]/repos/ems-code-consumer-sync-taxonomy/spark/process_file_R45_emr.py` | R45 processing script |
| **Auto Segments** | `s3://[code-bucket]/repos/ems-code-consumer-sync-taxonomy/spark/process_file_auto_segments_emr.py` | Auto segments processing |
| **Boots Segments** | `s3://[code-bucket]/repos/ems-code-consumer-sync-taxonomy/spark/process_file_boots_segments_emr.py` | Boots segments processing |
| **Propensities** | `s3://[code-bucket]/repos/ems-code-consumer-sync-taxonomy/spark/process_file_propensities_segments_emr.py` | Propensities processing |
| **YouGov Processing** | `s3://[code-bucket]/repos/ems-code-consumer-sync-taxonomy/spark/process_file_yougov_emr.py` | YouGov processing script |
| **20CI Processing** | `s3://[code-bucket]/repos/ems-code-consumer-sync-taxonomy/spark/process_file_20ci_emr.py` | 20CI processing script |
| **F35 Mosaic** | `s3://[code-bucket]/repos/ems-code-consumer-sync-taxonomy/spark/process_file_F35_mosaic_emr.py` | F35 Mosaic processing |
| **Main Processing** | `s3://[code-bucket]/repos/ems-code-consumer-sync-taxonomy/spark/main_emr.py` | Main assembly script |

---

## Email Alerts Configuration

### Email Recipients

Email addresses are configured via **DAG parameters**:

| Configuration | How to Set |
|---------------|------------|
| **Default Recipient** | `kallusrujan.reddy@experian.com` (hardcoded fallback) |
| **Custom Recipient** | Set `email_to` parameter when triggering DAG |
| **Change Default** | Update `email_to` Param in DAG definition (line 142) |

**To Send Emails to Different Address:**
1. Trigger DAG manually
2. Click "Trigger DAG w/ config"
3. Add parameter:
   ```json
   {
     "email_to": "your.email@experian.com"
   }
   ```

### Email Types

#### 1. Input Statistics Email
**Trigger:** After all stats collection completes  
**Subject:** `Digital Taxonomy Input Statistics - YYYY-MM-DD`  
**Content:**
- Date and processing month
- Statistics table for all 22 input files
- Row counts, file sizes
- Any alerts or warnings
- Links to detailed stats in S3

#### 2. Success/Completion Email
**Trigger:** After main processing completes successfully  
**Subject:** `Digital Taxonomy Processing Complete - YYYY-MM-DD`  
**Content:**
- Processing status: ✅ Success
- Processing month
- Input file count
- Output file paths (both locations)
- Total rows in final output
- Processing duration
- Summary statistics

#### 3. Failure Email
**Trigger:** When any task fails  
**Subject:** `*** Digital Taxonomy Processing FAILED *** - YYYY-MM-DD`  
**Content:**
- Processing status: ❌ Failed
- Failed task name(s)
- Processing month
- Error message
- Link to Airflow logs
- Action required message

---

## Processing Steps Breakdown

### Phase 1: Setup (3 tasks)
1. **Create Script Arguments** - Generate all paths, validate buckets
2. **Initialize EMR** - Create EMR Serverless application
3. **Check Inputs** - Verify all 22 files exist

### Phase 2: Statistics Collection (20 tasks)
Each task collects stats from one input file:
- Runs EMR job with `get_stats_emr.py`
- Outputs to stats bucket
- Runs sequentially (one after another)

### Phase 3: File Processing (9 tasks)
Each task processes one component:
- Reads input file(s)
- Applies transformations
- Writes to interim bucket as Parquet
- Runs sequentially

### Phase 4: Main Assembly (1 task)
**Main Processing** ([main_emr.py](file:///c:/Users/c13505e/OneDrive%20-%20EXPERIAN%20SERVICES%20CORP/ems-code-consumer-sync-taxonomy/src/spark/main_emr.py)):
1. Load F35 consumer data
2. Apply quality filters
3. Apply suppressions (6 files)
4. Apply adhoc suppressions
5. Join all 9 processed files
6. Apply taxonomy rules
7. Select final columns
8. Write to 2 output locations

### Phase 5: Cleanup (2 tasks)
1. **Send Completion Email**
2. **Finalize** - Delete EMR application

---

## Bucket Names (Environment Variables)

| Bucket Type | Variable Name | Purpose |
|-------------|---------------|---------|
| **Source** | `source_bucket` | Input files and configs |
| **Interim** | `interim_bucket` | Processed intermediate files |
| **Output** | `output_bucket` | Final output delivery |
| **Code** | `code_bucket` | Python scripts and dependencies |
| **Logs** | `log_bucket` | EMR Spark logs |
| **Stats** | `stats_bucket` | Statistics and alerts |

---
