"""
Script Name: process_file_20ci_emr.py
Description: EMR-compatible version of process_file_20ci for processing 20ci data.
             This version is designed to run with S3 paths via EMR Serverless.
Date: July 28, 2025
"""

# ----------------------------------------------------------------------
# STANDARD IMPORTS
# ----------------------------------------------------------------------

import json
import sys
import datetime
import argparse
import logging
from pyspark.sql import SparkSession, DataFrame
import pyspark.sql.functions as F
from timeit import default_timer as timer

# Configure root logger
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

logger = logging.getLogger(__name__)

# ----------------------------------------------------------------------
# SCRIPT CONFIGURATION
# ----------------------------------------------------------------------

SCRIPT_CODE = "20CI"

# Conditions dictionaries
conditions_trigger = {
    "C000718": "PreMover",
    "C000719": "MoveMaker",
    "C000720": "MovePlanner",
    "C000721": "Mover",
    "C000722": "MoveNestBuilder",
    "C000723": "MoveHomemaker",
}

conditions_tenure = {"C000724": "Rental", "C000725": "Sale"}

# ----------------------------------------------------------------------
# ARGUMENT PARSING
# ----------------------------------------------------------------------


def create_parser():
    """Create argument parser for the script."""
    parser = argparse.ArgumentParser(description="Process 20ci data for EMR")

    parser.add_argument(
        "--input_path_20ci", type=str, required=True, help="S3 path to files containing 20ci data"
    )
    parser.add_argument(
        "--input_path_new_lookup", type=str, required=True, help="S3 path to new lookup file"
    )
    parser.add_argument("--output_path", type=str, required=True, help="S3 path for output data")
    parser.add_argument(
        "--delimiter_config",
        type=str,
        required=False,
        help="JSON string containing delimiter configuration",
    )

    return parser


def get_spark_session(session_name: str = "Process EMR") -> SparkSession:
    """Initialize and return a Spark session.

    Args:
        session_name: Name for the Spark session

    Returns:
        SparkSession object
    """
    spark = None
    try:
        spark = (
            SparkSession.builder.appName(session_name)
            .config("spark.sql.adaptive.enabled", "true")
            .config("spark.sql.adaptive.coalescePartitions.enabled", "true")
            .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
            .getOrCreate()
        )
        spark.sparkContext.setLogLevel("WARN")
        return spark
    except Exception as e:
        logger.error(f"Failed to create Spark session: {str(e)}")
        raise


def get_delimiter_for_file(file_key: str, delimiter_config: dict = None) -> str:
    """
    Get the delimiter for a specific file type.

    Args:
        file_key: Key identifying the file type
        delimiter_config: Delimiter configuration dictionary

    Returns:
        Delimiter to use for the file (defaults to "|")
    """

    return delimiter_config.get(file_key, "|")


# ----------------------------------------------------------------------
# MAIN PROCESSING FUNCTION
# ----------------------------------------------------------------------


def process_data(twenty_ci_df: DataFrame, new_lookup_df: DataFrame) -> DataFrame:
    """
    Main data processing logic following the pattern of the original script.

    Args:
        twenty_ci_input_df: Input DataFrame for 20ci data
        new_lookup_df: Input DataFrame for new lookup data

    Returns:
        Processed DataFrame
    """
    start_time = timer()

    logger.info("Starting 20ci processing")

    try:

        logger.info("Deduplicating new lookup data")
        deduped = new_lookup_df.groupBy("cb_key_household", "AddressBaseUPRN").count()

        # Add condition columns
        logger.info("Adding conditions columns")
        select_list = ["UPRN", "Tenure", "Trigger"]

        for col_name, val in conditions_trigger.items():
            trigger_expr = F.when(F.col("Trigger") == val, F.lit(val)).otherwise(F.lit(""))
            select_list.append(trigger_expr.alias(col_name))

        for col_name, val in conditions_tenure.items():
            tenure_expr = F.when(F.col("Tenure") == val, F.lit(val)).otherwise(F.lit(""))
            select_list.append(tenure_expr.alias(col_name))

        twenty_ci_df = twenty_ci_df.select(*select_list)

        # Join with deduplicated lookup data
        logger.info("Joining 20CI data with deduplicated lookup data")
        join = twenty_ci_df.join(
            deduped, twenty_ci_df["UPRN"] == deduped["AddressBaseUPRN"], "inner"
        )

        # Aggregate by household
        logger.info("Aggregating conditions by household")
        aggs_trigger = [
            F.max(F.col(c)).alias(c)
            for c in [*conditions_trigger.keys(), *conditions_tenure.keys()]
        ]
        output_df = join.groupBy("cb_key_household").agg(*aggs_trigger)

        final_count = output_df.count()
        logger.info(f"Final processed count: {final_count:,} rows")

        # No local file cleanup needed; file read directly from S3

        end_time = timer()
        processing_time = str(datetime.timedelta(seconds=round(end_time - start_time, 0)))
        logger.info(f"20ci processing completed successfully in {processing_time}")

        return output_df

    except Exception as e:
        logger.error(f"Error processing 20ci data: {str(e)}")
        raise


# ----------------------------------------------------------------------
# MAIN FUNCTION
# ----------------------------------------------------------------------


def read_input_df(
    name: str, path: str, spark: SparkSession, header: bool = True, delimiter: str = ","
) -> DataFrame:
    """Read input DataFrame from S3 path.

    Args:
        name: Name of the input data (for logging)
        path: S3 path to the input data
        spark: SparkSession object
        header: Boolean indicating if the input file has a header
        delimiter: Delimiter used in the input file

    Returns:
        DataFrame read from the specified S3 path
    """
    header = "true" if header else "false"
    try:
        logger.info(f"Reading {name} from S3: {path}")
        input_df = spark.read.option("header", header).option("sep", delimiter).csv(path)
    except FileNotFoundError as fnf_error:
        logger.error(f"{name} - {path} not found: {str(fnf_error)}")
        raise
    except Exception as e:
        logger.error(f"Error reading {name}: {str(e)}")
        raise
    input_count = input_df.count()
    logger.info(f"{name} count: {input_count:,} rows")
    return input_df


def main():
    """Main entry point for the script."""
    start_time = timer()

    # Parse arguments
    parser = create_parser()
    args, unknown = parser.parse_known_args()

    if unknown:
        logger.warning(f"Unknown arguments: {unknown}")

    # Parse delimiter configuration
    delimiter_config = {}
    if hasattr(args, "delimiter_config") and args.delimiter_config:
        try:
            delimiter_config = json.loads(args.delimiter_config)
            logger.info(f"Using delimiter configuration: {delimiter_config}")
        except Exception as e:
            logger.warning(f"Failed to parse delimiter config: {e}. Using defaults.")

    # Initialize Spark Session
    spark = get_spark_session("Process 20ci EMR")

    logger.info("Starting Process 20ci EMR job")
    logger.info(f"Input path - 20ci: {args.input_path_20ci}")
    logger.info(f"Input path - new lookup: {args.input_path_new_lookup}")
    logger.info(f"Output path: {args.output_path}")

    try:
        # Read input data from S3
        lookup_delimiter = get_delimiter_for_file("20ci_new_lookup", delimiter_config or {})
        new_lookup_df = read_input_df(
            "New Lookup", args.input_path_new_lookup, spark, delimiter=lookup_delimiter
        )

        input_delimiter = get_delimiter_for_file("20ci_input", delimiter_config or {})
        twenty_ci_input_df = read_input_df(
            "20ci", args.input_path_20ci, spark, delimiter=input_delimiter
        )

        # Process the data
        output_df = process_data(twenty_ci_input_df, new_lookup_df)

        # Write output to S3
        logger.info(f"Writing output to S3: {args.output_path}")
        output_df.write.mode("overwrite").parquet(args.output_path)

        # Verify output
        output_df = spark.read.parquet(args.output_path)
        output_count = output_df.count()
        logger.info(f"Verified output count: {output_count:,} rows")

        # Calculate total time
        end_time = timer()
        total_time = str(datetime.timedelta(seconds=round(end_time - start_time, 0)))

        logger.info(f"Job completed successfully in {total_time}")
        logger.info("Process 20ci EMR job finished")

        # Exit successfully
        sys.exit(0)

    except Exception as e:
        logger.error(f"Process failed: {type(e).__name__}: {str(e)}", exc_info=True)
        sys.exit(1)

    finally:
        if spark:
            spark.stop()


if __name__ == "__main__":
    main()
