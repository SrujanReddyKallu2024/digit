#!/usr/bin/env python3
"""
F15 Channel View Email Processing Script

Processes F15 channel view email prospect data and applies suppressions.
"""

import argparse
import logging
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, lit
from pyspark.sql.types import IntegerType, StringType
import json
import boto3
from pyspark.sql.functions import monotonically_increasing_id, col, lit, DataFrame

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def get_delimiter_for_file(file_key: str, delimiter_config: dict = None) -> str:
    """
    Get the delimiter for a specific file type.
    
    Args:
        file_key: Key identifying the file type
        delimiter_config: Delimiter configuration dictionary
        
    Returns:
        Delimiter to use for the file (defaults to "|")
    """
    if not delimiter_config:
        return "|"  # Default fallback
    
    return delimiter_config.get(file_key, "|")

def create_spark_session():
    """Create optimized Spark session for EMR Serverless."""
    return SparkSession.builder \
        .appName("Digital Taxonomy - Process F15") \
        .config("spark.sql.adaptive.enabled", "true") \
        .config("spark.sql.adaptive.coalescePartitions.enabled", "true") \
        .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer") \
        .getOrCreate()

def dynamic_flag(config_json: str, matching_df, unmatching_df, spark, delimiter_config: dict = None):
    """Apply dynamic flagging logic based on JSON configuration."""
    try:
        config = json.loads(config_json)
        logger.info("Parsed suppression configuration")
    except Exception as e:
        logger.error(f"Failed to parse configuration JSON: {e}")
        raise

    # Store records that get flagged for suppression
    unmatching_union = spark.createDataFrame([], unmatching_df.schema)

    # Process each suppression file
    for file_config in config['files']:
        file_name = file_config['file_name']
        join_column = file_config['join_column']
        stage_name = file_config['stage_name']

        logger.info(f"Processing suppression stage: {stage_name}")

        # Read suppression file with appropriate delimiter
        file_delimiter = "|"  # Default
        if "A40" in file_name:
            file_delimiter = get_delimiter_for_file("a40_input", delimiter_config)
        elif "A67" in file_name:
            file_delimiter = get_delimiter_for_file("a67_input", delimiter_config)
        elif "A16" in file_name:
            file_delimiter = get_delimiter_for_file("a16_input", delimiter_config)
        elif "A08" in file_name:
            file_delimiter = get_delimiter_for_file("a08_input", delimiter_config)
        elif "A01" in file_name:
            file_delimiter = get_delimiter_for_file("a01_input", delimiter_config)
        elif "A44" in file_name:
            file_delimiter = get_delimiter_for_file("a44_input", delimiter_config)
        
        lookup_df = spark.read.csv(f"{file_name}", sep=file_delimiter, header=True)

        # Preprocessing before filtering
        matching_df = matching_df.withColumn("NonRepeatableInputField", lit(""))
        matching_df = matching_df.withColumn("DJ_RecordID", monotonically_increasing_id())

        # Split matching and unmatching based on join column values
        matching_temp = matching_df.filter((col(f"{join_column}") != "") & (col(f"{join_column}") != "0"))
        unmatching_temp = matching_df.filter((col(f"{join_column}") == "") | (col(f"{join_column}") == "0"))
        unmatching_temp = unmatching_temp.withColumn("Count", lit(0))

        # Rename the join column in the lookup DataFrame
        lookup_df = lookup_df.withColumnRenamed(join_column, f"{join_column}_1")

        # # Performance optimization for large datasets
        # if matching_temp.count() >= 90:
        lookup_df = lookup_df.select(f"{join_column}_1").distinct()

        # Perform the inner join (flagged records)
        joined_df = matching_temp.join(lookup_df, matching_temp[join_column] == lookup_df[f"{join_column}_1"], "inner")
        joined_df = joined_df.withColumn("Count", lit(1))
        joined_df = joined_df.drop(f"{join_column}_1")

        # Perform the anti join (clean records)
        anti_joined_df = matching_temp.join(lookup_df, matching_temp[join_column] == lookup_df[f"{join_column}_1"], "left_anti")
        anti_joined_df = anti_joined_df.withColumn("Count", lit(0))
        # Note: left_anti join doesn't include lookup columns, so no need to drop join_column_1

        # Ensure all DataFrames have the same schema before union
        logger.info(f"Joined DF columns: {len(joined_df.columns)}")
        logger.info(f"Anti-joined DF columns: {len(anti_joined_df.columns)}")
        logger.info(f"Unmatching temp DF columns: {len(unmatching_temp.columns)}")

        # Union the results
        union = joined_df.union(anti_joined_df).union(unmatching_temp)
        union = union.drop("NonRepeatableInputField", "DJ_RecordID")

        # Split into matching and unmatching for next iteration
        new_matching_union = union.filter(col("Count") == lit(0)).drop("Count")
        new_unmatching_union = union.filter(col("Count") != lit(0))
        new_unmatching_union = new_unmatching_union.withColumn("Stage", lit(stage_name))

        logger.info(f"Stage {stage_name}: Matching Rows: {new_matching_union.count()}, Unmatching Rows: {new_unmatching_union.count()}")

        # Collect all unmatching results
        unmatching_union = unmatching_union.union(new_unmatching_union)

        # Update matching_df for the next iteration
        matching_df = new_matching_union

    return matching_df, unmatching_union

def process_f15_data(spark, input_path, suppressions_config_path, delimiter_config: dict = None):
    """Process F15 Channel View Email Prospect data."""
    logger.info(f"Reading F15 data from: {input_path}")
    
    # Read F15 data with appropriate delimiter
    f15_delimiter = get_delimiter_for_file("f15_input", delimiter_config)
    logger.info(f"Using delimiter '{f15_delimiter}' for F15 file")
    df = spark.read.csv(input_path, sep=f15_delimiter, header=True)
    
    # Filter for specific email contributor sources
    df = df.filter(
        col("email_contributor_sources").contains("X20A") | 
        col("email_contributor_sources").contains("X42A") | 
        col("email_contributor_sources").contains("X55A") |
        col("email_contributor_sources").contains("X21A") | 
        col("email_contributor_sources").contains("X70A") | 
        col("email_contributor_sources").contains("X22A")
    )
    
    logger.info(f"Filtered F15 data count: {df.count()}")

    # Initialize empty DataFrame for unmatching_df
    unmatching_df = spark.createDataFrame([], df.schema).withColumn("Count", lit(None).cast(IntegerType()))
    unmatching_df = unmatching_df.withColumn("Stage", lit(None).cast(StringType()))

    # Apply dynamic flagging for suppressions
    df, final_unmatching = dynamic_flag(suppressions_config_path, df, unmatching_df, spark, delimiter_config)
    
    # Select required columns and add flag
    df = df.select("cb_key_db_person")
    df = df.withColumn("Prospect Email", lit("Y"))

    logger.info(f"Final F15 processed count: {df.count()}")
    return df

def main():
    parser = argparse.ArgumentParser(description="Process F15 Channel View Email data for Digital Taxonomy")
    parser.add_argument("--input_path", type=str, required=True, help="S3 path to F15 input file")
    parser.add_argument("--output_path", type=str, required=True, help="S3 path for output")
    parser.add_argument("--suppressions_config", type=str, required=True, help="JSON string containing suppressions config")
    parser.add_argument("--delimiter_config", type=str, required=False, help="JSON string containing delimiter configuration")
    
    args = parser.parse_args()
    
    logger.info("Starting F15 processing job")
    logger.info(f"Input path: {args.input_path}")
    logger.info(f"Output path: {args.output_path}")
    
    # Parse delimiter configuration
    delimiter_config = {}
    if hasattr(args, 'delimiter_config') and args.delimiter_config:
        try:
            delimiter_config = json.loads(args.delimiter_config)
            logger.info(f"Using delimiter configuration: {delimiter_config}")
        except Exception as e:
            logger.warning(f"Failed to parse delimiter config: {e}. Using defaults.")
    
    spark = create_spark_session()
    
    try:
        # Process F15 data
        processed_df = process_f15_data(spark, args.input_path, args.suppressions_config, delimiter_config)
        
        # Write output to S3
        logger.info(f"Writing output to: {args.output_path}")
        processed_df.write \
            .mode("overwrite") \
            .option("header", "true") \
            .parquet(args.output_path)
        
            
        logger.info("F15 processing completed successfully")
        
    except Exception as e:
        logger.error(f"F15 processing failed: {str(e)}")
        raise
    finally:
        spark.stop()

if __name__ == "__main__":
    main()