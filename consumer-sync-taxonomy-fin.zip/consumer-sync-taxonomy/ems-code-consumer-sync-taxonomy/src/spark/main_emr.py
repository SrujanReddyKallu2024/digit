import sys
import datetime
import argparse
import logging
import json
import boto3
import pandas as pd
import io
from typing import Dict, List, Tuple

# Import signoff stats module for validation
try:
    from signoff_stats import validate_output, format_validation_email
except ImportError:
    # Fallback if module not available
    validate_output = None
    format_validation_email = None
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import (
    expr,
    monotonically_increasing_id,
    when,
    col,
    datediff,
    to_date,
    current_date,
    lit,
    substring,
    regexp_replace,
    trim,
)
from pyspark.sql.types import IntegerType, StringType
from timeit import default_timer as timer

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

logger = logging.getLogger(__name__)

SCRIPT_CODE = "MAIN_TAX"


def get_delimiter_for_file(file_key: str, delimiter_config: dict = None) -> str:
    """Get the delimiter for a specific file type."""
    return delimiter_config.get(file_key, "|") if delimiter_config else "|"


def inner_join(df1: DataFrame, df2: DataFrame, join_condition) -> DataFrame:
    """Perform inner join between two DataFrames."""
    return df1.join(df2, join_condition, "inner")


def left_anti_join(df1: DataFrame, df2: DataFrame, join_condition) -> DataFrame:
    """Perform left anti join between two DataFrames."""
    return df1.join(df2, join_condition, "left_anti")


def batch_suppression_processing(
    config_json: str,
    df: DataFrame,
    unmatching_df: DataFrame,
    inner_join_func,
    left_anti_join_func,
    spark: SparkSession,
    args,
    delimiter_config: dict = None,
):

    logger.info("Starting batch suppression processing")

    try:
        config = json.loads(config_json)
        logger.info(f"Processing {len(config['files'])} suppression files")
    except Exception as e:
        logger.error(f"Failed to parse configuration: {e}")
        return df, unmatching_df

    # Load ALL suppression files and create temp views
    suppression_views = []
    suppression_metadata = []

    for i, file_config in enumerate(config["files"]):
        file_name = file_config["file_name"]
        join_column = file_config["join_column"]
        stage_name = file_config["stage_name"]

        logger.info(f"loading suppression file {i+1}/{len(config['files'])}: {stage_name}")

        # Determine delimiter
        file_delimiter = None
        if "A40" in file_name:
            file_delimiter = get_delimiter_for_file("a40_input", delimiter_config)
        elif "A67" in file_name:
            file_delimiter = get_delimiter_for_file("a67_input", delimiter_config)
        elif "A16" in file_name:
            file_delimiter = get_delimiter_for_file("a16_input", delimiter_config)
        elif "A08" in file_name:
            file_delimiter = get_delimiter_for_file("a08_input", delimiter_config)
        elif "A01" in file_name:
            file_delimiter = get_delimiter_for_file("a01_input", delimiter_config)
        elif "A44" in file_name:
            file_delimiter = get_delimiter_for_file("a44_input", delimiter_config)

        if not file_delimiter:
            raise ValueError(f"Delimiter not found for suppression file: {file_name}")

        # Load suppression file
        lookup_df = spark.read.csv(file_name, sep=file_delimiter, header=True)
        lookup_df = lookup_df.select(join_column).distinct()  # Only need join column

        # Create temp view for this suppression file
        view_name = f"suppression_{i}_{stage_name.replace(' ', '_')}"
        lookup_df.createOrReplaceTempView(view_name)

        suppression_views.append(view_name)
        suppression_metadata.append(
            {
                "view_name": view_name,
                "join_column": join_column,
                "stage_name": stage_name,
                "index": i,
            }
        )

    # Register main DataFrame as temp view
    df.createOrReplaceTempView("main_data")

    # Process suppressions
    logger.info("Processing suppressions")

    current_df = df
    unmatching_union = spark.createDataFrame([], unmatching_df.schema)

    # Process all suppressions in batch
    for metadata in suppression_metadata:
        view_name = metadata["view_name"]
        join_column = metadata["join_column"]
        stage_name = metadata["stage_name"]

        # Create suppression
        suppression_sql = f"""
        SELECT m.*, 
               CASE WHEN s.{join_column} IS NOT NULL THEN 1 ELSE 0 END as suppression_flag
        FROM main_data m
        LEFT JOIN {view_name} s ON m.{join_column} = s.{join_column}
        WHERE m.{join_column} IS NOT NULL AND m.{join_column} != '' AND m.{join_column} != '0'
        """

        result_df = spark.sql(suppression_sql)

        # Split records
        clean_records = result_df.filter(col("suppression_flag") == 0).drop("suppression_flag")
        flagged_records = result_df.filter(col("suppression_flag") == 1)
        flagged_records = flagged_records.withColumn("Stage", lit(stage_name))

        logger.info(
            f"Stage {stage_name}: Clean: {clean_records.count():,}, Flagged: {flagged_records.count():,}"
        )

        # Update for next iteration
        unmatching_union = unmatching_union.union(flagged_records)
        clean_records.createOrReplaceTempView("main_data")  # Update temp view
        current_df = clean_records

    logger.info("Batch suppression processing completed")
    return current_df, unmatching_union


def multi_join(
    final_df: DataFrame,
    processed_dfs: Dict[str, DataFrame],
    join_config: dict,
    spark: SparkSession,
) -> DataFrame:

    logger.info("Starting multi-join")

    # Create temp view for main DataFrame
    final_df.createOrReplaceTempView("main_final")

    # Create temp views for all processed DataFrames
    view_metadata = []
    for file_config in join_config["files"]:
        file_name = file_config["name"]
        main_col = file_config["join_column_main"]
        file_col = file_config["join_column_file"]

        if file_name not in processed_dfs or processed_dfs[file_name] is None:
            logger.warning(f"Skipping {file_name} - not available")
            continue

        df = processed_dfs[file_name]

        main_columns = set(final_df.columns)
        df_columns = set(df.columns)
        common_cols = main_columns & df_columns

        # Rename conflicting columns (except join columns)
        for column_name in common_cols:
            df = df.withColumnRenamed(file_col, f"{file_col}_right")

        # Handle join column conflicts
        if main_col == file_col:
            df = df.withColumnRenamed(file_col, f"{file_col}_right")
            actual_file_col = f"{file_col}_right"
        else:
            actual_file_col = file_col

        view_name = f"processed_{file_name.replace('process_file_', '').lower()}"
        df.createOrReplaceTempView(view_name)

        view_metadata.append(
            {
                "view_name": view_name,
                "main_col": main_col,
                "file_col": actual_file_col,
                "original_name": file_name,
            }
        )

    # Build the multi-join SQL
    logger.info("Building multi-join")

    base_query = "SELECT * FROM main_final m"
    join_parts = []

    for metadata in view_metadata:
        view_name = metadata["view_name"]
        main_col = metadata["main_col"]
        file_col = metadata["file_col"]

        join_part = f"LEFT JOIN {view_name} ON m.{main_col} = {view_name}.{file_col}"
        join_parts.append(join_part)

    multi_join_sql = f"{base_query} " + " ".join(join_parts)

    logger.info(f"Joining {len(view_metadata)} datasets")

    try:
        result_df = spark.sql(multi_join_sql)
        logger.info("Multi-join completed successfully")
        return result_df
    except Exception as e:
        logger.error(f"Multi-join failed {e}")
        raise


def vectorized_cvar_processing(
    final_df: DataFrame, taxonomy_excel_config: str, spark: SparkSession
) -> Tuple[DataFrame, List[str]]:

    logger.info("Starting vectorized C-variable processing")

    try:
        bucket, key = parse_s3_path(taxonomy_excel_config)
        s3 = boto3.client("s3")
        s3_response = s3.get_object(Bucket=bucket, Key=key)
        excel_bytes = s3_response["Body"].read()
        rules = pd.read_excel(io.BytesIO(excel_bytes), dtype=str)
        logger.info(f"Loaded {len(rules)} rules for processing")
    except Exception as e:
        logger.error(f"Error reading Excel file: {e}")
        raise

    existing_columns = set(final_df.columns)
    c_vars = []
    invalid_rules = []

    # Group rules by type for batch processing
    case_rules = []
    simple_rules = []
    direct_rules = []

    # Pre-process and validate all rules
    for _, row in rules.iterrows():
        new_col = row["new_column"]
        source_col = str(row["source_column"]) if pd.notna(row["source_column"]) else ""
        condition_type = row["condition_type"]

        c_vars.append(new_col)

        # Validate source columns
        if source_col:
            source_cols = [col.strip() for col in source_col.split(",")]
            missing_cols = [col for col in source_cols if col not in existing_columns]
            if missing_cols:
                invalid_rules.append(
                    {"new_column": new_col, "error": f"Missing columns: {missing_cols}"}
                )
                continue

        # Group by type
        if condition_type == "CASE":
            case_rules.append(row)
        elif condition_type == "Simple":
            simple_rules.append(row)
        elif condition_type == "Direct":
            direct_rules.append(row)

    logger.info(
        f"Grouped rules - CASE: {len(case_rules)}, Simple: {len(simple_rules)}, Direct: {len(direct_rules)}"
    )

    current_df = final_df

    # Process CASE rules
    if case_rules:
        logger.info(f"Processing {len(case_rules)} CASE rules")
        for rule in case_rules:
            try:
                current_df = current_df.withColumn(
                    rule["new_column"], expr(rule["case_expression"])
                )
            except Exception as e:
                invalid_rules.append(
                    {"new_column": rule["new_column"], "error": f"CASE error: {e}"}
                )

    # Process Simple rules
    if simple_rules:
        logger.info(f"Processing {len(simple_rules)} Simple rules")
        for rule in simple_rules:
            try:
                condition_expr = rule["condition"]
                true_value = rule["true_value"]
                false_value = rule["false_value"] if pd.notna(rule["false_value"]) else ""

                case_expr = f"CASE WHEN {condition_expr} THEN {true_value} ELSE {false_value} END"
                current_df = current_df.withColumn(rule["new_column"], expr(case_expr))
            except Exception as e:
                invalid_rules.append(
                    {"new_column": rule["new_column"], "error": f"Simple error: {e}"}
                )

    # Process Direct rules
    if direct_rules:
        logger.info(f"Processing {len(direct_rules)} Direct rules")

        # Group direct rules into rename and copy operations
        rename_ops = {}
        copy_ops = {}

        for rule in direct_rules:
            new_col = rule["new_column"]
            direct_assignment = rule["direct_assignment"]

            if pd.isna(direct_assignment) or direct_assignment not in existing_columns:
                invalid_rules.append(
                    {
                        "new_column": new_col,
                        "error": f"Missing direct assignment: '{direct_assignment}'",
                    }
                )
                continue

            if new_col not in current_df.columns:
                rename_ops[direct_assignment] = new_col
            else:
                copy_ops[new_col] = direct_assignment

        # Apply all renames in batch
        for old_name, new_name in rename_ops.items():
            current_df = current_df.withColumnRenamed(old_name, new_name)

        # Apply all copies in batch
        for new_col, source_col in copy_ops.items():
            current_df = current_df.withColumn(new_col, col(source_col))

    if invalid_rules:
        logger.warning(f"Found {len(invalid_rules)} invalid rules")
        for rule in invalid_rules[:5]:  # Show only first 5
            logger.warning(f"Invalid rule: {rule}")

    logger.info("Vectorized C-variable processing completed")
    return current_df, c_vars


def create_parser():
    """Create command line argument parser."""
    parser = argparse.ArgumentParser(description="Digital Taxonomy Main Processing for EMR")

    # Input paths
    parser.add_argument("--f35_input_path", type=str, required=True)
    parser.add_argument("--adhoc_suppression_path", type=str, required=True)

    # Interim paths
    parser.add_argument("--f15_processed_path", type=str, required=True)
    parser.add_argument("--f45_processed_path", type=str, required=True)
    parser.add_argument("--r45_processed_path", type=str, required=True)
    parser.add_argument("--auto_segments_processed_path", type=str, required=True)
    parser.add_argument("--boots_segments_processed_path", type=str, required=True)
    parser.add_argument("--propensities_processed_path", type=str, required=True)
    parser.add_argument("--yougov_processed_path", type=str, required=True)
    parser.add_argument("--twenty_ci_processed_path", type=str, required=True)
    parser.add_argument("--f35_mosaic_processed_path", type=str, required=True)

    # Configuration paths
    parser.add_argument("--mailable_universe_config", type=str, required=True)
    parser.add_argument("--cv_vars_config", type=str, required=True)
    parser.add_argument("--final_vars_config", type=str, required=True)
    parser.add_argument("--taxonomy_excel_config", type=str, required=True)
    parser.add_argument("--config_json_path", type=str, required=True)

    # Environment parameters
    parser.add_argument("--source_bucket", type=str, required=True)
    parser.add_argument("--month_yyyy_mm", type=str, required=True)

    # Output paths
    parser.add_argument("--interim_output_path", type=str, required=True)
    parser.add_argument("--final_output_source_path", type=str, required=True)
    parser.add_argument("--final_output_bucket_path", type=str, required=True)

    # Delimiter configuration
    parser.add_argument("--delimiter_config", type=str, required=False)

    # Stats validation (signoff stats)
    parser.add_argument("--stats_bucket", type=str, required=False,
                        help="S3 bucket for storing/loading signoff stats")
    parser.add_argument("--enable_validation", type=str, default="true",
                        help="Enable output validation before writing (true/false)")

    return parser


def parse_s3_path(s3_path: str) -> tuple:
    """Parse S3 path and return bucket and key."""
    if s3_path.startswith("s3a://"):
        s3_path_cleaned = s3_path[6:]
    elif s3_path.startswith("s3://"):
        s3_path_cleaned = s3_path[5:]
    else:
        s3_path_cleaned = s3_path

    parts = s3_path_cleaned.split("/")
    bucket = parts[0]
    key = "/".join(parts[1:]) if len(parts) > 1 else ""
    return bucket, key


def load_json_from_s3(s3_path: str) -> dict:
    """Load JSON configuration from S3."""
    s3 = boto3.client("s3")
    bucket, key = parse_s3_path(s3_path)
    response = s3.get_object(Bucket=bucket, Key=key)
    return json.loads(response["Body"].read().decode("utf-8"))


def save_validation_result(stats_bucket: str, current_month: str, validation_result, output_path: str = None) -> str:
    """
    Save validation result to S3 for DAG to pick up.
    
    Args:
        stats_bucket: S3 bucket name
        current_month: YYYYMM format
        validation_result: ValidationResult object from signoff_stats
        output_path: Optional output file path for email
    
    Returns:
        S3 path where result was saved
    """
    result_key = f"taxonomy_signoff/{current_month}/validation_result.json"
    
    # Format email using format_validation_email
    email_data = None
    if format_validation_email:
        try:
            email_data = format_validation_email(validation_result, current_month, output_path)
        except Exception as e:
            logger.warning(f"Could not format validation email: {e}")
    
    # Build comprehensive result data
    result_data = {
        "passed": validation_result.passed,
        "reasons": validation_result.reasons,
        "total_rows": validation_result.current_stats.get("total_rows", 0),
        "computed_at": validation_result.current_stats.get("computed_at", ""),
        "month": current_month,
        # Add email format data
        "email": email_data if email_data else {
            "subject": f"{'✅' if validation_result.passed else '❌'} Digital Taxonomy {current_month} - {'Validation Passed' if validation_result.passed else 'VALIDATION FAILED'}",
            "body": "\\n".join(validation_result.reasons) if validation_result.reasons else "All validation checks passed.",
            "passed": validation_result.passed
        },
        # Add row count comparison if available
        "row_count_comparison": validation_result.comparison.get("row_count", {}) if validation_result.comparison else {},
        # Add flagged columns summary (columns with breaches)
        "flagged_columns": [
            {
                "column_name": col_name,
                "prev_null_values": col_data.get("prev_null_values", 0),
                "curr_null_values": col_data.get("curr_null_values", 0),
                "diff_null_values": col_data.get("diff_null_values", 0),
                "pct_change_null_values": col_data.get("pct_change_null_values", 0),
                "null_pct": col_data.get("null_pct", {}),
                "status": col_data.get("status", "compared")
            }
            for col_name, col_data in (validation_result.comparison.get("columns", {}) if validation_result.comparison else {}).items()
            if col_data.get("breach_any", False) or col_data.get("status") in ["new_column", "removed"]
        ] if validation_result.comparison else []
    }
    
    try:
        s3 = boto3.client("s3")
        s3.put_object(
            Bucket=stats_bucket,
            Key=result_key,
            Body=json.dumps(result_data, indent=2),
            ContentType="application/json"
        )
        logger.info(f"Validation result saved to s3://{stats_bucket}/{result_key}")
        return f"s3://{stats_bucket}/{result_key}"
    except Exception as e:
        logger.error(f"Failed to save validation result: {e}")
        return ""


def load_processing_scripts_data(
    spark: SparkSession, script_paths: Dict[str, str]
) -> Dict[str, DataFrame]:
    """Load processed data from all component scripts with caching."""
    processed_dfs = {}

    for script_name, s3_path in script_paths.items():
        logger.info(f"Loading {script_name} from {s3_path}")
        try:
            df = spark.read.parquet(s3_path)
            df.cache()  # Cache for joins
            processed_dfs[script_name] = df
            logger.info(f"Loaded and cached {script_name}: {df.count():,} rows")
        except Exception as e:
            logger.error(f"Failed to load {script_name}: {e}")
            processed_dfs[script_name] = None

    return processed_dfs


def process_data(spark: SparkSession, args: argparse.Namespace) -> DataFrame:
    start_time = timer()

    logger.info("Starting Digital Taxonomy processing")

    delimiter_config = {}
    if hasattr(args, "delimiter_config") and args.delimiter_config:
        try:
            delimiter_config = json.loads(args.delimiter_config)
        except Exception as e:
            logger.warning(f"Failed to parse delimiter config: {e}")

    try:
        # Read main F35 consumer data file
        logger.info("Reading F35 consumer data file")
        f35_delimiter = get_delimiter_for_file("f35_input", delimiter_config)
        df = spark.read.csv(args.f35_input_path, sep=f35_delimiter, header=True)
        initial_count = df.count()
        logger.info(f"F35 initial data count: {initial_count:,} rows")

        if initial_count > 10000000:
            df = df.repartition(400)
        elif initial_count > 1000000:
            df = df.repartition(200)

        df_copy = df.cache()
        df = df.withColumn("MU_RecordID", monotonically_increasing_id() + 1).withColumn(
            "Person_Mailable_flag", lit("")
        )
        columns = ["MU_RecordID"] + [col for col in df.columns if col != "MU_RecordID"]
        df = df.select(columns)

        logger.info("Applying initial data quality filters")
        df = df.withColumn(
            "Stage",
            when(col("cb_address_mailable_flag") != "Y", "Mailable")
            .when(col("p_prospectable_flag") != "Y", "Prospectable")
            .when(col("cb_name_title").isNull() | (col("cb_name_title") == ""), "Blank title")
            .when(
                (col("p_prospectable_date_of_birth").isNotNull())
                & (col("p_prospectable_date_of_birth") != "")
                & (
                    datediff(
                        current_date(), to_date(col("p_prospectable_date_of_birth"), "yyyyMMdd")
                    )
                    < 6574
                ),
                "Over 18",
            )
            .when(
                (col("P_NA_CONTRIBUTOR_SOURCES").substr(1, 3) == "A04")
                | (col("P_NA_CONTRIBUTOR_SOURCES").substr(1, 3) == "A05")
                | (col("P_NA_CONTRIBUTOR_SOURCES").substr(1, 3) == "A30"),
                "Unwanted Contributors",
            )
            .otherwise(""),
        )

        df = df.filter(col("Stage") == "")
        df = df.drop("Stage")
        after_initial_filter = df.count()
        logger.info(f"After initial filtering: {after_initial_filter:,} rows")

        # Initialize empty DataFrame for unmatching_df
        unmatching_df = spark.createDataFrame([], df.schema).withColumn(
            "Count", lit(None).cast(IntegerType())
        )
        unmatching_df = unmatching_df.withColumn("Stage", lit(None).cast(StringType()))

        # suppression processing
        logger.info("Starting batch suppression processing")
        final_matching, final_unmatching = batch_suppression_processing(
            args.mailable_universe_config,
            df,
            unmatching_df,
            inner_join,
            left_anti_join,
            spark,
            args,
            delimiter_config,
        )

        # Perform ad-hoc suppressions
        logger.info("Performing ad-hoc suppressions")
        adhoc_delimiter = get_delimiter_for_file("adhoc_suppression", delimiter_config)
        ad_hoc_sups = (
            spark.read.option("header", "true")
            .option("sep", adhoc_delimiter)
            .csv(args.adhoc_suppression_path)
        )
        ad_hoc_sups.cache()

        join_column = "cb_key_db_person"
        ad_hoc_sups = ad_hoc_sups.withColumnRenamed(join_column, f"{join_column}_1")

        mu_l = left_anti_join(
            final_matching,
            ad_hoc_sups,
            final_matching[join_column] == ad_hoc_sups[f"{join_column}_1"],
        )
        mailable_universe = mu_l.drop(
            "MU_RecordID",
            "cb_key_db_person_1",
            "A13_Sup_File",
            "F35_Suppressions",
            "LSO_Suppressions",
        )
        mailable_universe = mailable_universe.select("cb_key_db_person").withColumn(
            "Person_Mailable_flag", lit("Y")
        )

        # Join suppressions back to main file
        mailable_universe = mailable_universe.withColumnRenamed(join_column, f"{join_column}_1")
        join = inner_join(
            df_copy,
            mailable_universe,
            df_copy[join_column] == mailable_universe[f"{join_column}_1"],
        )
        join = join.drop(f"{join_column}_1")

        left_anti_join_df = left_anti_join(
            df_copy,
            mailable_universe,
            df_copy[join_column] == mailable_universe[f"{join_column}_1"],
        )

        union = join.unionByName(left_anti_join_df, allowMissingColumns=True)

        # Reduce schema and pre-processing
        cv_vars_config = load_json_from_s3(args.cv_vars_config)
        required_columns = cv_vars_config.get("columns", [])
        available_columns = [col for col in required_columns if col in union.columns]
        reduced_union = union.select(available_columns)
        reduced_union.cache()

        # Pre-processing (batch operations)
        reduced_union = (
            reduced_union.withColumnRenamed("cb_address_postcode_area", "Postcode Area")
            .withColumnRenamed("cb_address_postcode_outcode", "Postcode District")
            .withColumnRenamed("cb_address_postcode_sector", "Postcode Sector")
            .withColumn("p_fss_4_group", substring(col("p_fss_4_type"), 1, 1))
            .withColumn("p_fss_4_type_Two_byte", substring(col("p_fss_4_type"), 2, 2))
            .withColumn("p_mosaic_7_uk_group", substring(col("p_mosaic_uk_7_type"), 1, 1))
            .withColumn(
                "mosaic_uk_7_type_for_matching", substring(col("p_mosaic_uk_7_type"), 2, 2)
            )
            .withColumn("Pcode_To_Match", trim(regexp_replace(col("mailable_postcode"), " ", "")))
        )

        # Load processed script data
        script_paths = {
            "process_file_F15": args.f15_processed_path,
            "process_file_F45": args.f45_processed_path,
            "process_file_R45": args.r45_processed_path,
            "process_file_auto_segments": args.auto_segments_processed_path,
            "process_file_boots_segments": args.boots_segments_processed_path,
            "process_file_propensities_segments": args.propensities_processed_path,
            "process_file_yougov": args.yougov_processed_path,
            "process_file_20ci": args.twenty_ci_processed_path,
            "process_file_F35_mosaic": args.f35_mosaic_processed_path,
        }

        processed_dfs = load_processing_scripts_data(spark, script_paths)

        logger.info("Starting multi-join processing")
        join_config = load_json_from_s3(args.config_json_path)

        final_df = multi_join(reduced_union, processed_dfs, join_config, spark)

        logger.info("Starting vectorized C-variable processing")
        final_df, c_vars = vectorized_cvar_processing(final_df, args.taxonomy_excel_config, spark)

        # Reduce final schema
        try:
            final_vars_config = load_json_from_s3(args.final_vars_config)
            required_columns = final_vars_config.get("columns", [])
            base_columns = [col for col in required_columns if col in final_df.columns]
            final_columns = list(
                dict.fromkeys(base_columns + c_vars)
            )  # Remove duplicates, preserve order
            digital_taxonomy = final_df.select(final_columns)
        except Exception as e:
            logger.error(f"Error in final schema reduction: {e}")
            digital_taxonomy = final_df

        final_count = digital_taxonomy.count()
        logger.info(f"Final digital taxonomy count: {final_count:,} rows")

        # =====================================================
        # SIGNOFF STATS VALIDATION (before writing output)
        # =====================================================
        validation_passed = True
        validation_result = None
        
        enable_validation = getattr(args, 'enable_validation', 'true').lower() == 'true'
        stats_bucket = getattr(args, 'stats_bucket', None)
        
        if enable_validation and validate_output and stats_bucket:
            logger.info("Running signoff stats validation...")
            
            # stats_bucket is already just the bucket name (no s3:// prefix)
            # But handle the case if it has a prefix just in case
            if stats_bucket.startswith("s3://"):
                stats_bucket_name = stats_bucket[5:].split("/")[0]
            elif stats_bucket.startswith("s3a://"):
                stats_bucket_name = stats_bucket[6:].split("/")[0]
            else:
                stats_bucket_name = stats_bucket  # Already just the bucket name
            
            # Get month in YYYYMM format (input is YYYY-MM)
            current_month = args.month_yyyy_mm.replace("-", "")
            if len(current_month) != 6:
                logger.warning(f"Unexpected month format: {args.month_yyyy_mm} -> {current_month}")
            
            logger.info(f"Validating for month: {current_month}, stats bucket: {stats_bucket_name}")
            
            # Validate output DataFrame
            validation_result = validate_output(
                df=digital_taxonomy,
                stats_bucket=stats_bucket_name,
                current_month=current_month,
                columns_to_check=None,  # Check all columns
                thresholds=None,  # Use default thresholds
                critical_columns=None  # Use default critical columns
            )
            
            validation_passed = validation_result.passed
            
            if not validation_passed:
                logger.error("VALIDATION FAILED - Output will NOT be written to client delivery")
                for reason in validation_result.reasons:
                    logger.error(f"  - {reason}")
                
                # Save validation result for DAG to pick up (includes email format)
                save_validation_result(stats_bucket_name, current_month, validation_result, args.final_output_bucket_path)
                
                raise Exception(
                    f"Signoff validation failed with {len(validation_result.reasons)} issue(s). "
                    f"File NOT delivered. Reasons: {'; '.join(validation_result.reasons)}"
                )
            else:
                logger.info("VALIDATION PASSED - Proceeding to write output")
        elif not enable_validation:
            logger.info("Validation disabled - skipping signoff stats check")
        elif not stats_bucket:
            logger.warning("stats_bucket not provided - skipping signoff stats validation")
        elif not validate_output:
            logger.warning("signoff_stats module not available - skipping validation")

        # Optimize output partitioning
        if final_count > 5000000:
            digital_taxonomy = digital_taxonomy.coalesce(100)
        elif final_count > 1000000:
            digital_taxonomy = digital_taxonomy.coalesce(50)
        else:
            digital_taxonomy = digital_taxonomy.coalesce(10)

        try:
            logger.info("Using RDD-based approach")

            # Get header
            header_row = "|".join(digital_taxonomy.columns)

            # Convert to RDD with proper formatting
            data_rdd = digital_taxonomy.rdd.map(
                lambda row: "|".join(
                    [str(val).replace('"', "") if val is not None else "" for val in row]
                )
            )

            data_list = data_rdd.collect()
            final_list = [header_row] + data_list
            final_rdd = spark.sparkContext.parallelize(final_list)

            # Write to source bucket location (internal/taxonomy/YYYY-MM-DD/)
            final_rdd.coalesce(1).saveAsTextFile(args.final_output_source_path)
            logger.info(f"Successfully created source output at {args.final_output_source_path}")

            # Write to output bucket location (taxonomy/YYYY-MM-DD/)
            final_rdd.coalesce(1).saveAsTextFile(args.final_output_bucket_path)
            logger.info(f"Successfully created bucket output at {args.final_output_bucket_path}")

        except Exception as e2:
            logger.error(f"RDD approach has failed: {e2}")

        # Cleanup cached DataFrames
        df_copy.unpersist()
        ad_hoc_sups.unpersist()
        reduced_union.unpersist()
        for df in processed_dfs.values():
            if df is not None:
                df.unpersist()

        end_time = timer()
        processing_time = datetime.timedelta(seconds=round(end_time - start_time, 0))
        logger.info(f"processing completed in {processing_time}")

        return digital_taxonomy

    except Exception as e:
        logger.error(f"Error in processing: {str(e)}")
        raise


# ----------------------------------------------------------------------
# MAIN FUNCTION
# ----------------------------------------------------------------------


def main():
    """Main entry point for the Digital Taxonomy EMR job."""
    start_time = timer()

    # Parse arguments
    parser = create_parser()
    args, unknown = parser.parse_known_args()

    if unknown:
        logger.warning(f"Unknown arguments: {unknown}")

    # Initialize Spark Session
    spark = SparkSession.builder.appName("Digital Taxonomy Main EMR").getOrCreate()

    spark.sparkContext.setLogLevel("WARN")

    logger.info("Starting Digital Taxonomy Main EMR job")

    try:
        # Process the data with optimizations
        process_data(spark, args)

        # Calculate total time
        end_time = timer()
        total_time = str(datetime.timedelta(seconds=round(end_time - start_time, 0)))

        logger.info(f"job completed successfully in {total_time}")

        # Exit successfully
        sys.exit(0)

    except Exception as e:
        logger.error(f"process failed: {type(e).__name__}: {str(e)}", exc_info=True)
        sys.exit(1)

    finally:
        if spark:
            spark.stop()


if __name__ == "__main__":
    main()
