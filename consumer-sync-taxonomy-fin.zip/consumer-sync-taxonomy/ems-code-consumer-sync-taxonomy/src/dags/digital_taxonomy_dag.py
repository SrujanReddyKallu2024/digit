import json
import logging
import time
import boto3
import fnmatch
from datetime import datetime, timedelta

from airflow import DAG
from airflow.models.param import Param
from airflow.operators.python import PythonOperator, BranchPythonOperator, get_current_context
from airflow.operators.dummy import DummyOperator
from airflow.operators.email import EmailOperator
from airflow.models import Variable
from airflow.operators.trigger_dagrun import TriggerDagRunOperator

import pendulum
import re
import sys
import os
import tempfile
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent))

logging.getLogger(__name__).setLevel(logging.INFO)

import shared.functions
import shared.utils
import shared.utils.utils
import shared.bucket_list

from shared.functions import platform, get_env, parse_s3_path, email_on_failure
from urllib.parse import urlparse


def resolve_s3_pattern(s3_path_pattern):
    """
    Resolve an S3 path pattern to the latest file by filename (alphabetical sort).
    Matches on-prem behavior: find | sort | tail -n 1
    """
    import boto3
    import fnmatch

    if s3_path_pattern.startswith("s3://"):
        s3_path_pattern = s3_path_pattern[5:]
    elif s3_path_pattern.startswith("s3a://"):
        s3_path_pattern = s3_path_pattern[6:]

    parts = s3_path_pattern.split("/", 1)
    bucket_name = parts[0]
    key_pattern = parts[1] if len(parts) > 1 else ""

    logging.info(f"Resolving S3 pattern: bucket={bucket_name}, pattern={key_pattern}")

    try:
        s3 = boto3.client("s3")

        # Extract prefix before first wildcard for efficient S3 listing
        prefix = key_pattern.split("*")[0]

        paginator = s3.get_paginator("list_objects_v2")
        page_iterator = paginator.paginate(Bucket=bucket_name, Prefix=prefix)

        # Collect all matching file keys
        matching_files = []
        for page in page_iterator:
            if "Contents" in page:
                for obj in page["Contents"]:
                    obj_key = obj["Key"]
                    if fnmatch.fnmatch(obj_key, key_pattern):
                        matching_files.append(obj_key)

        if not matching_files:
            logging.warning(f"No files found matching pattern: {key_pattern}")
            return None

        # Sort alphabetically and pick the last one (same as: sort | tail -n 1)
        matching_files.sort()
        latest_file = matching_files[-1]

        resolved_path = f"s3://{bucket_name}/{latest_file}"
        logging.info(f"Found {len(matching_files)} file(s), selected latest: {resolved_path}")

        return resolved_path

    except Exception as e:
        logging.error(f"Error resolving S3 pattern {s3_path_pattern}: {e}")
        return None


def file_exists_with_pattern(bucket_name, key_pattern, exclude=None):

    import boto3
    import fnmatch

    logging.info(f"Checking if file exists in bucket '{bucket_name}' with pattern '{key_pattern}'")

    try:
        s3 = boto3.client("s3")

        if "*" in key_pattern:
            prefix = key_pattern.split("*")[0]
        else:
            try:
                s3.head_object(Bucket=bucket_name, Key=key_pattern)
                logging.info(f"Found exact match for key: {key_pattern}")
                return True
            except Exception as e:
                logging.error(f"Error checking exact key {key_pattern}: {e}")
                return False

        paginator = s3.get_paginator("list_objects_v2")
        page_iterator = paginator.paginate(Bucket=bucket_name, Prefix=prefix)

        for page in page_iterator:
            if "Contents" in page:
                for obj in page["Contents"]:
                    obj_key = obj["Key"]
                    logging.info(f"Checking object key: {obj_key}")

                    if fnmatch.fnmatch(obj_key, key_pattern):

                        if exclude and exclude in obj_key:
                            logging.info(f"Excluding {obj_key} due to exclude pattern: {exclude}")
                            continue

                        logging.info(f"Found matching file: {obj_key}")
                        return True

        logging.warning(f"No files found matching pattern: {key_pattern}")
        return False

    except Exception as e:
        logging.error(f"Error checking if file exists with pattern {key_pattern}: {e}")
        return False


from shared.utils.emr_application_factory import (
    create_emr_application,
    delete_emr_application,
    start_emr_job,
)
import boto3

with DAG(
    "digital_taxonomy_processing",
    description="Process Digital Taxonomy data end-to-end",
    catchup=False,
    start_date=pendulum.datetime(2023, 1, 1, tz="UTC"),
    schedule_interval="0 8 12 * *",
    tags=["digital_taxonomy", "consumer_sync"],
    params={
        "email_to": Param("kallusrujan.reddy@experian.com", type="string"),
        "enable_validation": Param(True, type="boolean", description="Enable signoff stats validation before writing output"),
    },
    default_args={
        "owner": "airflow",
        "depends_on_past": False,
        "email_on_failure": False,
        "email_on_retry": False,
        "retries": 1,
        "retry_delay": timedelta(minutes=5),
        "on_failure_callback": email_on_failure,
    },
) as dag:

    def get_source_routing_config():
        """
        Configure source routing for input files.
        
        Routes:
            - 'analytics': source-bucket/internal/analytics
            - 'client_delivery': client-delivery-bucket/misc
            - 'data_office': source-bucket/internal/data_office (default)
        """
        return {
            # Data Office files
            "f35_input": "data_office",
            "f45_input": "data_office",
            "f15_input": "data_office",
            "a40_input": "data_office",
            "a67_input": "data_office",
            "a16_input": "data_office",
            "a08_input": "data_office",
            "a01_input": "data_office",
            "a44_input": "data_office",
            "20ci_input": "data_office",
            
            # Analytics files
            "r45_input": "analytics",
            "yougov_input": "analytics",
            "adhoc_suppression": "analytics",
            "boots_lookup_excel": "analytics",
            "core_propensities_millitiles": "analytics",
            "core_propensities_cutoffs": "analytics",
            "standard_audiences_millitiles": "analytics",
            "standard_audiences_cutoffs": "analytics",
            "mc_hh_lookup": "analytics",
            "f35_mosaic_input": "analytics",
            
            # Client Delivery files
            "auto_segments_excel": "client_delivery",
            "20ci_new_lookup": "client_delivery",
        }
    
    def get_source_path_for_file(file_key: str, env: str, source_routing: dict) -> str:
        """Get the base S3 path for a file based on its routing configuration."""
        origin = source_routing.get(file_key, "data_office")
        
        if origin == "analytics":
            return f"s3://eec-aws-uk-ms-consumersync-{env}-source-bucket/internal/analytics"
        elif origin == "client_delivery":
            return f"s3://eec-aws-uk-ms-consumersync-{env}-client-delivery-bucket/misc"
        else:
            return f"s3://eec-aws-uk-ms-consumersync-{env}-source-bucket/internal/data_office"

    def get_delimiter_config():
        """
        Configure delimiter specifications for all input file types.

        This function centralizes delimiter configuration for the various data sources
        processed in the Digital Taxonomy workflow. Different file types use different
        delimiters based on their source systems and data export formats.

        Returns:
            dict: Mapping of file type identifiers to their respective delimiter characters

        Note:
            Modify delimiter values here when source file formats change.
            Pipe-delimited files (|) are typically from Experian internal systems,
            while comma-delimited files (,) are from external providers.
        """
        return {
            "f35_input": "|",
            "f15_input": "|",
            "f45_input": ",",
            "r45_input": ",",
            "yougov_input": ",",
            "adhoc_suppression": ",",
            "20ci_input": "\\t",
            "20ci_new_lookup": ",",
            "f35_mosaic_input": "|",
            # Data suppression and mailability files
            # These files control record-level data processing and output
            "a40_input": "|",
            "a67_input": "|",
            "a16_input": "|",
            "a08_input": "|",
            "a01_input": "|",
            "a44_input": "|",
            # Consumer propensity modeling and scoring files
            "core_propensities_millitiles": "|",
            "core_propensities_cutoffs": "|",
            "standard_audiences_millitiles": ",",
            "standard_audiences_cutoffs": ",",
            "mc_hh_lookup": ",",
        }

    def get_delimiter_for_file_pattern(file_name: str, delimiter_config: dict) -> str:
        """
        Get delimiter for a file based on pattern matching instead of lengthy if-elif chains.

        Args:
            file_name: The file name or path to check
            delimiter_config: Configuration mapping file patterns to delimiters

        Returns:
            Delimiter character for the file
        """
        # File pattern to config key mapping
        pattern_mapping = {
            "A40": "a40_input",
            "A67": "a67_input",
            "A16": "a16_input",
            "A08": "a08_input",
            "A01": "a01_input",
            "A44": "a44_input",
            "F35": "f35_input",
            "F15": "f15_input",
            "F45": "f45_input",
            "R45": "r45_input",
            "YouGov": "yougov_input",
            "ADHOC_SUPPRESSION": "adhoc_suppression",
            "Core_Propensities_Millitiles": "core_propensities_millitiles",
            "Core_Propensities_FlagCutoffs": "core_propensities_cutoffs",
            "Standard_Audiences": "standard_audiences_millitiles",
            "mc_hh_Lookup": "mc_hh_lookup",
        }

        # Find matching pattern
        for pattern, config_key in pattern_mapping.items():
            if pattern in file_name:
                return delimiter_config.get(config_key, "|")

        # Default delimiter if no pattern matches
        logging.warning(f"No delimiter pattern found for file {file_name}, using default '|'")
        return "|"

    def create_script_arguments(**context):

        from shared.bucket_list import get_bucket_name
        from shared.functions import latest_path, get_env, latest_file

        logging.info("Creating script arguments for Digital Taxonomy processing")

        workflow_start_time = time.time()
        logging.info("Workflow started %s", datetime.fromtimestamp(workflow_start_time))

        env = get_env()
        execution_date = context["execution_date"]
        run_date_param = context["params"].get("RUNDATE", "")
        # Override execution date if provided in DAG run configuration
        if run_date_param:
            execution_date = datetime.strptime(run_date_param, "%Y%m%d")
        # Support both compressed (YYYYMM) and hyphenated (YYYY-MM) date formats
        month_yyyymm = execution_date.strftime("%Y%m")
        month_yyyy_mm = execution_date.strftime("%Y-%m")
        date_str = execution_date.strftime("%Y-%m-%d")
        now_str = datetime.now().strftime("%Y%m%d%H%M%S")

        # Store timing, environment, and date information for processing continuity
        context["task_instance"].xcom_push(key="workflow_start_time", value=workflow_start_time)
        context["task_instance"].xcom_push(key="env", value=env)
        context["task_instance"].xcom_push(key="month_yyyymm", value=month_yyyymm)
        context["task_instance"].xcom_push(key="month_yyyy_mm", value=month_yyyy_mm)
        context["task_instance"].xcom_push(key="execution_date", value=date_str)

        PROTOCOL = "s3"

        source_bucket = get_bucket_name("source")
        interim_bucket = get_bucket_name("interim")
        output_bucket = get_bucket_name("output")
        code_bucket = get_bucket_name("code")
        log_bucket = get_bucket_name("logs")
        stats_bucket = get_bucket_name("stats")

        stats_timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        context["task_instance"].xcom_push(key="stats_timestamp", value=stats_timestamp)

        context["task_instance"].xcom_push(key="source_bucket", value=source_bucket)
        context["task_instance"].xcom_push(key="interim_bucket", value=interim_bucket)
        context["task_instance"].xcom_push(key="output_bucket", value=output_bucket)
        context["task_instance"].xcom_push(key="code_bucket", value=code_bucket)
        context["task_instance"].xcom_push(key="log_bucket", value=log_bucket)
        context["task_instance"].xcom_push(key="stats_bucket", value=stats_bucket)

        dt_interim_base_path = f"{PROTOCOL}://{interim_bucket}/internal/taxonomy"

        # Get source routing configuration
        source_routing = get_source_routing_config()
        
        def get_path(file_key):
            return get_source_path_for_file(file_key, env, source_routing)
        
        # Input files with dynamic source routing
        input_files = {
            # Data Office files
            "f35_input": f"{get_path('f35_input')}/F35_*_P60_consview.csv",
            "f15_input": f"{get_path('f15_input')}/F15_*_ChannelView_ProspectView.csv",
            "f45_input": f"{get_path('f45_input')}/F45*.cbaf_utility_1.csv",
            "a40_input": f"{get_path('a40_input')}/A40_*_address_output.csv",
            "a67_input": f"{get_path('a67_input')}/A67_*_cbaf_address.csv",
            "a16_input": f"{get_path('a16_input')}/A16_*_cbaf_utility.csv",
            "a08_input": f"{get_path('a08_input')}/A08_*_absm_master.csv",
            "a01_input": f"{get_path('a01_input')}/A01_*_emsf_master.csv",
            "a44_input": f"{get_path('a44_input')}/A44_*_cbaf_address.csv",
            "20ci_input": f"{get_path('20ci_input')}/TwentyCI_Experian_Digital_*",
            
            # Analytics files
            "r45_input": f"{get_path('r45_input')}/R45*.PostcodeDirectory*.csv",
            "yougov_input": f"{get_path('yougov_input')}/YouGov*.csv",
            "f35_mosaic_input": f"{get_path('f35_mosaic_input')}/F35_MosaicSuite_*.txt",
            "adhoc_suppression": f"{get_path('adhoc_suppression')}/ADHOC_SUPPRESSION.csv",
            "boots_lookup_excel": f"{get_path('boots_lookup_excel')}/Boots_Model_Segments_lookup.xlsx",
            "core_propensities_millitiles": f"{get_path('core_propensities_millitiles')}/Core_Propensities_Millitiles_UK*.txt",
            "core_propensities_cutoffs": f"{get_path('core_propensities_cutoffs')}/Core_Propensities_FlagCutoffs_*.txt",
            "standard_audiences_millitiles": f"{get_path('standard_audiences_millitiles')}/Standard_Audiences*_millitiles.csv",
            "standard_audiences_cutoffs": f"{get_path('standard_audiences_cutoffs')}/Standard_Audiences*_cutoffs.csv",
            "mc_hh_lookup": f"{get_path('mc_hh_lookup')}/mc_hh_Lookup*.csv",
            
            # Client Delivery files
            "auto_segments_excel": f"{get_path('auto_segments_excel')}/Digital_Taxonomy_Master_Layout_created_*.xlsx",
            "20ci_new_lookup": f"{get_path('20ci_new_lookup')}/UPRN_HH_Lookup.csv",
        }

        config_files = {
            "cv_vars_config": f"s3://{code_bucket}/dags/ems-code-consumer-sync-taxonomy/config_aws/cv_vars.json",
            "final_vars_config": f"s3://{code_bucket}/dags/ems-code-consumer-sync-taxonomy/config_aws/final_vars.json",
            "taxonomy_excel_config": f"s3://{code_bucket}/dags/ems-code-consumer-sync-taxonomy/config_aws/taxonomy.xlsx",
            "config_json_path": f"s3://{code_bucket}/dags/ems-code-consumer-sync-taxonomy/config_aws/config.json",
        }

        suppressions_config = {
            "files": [
                {
                    "file_name": input_files["a01_input"],
                    "join_column": "cb_key_db_individual",
                    "stage_name": "EMSF",
                },
                {
                    "file_name": input_files["a16_input"],
                    "join_column": "cb_key_family",
                    "stage_name": "NMR",
                },
            ]
        }

        propensities_config = {
            "iterations": [
                {
                    "data_file_path": input_files["core_propensities_millitiles"],
                    "cutoffs_file_path": input_files["core_propensities_cutoffs"],
                    "old_prefix": "PROP",
                    "delimiter": "|",
                    "output_folder": f"{dt_interim_base_path}/taxonomy/processed/{month_yyyy_mm}/Propensities_millitiles_flagged",
                },
                {
                    "data_file_path": input_files["standard_audiences_millitiles"],
                    "cutoffs_file_path": input_files["standard_audiences_cutoffs"],
                    "old_prefix": "AUDE",
                    "delimiter": ",",
                    "output_folder": f"{dt_interim_base_path}/taxonomy/processed/{month_yyyy_mm}/Consumer_Dynamics_Flagged",
                },
            ],
            "iterations2": [
                {
                    "input_csv_path": input_files["mc_hh_lookup"],
                    "flagged_parquet_path": f"{dt_interim_base_path}/taxonomy/processed/{month_yyyy_mm}/Propensities_millitiles_flagged",
                    "old_prefix": "PROP",
                    "output_path": f"{dt_interim_base_path}/taxonomy/processed/{month_yyyy_mm}/Propensities_millitiles_flagged_HHkey",
                },
                {
                    "input_csv_path": input_files["mc_hh_lookup"],
                    "flagged_parquet_path": f"{dt_interim_base_path}/taxonomy/processed/{month_yyyy_mm}/Consumer_Dynamics_Flagged",
                    "old_prefix": "AUDE",
                    "output_path": f"{dt_interim_base_path}/taxonomy/processed/{month_yyyy_mm}/ConsumerDynamics_millitiles_flagged_HHkey",
                },
            ],
        }

        # Mailable universe configuration with file mappings
        mailable_universe_config = {
            "files": [
                {
                    "file_name": input_files["a40_input"],
                    "join_column": "cb_key_family",
                    "stage_name": "MPS FAMILY",
                },
                {
                    "file_name": input_files["a67_input"],
                    "join_column": "cb_key_db_individual",
                    "stage_name": "MPS INDIVIDUAL",
                },
                {
                    "file_name": input_files["a16_input"],
                    "join_column": "cb_key_family",
                    "stage_name": "NMR",
                },
                {
                    "file_name": input_files["a08_input"],
                    "join_column": "cb_key_db_individual",
                    "stage_name": "Abs Mov",
                },
                {
                    "file_name": input_files["a01_input"],
                    "join_column": "cb_key_db_individual",
                    "stage_name": "EMSF",
                },
                {
                    "file_name": input_files["a44_input"],
                    "join_column": "cb_key_db_individual",
                    "stage_name": "Mortascreen Plus",
                },
            ]
        }

        config_files["suppressions_config"] = suppressions_config
        config_files["propensities_config"] = propensities_config
        config_files["mailable_universe_config"] = mailable_universe_config

        # Use interim bucket for all interim files
        interim_paths = {
            "f15_processed": f"{dt_interim_base_path}/taxonomy/processed/{month_yyyy_mm}/f15_processed.parquet",
            "f45_processed": f"{dt_interim_base_path}/taxonomy/processed/{month_yyyy_mm}/f45_processed.parquet",
            "r45_processed": f"{dt_interim_base_path}/taxonomy/processed/{month_yyyy_mm}/r45_processed.parquet",
            "auto_segments_processed": f"{dt_interim_base_path}/taxonomy/processed/{month_yyyy_mm}/auto_segments_processed.parquet",
            "boots_segments_processed": f"{dt_interim_base_path}/taxonomy/processed/{month_yyyy_mm}/boots_segments_processed.parquet",
            "propensities_processed": f"{dt_interim_base_path}/taxonomy/processed/{month_yyyy_mm}/propensities_processed.parquet",
            "yougov_processed": f"{dt_interim_base_path}/taxonomy/processed/{month_yyyy_mm}/yougov_processed.parquet",
            "20ci_processed": f"{dt_interim_base_path}/taxonomy/processed/{month_yyyy_mm}/20ci_processed.parquet",
            "f35_mosaic_processed": f"{dt_interim_base_path}/taxonomy/processed/{month_yyyy_mm}/f35_mosaic_processed.parquet",
            "propensities_millitiles_flagged": f"{dt_interim_base_path}/taxonomy/processed/{month_yyyy_mm}/Propensities_millitiles_flagged_HHkey",
            "consumer_dynamics_millitiles_flagged": f"{dt_interim_base_path}/taxonomy/processed/{month_yyyy_mm}/ConsumerDynamics_millitiles_flagged_HHkey",
        }

        output_paths = {
            "interim_pyspark_output": f"{dt_interim_base_path}/taxonomy/processed/{month_yyyy_mm}/pyspark_output",
            "final_output_source": f"{PROTOCOL}://{source_bucket}/internal/taxonomy/digital_taxonomy_{month_yyyymm}.txt",
            "final_output_bucket": f"{PROTOCOL}://{output_bucket}/to_client_delivery/digital_taxonomy_{month_yyyymm}.txt",
        }

        # Remove unused stats paths - they're not used anywhere in the pipeline

        all_paths = {**input_files, **config_files, **interim_paths, **output_paths}

        logging.info(f"Using Digital Taxonomy file paths for {month_yyyymm}")

        context["task_instance"].xcom_push(key="DT_INPUT_FILES", value=input_files)
        context["task_instance"].xcom_push(key="DT_CONFIG_FILES", value=config_files)
        context["task_instance"].xcom_push(key="DT_INTERIM_PATHS", value=interim_paths)
        context["task_instance"].xcom_push(key="DT_OUTPUT_PATHS", value=output_paths)

        context["task_instance"].xcom_push(key="DT_ALL_PATHS", value=all_paths)

        required_files = [
            "f35_input",
            "f15_input", 
            "f45_input",
            "r45_input",
            "yougov_input",
            "adhoc_suppression",
            "auto_segments_excel",
            "boots_lookup_excel",
            "20ci_input",
            "20ci_new_lookup",
            "f35_mosaic_input",
            "a40_input",
            "a67_input",
            "a16_input",
            "a08_input",
            "a01_input",
            "a44_input",
            "core_propensities_millitiles",
            "core_propensities_cutoffs",
            "standard_audiences_millitiles",
            "standard_audiences_cutoffs",
            "mc_hh_lookup",
        ]

        missing_files = []
        existing_files = []

        for file_key in required_files:
            file_path = input_files[file_key]
            try:
                bucket_name, key = parse_s3_path(file_path)
                if file_exists_with_pattern(bucket_name, key):
                    existing_files.append(file_key)
                    logging.info(f"Found {file_key} at {file_path}")
                else:
                    missing_files.append(file_key)
                    logging.warning(f"Missing {file_key} at {file_path}")
            except Exception as e:
                missing_files.append(file_key)
                logging.error(f"Error checking {file_key}: {str(e)}")

        context["task_instance"].xcom_push(key="missing_files", value=missing_files)
        context["task_instance"].xcom_push(key="existing_files", value=existing_files)
        context["task_instance"].xcom_push(key="all_files_exist", value=len(missing_files) == 0)

        execution_role_arn = shared.utils.utils.get_emr_serverless_role(env)
        log_uri_prefix = f"s3://{log_bucket}/spark-logs"
        shared_code = [
            f"s3://{code_bucket}/zipped/ems-code-shared.zip,s3://{code_bucket}/packages/openpyxl.zip,s3://{code_bucket}/packages/fsspec.zip,s3://{code_bucket}/packages/s3fs.zip"
        ]
        dt_code_prefix = f"s3://{code_bucket}/repos/ems-code-consumer-sync-taxonomy/spark"

        delimiter_config = get_delimiter_config()
        logging.info(f"Using delimiter configuration: {delimiter_config}")

        context["task_instance"].xcom_push(key="EXECUTION_ROLE_ARN", value=execution_role_arn)
        context["task_instance"].xcom_push(key="LOG_URI_PREFIX", value=log_uri_prefix)
        context["task_instance"].xcom_push(key="SHARED_CODE", value=shared_code)
        context["task_instance"].xcom_push(key="DT_CODE_PREFIX", value=dt_code_prefix)
        context["task_instance"].xcom_push(key="DELIMITER_CONFIG", value=delimiter_config)

        return True

    def initialise(**context):

        logging.info("Initializing EMR Serverless application for Digital Taxonomy")

        emr_subnet_ids = None
        emr_security_group_ids = None

        date = datetime.now().strftime("%Y%m%d%H%M%S")
        emr_application_name = f"digital-taxonomy-{date}"

        logging.info(f"Creating EMR application with name {emr_application_name}")

        app_id = create_emr_application(
            context, emr_application_name, emr_subnet_ids, emr_security_group_ids
        )

        context["task_instance"].xcom_push(key="application_id", value=app_id)
        context["task_instance"].xcom_push(key="emr_application_name", value=emr_application_name)

        logging.info(f"Created EMR application {app_id}")

        end_time = time.time()
        workflow_start_time = context["task_instance"].xcom_pull(
            key="workflow_start_time", task_ids="create_script_arguments"
        )

        logging.info(
            f"Initialisation finished, created {app_id}, time taken: {timedelta(seconds=end_time - workflow_start_time)}"
        )

        return "Executed initialise..."

    def check_inputs_exist(**context):

        from airflow.exceptions import AirflowSkipException

        all_files_exist = context["ti"].xcom_pull(
            key="all_files_exist", task_ids="create_script_arguments"
        )
        missing_files = context["ti"].xcom_pull(
            key="missing_files", task_ids="create_script_arguments"
        )

        if all_files_exist:
            logging.info("All required input files exist, proceeding with processing")
            return True
        else:
            logging.warning(f"Missing required files: {missing_files}")
            # Terminate workflow gracefully when input files are unavailable
            # Implement fail-fast pattern to prevent resource waste on incomplete data
            raise AirflowSkipException(
                f"Skipping processing due to missing required files: {missing_files}"
            )

    def collect_f35_stats(**context):
        """Collect statistics from F35 input file"""
        return collect_file_stats(context, "F35", "f35_input")

    def collect_f15_stats(**context):
        """Collect statistics from F15 input file"""
        return collect_file_stats(context, "F15", "f15_input")

    def collect_f45_stats(**context):
        """Collect statistics from F45 input file"""
        return collect_file_stats(context, "F45", "f45_input")

    def collect_r45_stats(**context):
        """Collect statistics from R45 input file"""
        return collect_file_stats(context, "R45", "r45_input")

    def collect_yougov_stats(**context):
        """Collect statistics from YouGov input file"""
        return collect_file_stats(context, "YouGov", "yougov_input")

    def collect_adhoc_suppression_stats(**context):
        """Collect statistics from ADHOC_SUPPRESSION input file"""
        return collect_file_stats(context, "ADHOC_SUPPRESSION", "adhoc_suppression")

    def collect_20ci_stats(**context):
        """Collect statistics from 20CI input file"""
        return collect_file_stats(context, "20CI", "20ci_input")

    def collect_f35_mosaic_stats(**context):
        """Collect statistics from F35 Mosaic input file"""
        return collect_file_stats(context, "F35_Mosaic", "f35_mosaic_input")

    def collect_a40_stats(**context):
        """Collect statistics from A40 address input file"""
        return collect_file_stats(context, "A40", "a40_input")

    def collect_a67_stats(**context):
        """Collect statistics from A67 CBAF address input file"""
        return collect_file_stats(context, "A67", "a67_input")

    def collect_a16_stats(**context):
        """Collect statistics from A16 CBAF utility input file"""
        return collect_file_stats(context, "A16", "a16_input")

    def collect_a08_stats(**context):
        """Collect statistics from A08 ABS master input file"""
        return collect_file_stats(context, "A08", "a08_input")

    def collect_a01_stats(**context):
        """Collect statistics from A01 EMSF master input file"""
        return collect_file_stats(context, "A01", "a01_input")

    def collect_a44_stats(**context):
        """Collect statistics from A44 CBAF address input file"""
        return collect_file_stats(context, "A44", "a44_input")

    def collect_core_propensities_millitiles_stats(**context):
        """Collect statistics from Core Propensities Millitiles input file"""
        return collect_file_stats(
            context, "Core_Propensities_Millitiles", "core_propensities_millitiles"
        )

    def collect_core_propensities_cutoffs_stats(**context):
        """Collect statistics from Core Propensities Cutoffs input file"""
        return collect_file_stats(
            context, "Core_Propensities_Cutoffs", "core_propensities_cutoffs"
        )

    def collect_standard_audiences_millitiles_stats(**context):
        """Collect statistics from Standard Audiences Millitiles input file"""
        return collect_file_stats(
            context, "Standard_Audiences_Millitiles", "standard_audiences_millitiles"
        )

    def collect_standard_audiences_cutoffs_stats(**context):
        """Collect statistics from Standard Audiences Cutoffs input file"""
        return collect_file_stats(
            context, "Standard_Audiences_Cutoffs", "standard_audiences_cutoffs"
        )

    def collect_mc_hh_lookup_stats(**context):
        """Collect statistics from MC HH Lookup input file"""
        return collect_file_stats(context, "MC_HH_Lookup", "mc_hh_lookup")

    def collect_20ci_new_lookup_stats(**context):
        """Collect statistics from 20CI New Lookup (UPRN_HH_Lookup) input file"""
        return collect_file_stats(context, "20CI_New_Lookup", "20ci_new_lookup")

    def collect_file_stats(context, file_name: str, file_key: str):

        from shared.utils.emr_application_factory import start_emr_job

        start_time = time.time()

        app_id = context["task_instance"].xcom_pull(key="application_id", task_ids="initialise")

        EXECUTION_ROLE_ARN = context["task_instance"].xcom_pull(
            key="EXECUTION_ROLE_ARN", task_ids="create_script_arguments"
        )
        LOG_URI_PREFIX = context["task_instance"].xcom_pull(
            key="LOG_URI_PREFIX", task_ids="create_script_arguments"
        )
        SHARED_CODE = context["task_instance"].xcom_pull(
            key="SHARED_CODE", task_ids="create_script_arguments"
        )
        DT_CODE_PREFIX = context["task_instance"].xcom_pull(
            key="DT_CODE_PREFIX", task_ids="create_script_arguments"
        )

        input_files = context["task_instance"].xcom_pull(
            key="DT_INPUT_FILES", task_ids="create_script_arguments"
        )

        execution_date = context["task_instance"].xcom_pull(
            key="execution_date", task_ids="create_script_arguments"
        )

        stats_script = f"{DT_CODE_PREFIX}/get_stats_emr.py"

        # Get stats bucket for dynamic path
        stats_bucket = context["task_instance"].xcom_pull(
            key="stats_bucket", task_ids="create_script_arguments"
        )
        stats_path = f"s3://{stats_bucket}/get_stats"

        input_file_pattern = input_files[file_key]
        if input_file_pattern.startswith("s3a://"):
            input_file_pattern = input_file_pattern.replace("s3a://", "s3://")

        input_file_path = resolve_s3_pattern(input_file_pattern)
        if not input_file_path:
            raise ValueError(f"No file found matching pattern: {input_file_pattern}")

        logging.info(
            f"Collecting stats for {file_name} input file: {input_file_path} (resolved from {input_file_pattern})"
        )
        logging.info(f"Stats will be written to: {stats_path}")

        job = start_emr_job(
            task_id=f"collect_{file_name.lower()}_stats",
            application_id=app_id,
            execution_role_arn=EXECUTION_ROLE_ARN,
            job_driver={
                "sparkSubmit": {
                    "entryPoint": stats_script,
                    "entryPointArguments": ["-m", execution_date, "-if", input_file_path, "-sp", stats_path],
                    "sparkSubmitParameters": f"--conf spark.submit.pyFiles={','.join(SHARED_CODE) if isinstance(SHARED_CODE, list) else SHARED_CODE}",
                }
            },
            configuration_overrides={
                "monitoringConfiguration": {
                    "s3MonitoringConfiguration": {
                        "logUri": f"{LOG_URI_PREFIX}/digital_taxonomy_{file_name.lower()}_stats",
                    }
                }
            },
        )

        job_id = job.execute(get_current_context())

        end_time = time.time()
        logging.info(
            f"{file_name} stats collection finished, time taken: {timedelta(seconds=end_time - start_time)}"
        )

        return f"Executed {file_name} stats collection: {job_id}"

    def run_f15_processing(**context):
        """Execute F15 processing EMR job"""
        return run_processing_script(
            context,
            "F15",
            "process_file_F15_emr.py",
            {
                "--input_path": "f15_input",
                "--output_path": "f15_processed",
                "--suppressions_config": "suppressions_config",
            },
        )

    def run_f45_processing(**context):
        """Execute F45 processing EMR job"""
        return run_processing_script(
            context,
            "F45",
            "process_file_F45_emr.py",
            {"--input_path": "f45_input", "--output_path": "f45_processed"},
        )

    def run_r45_processing(**context):
        """Execute R45 processing EMR job"""
        return run_processing_script(
            context,
            "R45",
            "process_file_R45_emr.py",
            {"--input_path": "r45_input", "--output_path": "r45_processed"},
        )

    def run_auto_segments_processing(**context):
        """Execute Auto Segments processing EMR job"""
        return run_processing_script(
            context,
            "AutoSegments",
            "process_file_auto_segments_emr.py",
            {"--input_path": "auto_segments_excel", "--output_path": "auto_segments_processed"},
        )

    def run_boots_segments_processing(**context):
        """Execute Boots Segments processing EMR job"""
        return run_processing_script(
            context,
            "BootsSegments",
            "process_file_boots_segments_emr.py",
            {
                "--f35_input_path": "f35_input",
                "--boots_lookup_path": "boots_lookup_excel",
                "--output_path": "boots_segments_processed",
            },
        )

    def run_propensities_processing(**context):
        """Execute Propensities processing EMR job"""
        return run_processing_script(
            context,
            "Propensities",
            "process_file_propensities_segments_emr.py",
            {
                "--f35_input_path": "f35_input",
                "--f45_input_path": "f45_input",
                "--config_path": "propensities_config",
                "--prop_millitiles_path": "propensities_millitiles_flagged",
                "--cons_dynamics_path": "consumer_dynamics_millitiles_flagged",
                "--output_path": "propensities_processed",
            },
        )

    def run_yougov_processing(**context):
        """Execute YouGov processing EMR job"""
        return run_processing_script(
            context,
            "YouGov",
            "process_file_yougov_emr.py",
            {"--input_path": "yougov_input", "--output_path": "yougov_processed"},
        )

    def run_20ci_processing(**context):
        """Execute 20ci processing EMR job"""
        return run_processing_script(
            context,
            "20CI",
            "process_file_20ci_emr.py",
            {
                "--input_path_20ci": "20ci_input",
                "--input_path_new_lookup": "20ci_new_lookup",
                "--output_path": "20ci_processed",
            },
        )

    def run_f35_mosaic_processing(**context):
        """Execute F35 Mosaic processing EMR job"""
        return run_processing_script(
            context,
            "F35Mosaic",
            "process_file_F35_mosaic_emr.py",
            {"--input_path": "f35_mosaic_input", "--output_path": "f35_mosaic_processed"},
        )

    def run_processing_script(context, script_name: str, script_file: str, arg_mapping: dict):
        """
        Generic function to run processing scripts

        Args:
            context: Airflow task context
            script_name: Name of the script for logging
            script_file: EMR script filename
            arg_mapping: Dictionary mapping argument names to path keys

        Returns:
            Job execution result
        """
        from shared.utils.emr_application_factory import start_emr_job

        start_time = time.time()

        app_id = context["task_instance"].xcom_pull(key="application_id", task_ids="initialise")

        EXECUTION_ROLE_ARN = context["task_instance"].xcom_pull(
            key="EXECUTION_ROLE_ARN", task_ids="create_script_arguments"
        )
        LOG_URI_PREFIX = context["task_instance"].xcom_pull(
            key="LOG_URI_PREFIX", task_ids="create_script_arguments"
        )
        SHARED_CODE = context["task_instance"].xcom_pull(
            key="SHARED_CODE", task_ids="create_script_arguments"
        )
        DT_CODE_PREFIX = context["task_instance"].xcom_pull(
            key="DT_CODE_PREFIX", task_ids="create_script_arguments"
        )

        # Get all paths
        all_paths = context["task_instance"].xcom_pull(
            key="DT_ALL_PATHS", task_ids="create_script_arguments"
        )

        # Get delimiter configuration
        delimiter_config = context["task_instance"].xcom_pull(
            key="DELIMITER_CONFIG", task_ids="create_script_arguments"
        )

        # Build job arguments, resolving S3 wildcards for input paths
        job_args = []
        for arg_name, path_key in arg_mapping.items():
            if path_key in all_paths:
                value = all_paths[path_key]
                # If this is an S3 path and contains a wildcard, resolve it
                if isinstance(value, str) and value.startswith("s3") and "*" in value:
                    resolved_value = resolve_s3_pattern(value)
                    if not resolved_value:
                        logging.error(f"No file found matching pattern: {value}")
                        raise ValueError(f"Missing file for pattern: {value}")
                    value = resolved_value
                # Convert dictionary/object values to JSON strings
                if isinstance(value, (dict, list)):
                    value = json.dumps(value)
                job_args.extend([arg_name, value])
            else:
                logging.error(f"Path key {path_key} not found in all_paths")
                raise ValueError(f"Missing path: {path_key}")

        # Add delimiter configuration to all processing scripts
        job_args.extend(["--delimiter_config", json.dumps(delimiter_config)])
        logging.info(f"Added delimiter configuration to {script_name}: {delimiter_config}")

        script_path = f"{DT_CODE_PREFIX}/{script_file}"

        logging.info(f"Running {script_name} processing with script: {script_path}")
        logging.info(f"Job arguments: {job_args}")

        # Run the EMR job
        job = start_emr_job(
            task_id=f"run_{script_name.lower()}_processing",
            application_id=app_id,
            execution_role_arn=EXECUTION_ROLE_ARN,
            job_driver={
                "sparkSubmit": {
                    "entryPoint": script_path,
                    "entryPointArguments": job_args,
                    "sparkSubmitParameters": f"--conf spark.submit.pyFiles={','.join(SHARED_CODE) if isinstance(SHARED_CODE, list) else SHARED_CODE}",
                },
            },
            configuration_overrides={
                "monitoringConfiguration": {
                    "s3MonitoringConfiguration": {
                        "logUri": f"{LOG_URI_PREFIX}/digital_taxonomy_{script_name.lower()}",
                    },
                }
            },
        )

        job_id = job.execute(get_current_context())

        end_time = time.time()
        logging.info(
            f"{script_name} processing finished, time taken: {timedelta(seconds=end_time - start_time)}"
        )

        return f"Executed {script_name} processing: {job_id}"

    def run_main_processing(**context):
        """
        Execute the main Digital Taxonomy processing task

        Args:
            context: Airflow task context

        Returns:
            Message indicating completion
        """
        from shared.utils.emr_application_factory import start_emr_job

        start_time = time.time()

        app_id = context["task_instance"].xcom_pull(key="application_id", task_ids="initialise")

        EXECUTION_ROLE_ARN = context["task_instance"].xcom_pull(
            key="EXECUTION_ROLE_ARN", task_ids="create_script_arguments"
        )
        LOG_URI_PREFIX = context["task_instance"].xcom_pull(
            key="LOG_URI_PREFIX", task_ids="create_script_arguments"
        )
        SHARED_CODE = context["task_instance"].xcom_pull(
            key="SHARED_CODE", task_ids="create_script_arguments"
        )
        DT_CODE_PREFIX = context["task_instance"].xcom_pull(
            key="DT_CODE_PREFIX", task_ids="create_script_arguments"
        )

        # Get all paths
        all_paths = context["task_instance"].xcom_pull(
            key="DT_ALL_PATHS", task_ids="create_script_arguments"
        )

        # Get resolved config files
        config_files = context["task_instance"].xcom_pull(
            key="DT_CONFIG_FILES", task_ids="create_script_arguments"
        )

        # Get delimiter configuration
        delimiter_config = context["task_instance"].xcom_pull(
            key="DELIMITER_CONFIG", task_ids="create_script_arguments"
        )

        # Get environment parameters for template resolution
        source_bucket = context["task_instance"].xcom_pull(
            key="source_bucket", task_ids="create_script_arguments"
        )
        month_yyyy_mm = context["task_instance"].xcom_pull(
            key="month_yyyy_mm", task_ids="create_script_arguments"
        )

        # Get stats bucket for signoff validation
        stats_bucket = context["task_instance"].xcom_pull(
            key="stats_bucket", task_ids="create_script_arguments"
        )

        # Get enable_validation from DAG params (default: True)
        enable_validation = context["params"].get("enable_validation", True)
        enable_validation_str = "true" if enable_validation else "false"

        # Build job arguments for main processing
        job_args = [
            "--f35_input_path",
            all_paths["f35_input"],
            "--adhoc_suppression_path",
            all_paths["adhoc_suppression"],
            "--f15_processed_path",
            all_paths["f15_processed"],
            "--f45_processed_path",
            all_paths["f45_processed"],
            "--r45_processed_path",
            all_paths["r45_processed"],
            "--auto_segments_processed_path",
            all_paths["auto_segments_processed"],
            "--boots_segments_processed_path",
            all_paths["boots_segments_processed"],
            "--propensities_processed_path",
            all_paths["propensities_processed"],
            "--yougov_processed_path",
            all_paths["yougov_processed"],
            "--twenty_ci_processed_path",
            all_paths["20ci_processed"],
            "--f35_mosaic_processed_path",
            all_paths["f35_mosaic_processed"],
            "--mailable_universe_config",
            json.dumps(config_files["mailable_universe_config"]),
            "--cv_vars_config",
            all_paths["cv_vars_config"],
            "--final_vars_config",
            all_paths["final_vars_config"],
            "--taxonomy_excel_config",
            all_paths["taxonomy_excel_config"],
            "--config_json_path",
            all_paths["config_json_path"],
            "--source_bucket",
            source_bucket,
            "--month_yyyy_mm",
            month_yyyy_mm,
            "--interim_output_path",
            all_paths["interim_pyspark_output"],
            "--final_output_source_path",
            all_paths["final_output_source"],
            "--final_output_bucket_path",
            all_paths["final_output_bucket"],
            "--delimiter_config",
            json.dumps(delimiter_config),
            "--stats_bucket",
            stats_bucket,
            "--enable_validation",
            enable_validation_str,
        ]

        main_script = f"{DT_CODE_PREFIX}/main_emr.py"
        signoff_stats_script = f"{DT_CODE_PREFIX}/signoff_stats.py"

        logging.info(f"Running main Digital Taxonomy processing")

        # Set the parameters for the EMR job
        # job = start_emr_job(
        #     task_id="run_main_processing",
        #     application_id=app_id,
        #     execution_role_arn=EXECUTION_ROLE_ARN,
        #     job_driver={
        #         "sparkSubmit": {
        #             "entryPoint": main_script,
        #             "entryPointArguments": job_args,
        #             "sparkSubmitParameters": f"--conf spark.submit.pyFiles={','.join(SHARED_CODE) if isinstance(SHARED_CODE, list) else SHARED_CODE}",
        #         },
        #     },
        #     configuration_overrides={
        #         "monitoringConfiguration": {
        #             "s3MonitoringConfiguration": {
        #                 "logUri": f"{LOG_URI_PREFIX}/digital_taxonomy_main",
        #             },
        #         }
        #     },
        # )

        from airflow.providers.amazon.aws.operators.emr import EmrServerlessStartJobOperator

        # Build pyFiles list including signoff_stats.py for validation
        py_files_list = SHARED_CODE if isinstance(SHARED_CODE, list) else [SHARED_CODE]
        py_files_list = py_files_list + [signoff_stats_script]
        py_files_str = ",".join(py_files_list)

        job = EmrServerlessStartJobOperator(
            task_id="run_main_processing_emr",
            application_id=app_id,
            execution_role_arn=EXECUTION_ROLE_ARN,
            job_driver={
                "sparkSubmit": {
                    "entryPoint": main_script,
                    "entryPointArguments": job_args,
                    "sparkSubmitParameters": f"--conf spark.submit.pyFiles={py_files_str} --conf spark.sql.adaptive.enabled=true --conf spark.sql.adaptive.coalescePartitions.enabled=true --conf spark.serializer=org.apache.spark.serializer.KryoSerializer --conf spark.sql.execution.arrow.pyspark.enabled=false",
                },
            },
            configuration_overrides={
                # "applicationConfiguration": [
                #     {
                #         "classification": "spark-defaults",
                #         "properties": {
                #             "spark.executor.instances": "36",
                #             "spark.executor.cores": "8",
                #             "spark.executor.memory": "52g",
                #             "spark.driver.cores": "4",
                #             "spark.driver.memory": "32g",
                #             "spark.driver.memoryOverhead": "4g",
                #             "spark.driver.maxResultSize": "16g",
                #             "spark.sql.shuffle.partitions": "200",
                #             "spark.default.parallelism": "80",
                #         }
                #     }
                # ],
                "monitoringConfiguration": {
                    "s3MonitoringConfiguration": {
                        "logUri": f"{LOG_URI_PREFIX}/digital_taxonomy_main",
                    }
                }
            },
            wait_for_completion=True,
            waiter_delay=600,
            waiter_max_attempts=2400,  # 4 hours
            aws_conn_id="aws_default",
            dag=dag,
        )

        job_id = job.execute(get_current_context())

        end_time = time.time()
        logging.info(
            f"Main processing finished, time taken: {timedelta(seconds=end_time - start_time)}"
        )

        return f"Executed Digital Taxonomy main processing: {job_id}"

    def rename_output_files(**context):
        """
        Rename part files to single .txt files in the output locations.
        Spark saves as folder with part-00000 files, we need single .txt files.
        """
        import boto3

        s3 = boto3.client("s3")

        output_paths = context["task_instance"].xcom_pull(
            key="DT_OUTPUT_PATHS", task_ids="create_script_arguments"
        )

        # Process both output locations
        output_locations = [
            output_paths["final_output_source"],
            output_paths["final_output_bucket"],
        ]

        for output_path in output_locations:
            try:
                # Parse S3 path
                if output_path.startswith("s3://"):
                    path_without_prefix = output_path[5:]
                elif output_path.startswith("s3a://"):
                    path_without_prefix = output_path[6:]
                else:
                    path_without_prefix = output_path

                bucket = path_without_prefix.split("/")[0]
                key = "/".join(path_without_prefix.split("/")[1:])

                # The spark output creates a folder, find the part file inside
                folder_key = key  # e.g., to_client_delivery/digital_taxonomy_202511.txt
                
                logging.info(f"Looking for part files in s3://{bucket}/{folder_key}/")

                # List objects in the folder
                response = s3.list_objects_v2(Bucket=bucket, Prefix=f"{folder_key}/")

                if "Contents" not in response:
                    logging.warning(f"No files found in {folder_key}/")
                    continue

                # Find the part file (not _SUCCESS or other metadata)
                part_file_key = None
                for obj in response["Contents"]:
                    obj_key = obj["Key"]
                    if "part-" in obj_key and not obj_key.endswith("_SUCCESS"):
                        part_file_key = obj_key
                        break

                if not part_file_key:
                    logging.warning(f"No part file found in {folder_key}/")
                    continue

                logging.info(f"Found part file: {part_file_key}")

                # Copy part file to the correct location (without folder)
                final_key = key  # e.g., to_client_delivery/digital_taxonomy_202511.txt
                
                logging.info(f"Copying {part_file_key} to {final_key}")
                s3.copy_object(
                    Bucket=bucket,
                    CopySource={"Bucket": bucket, "Key": part_file_key},
                    Key=final_key,
                )

                # Delete all files in the old folder
                logging.info(f"Deleting folder {folder_key}/")
                for obj in response["Contents"]:
                    s3.delete_object(Bucket=bucket, Key=obj["Key"])

                logging.info(f"Successfully renamed output to s3://{bucket}/{final_key}")

            except Exception as e:
                logging.error(f"Error renaming output file {output_path}: {str(e)}")
                raise

        return "Output files renamed successfully"

    def finalise(**context):
        """
        Delete EMR Serverless application and log workflow completion

        Args:
            context: Airflow task context

        Returns:
            Message indicating completion
        """
        logging.info("Finalizing EMR application")

        app_id = context["task_instance"].xcom_pull(key="application_id", task_ids="initialise")
        emr_application_name = context["task_instance"].xcom_pull(
            key="emr_application_name", task_ids="initialise"
        )
        workflow_start_time = context["task_instance"].xcom_pull(
            key="workflow_start_time", task_ids="create_script_arguments"
        )

        logging.info(f"Finalization started, deleting application {app_id}")

        # Delete EMR application
        delete_emr_application(context, emr_application_name, app_id)

        end_time = time.time()
        logging.info(
            f"Digital Taxonomy workflow finished, time taken: {timedelta(seconds=end_time - workflow_start_time)}"
        )

        return "Finalized EMR application"

    def send_input_stats_email(**context):

        import boto3
        import tempfile
        import os

        # Get stats bucket dynamically from xcom (set in create_script_arguments)
        STATS_BUCKET = context["task_instance"].xcom_pull(
            key="stats_bucket", task_ids="create_script_arguments"
        )

        current_date = datetime.now()
        mask = current_date.strftime("%Y-%m-%d")

        # Calculate week start date
        week_start_date = (current_date - timedelta(days=current_date.weekday())).strftime(
            "%Y-%m-%d"
        )
        if current_date.weekday() == 0:
            week_start_date = mask

        logging.info(
            f"Sending consolidated input stats email for date: {mask}, week start: {week_start_date}"
        )

        # Get recipients from DAG params
        recipients = [context["params"].get("email_to", "kallusrujan.reddy@experian.com")]

        try:
            # Initialize S3 client
            s3 = boto3.client("s3")

            # Check for alerts first (any of the get_stats_emr.py calls could have created alerts)
            alert_data_path = f"get_stats/{week_start_date}/alert_data_{mask}.json"
            try:
                alert_response = s3.get_object(Bucket=STATS_BUCKET, Key=alert_data_path)
                alert_data = json.loads(alert_response["Body"].read().decode("utf-8"))

                # Send alert email
                alert_subject = alert_data.get(
                    "subject", f"Digital Taxonomy Input Alert for {mask}"
                )
                alert_message = alert_data.get(
                    "alert_message", "An alert was triggered during input processing"
                )

                alert_email = EmailOperator(
                    task_id="send_alert_email",
                    to=recipients,
                    subject=alert_subject,
                    html_content=f"""
                    <h2>Digital Taxonomy Input Processing Alert</h2>
                    <p><strong>Date:</strong> {mask}</p>
                    <p><strong>Alert:</strong> {alert_message}</p>
                    <p>Please check the logs for more details.</p>
                    <p><em>This is an automated message from the Digital Taxonomy system.</em></p>
                    """,
                    dag=dag,
                )

                alert_email.execute(context=context)
                logging.info(f"Sent alert email for {mask}")

            except Exception as alert_err:
                logging.info(f"No alerts found: {str(alert_err)}")

            # The get_stats_emr.py script consolidates all stats into one CSV file and creates JSON
            # Look for the consolidated email JSON data first
            email_data_path = (
                f"get_stats/{week_start_date}/email_data_weekly_{week_start_date}.json"
            )
            try:
                logging.info(f"Looking for consolidated email JSON data at {email_data_path}")
                email_response = s3.get_object(Bucket=STATS_BUCKET, Key=email_data_path)
                email_data = json.loads(email_response["Body"].read().decode("utf-8"))

                # Send consolidated stats email
                email_subject = email_data.get(
                    "subject", f"Digital Taxonomy Input Statistics for {mask}"
                )
                email_content = email_data.get(
                    "html_content", f"<p>No detailed statistics available for {mask}</p>"
                )

                # Customize the subject for Digital Taxonomy
                email_subject = f"*** Digital Taxonomy Input Statistics *** - {mask}"

                stats_email = EmailOperator(
                    task_id="send_input_stats_email_json",
                    to=recipients,
                    subject=email_subject,
                    html_content=email_content,
                    dag=dag,
                )

                stats_email.execute(context=context)
                logging.info(f"Sent consolidated input stats email using JSON data")

                return f"Sent consolidated input stats email for {mask} using JSON data"

            except Exception as json_err:
                logging.warning(f"No email JSON found, trying CSV file: {str(json_err)}")

                # FALLBACK: Try the consolidated CSV file created by get_stats_emr.py
                stats_file_key = (
                    f"get_stats/{week_start_date}/pipeline_stats__{week_start_date}.csv"
                )
                try:
                    logging.info(f"Looking for consolidated CSV file at {stats_file_key}")
                    with tempfile.NamedTemporaryFile(delete=False, suffix=".csv") as temp_file:
                        s3.download_fileobj(STATS_BUCKET, stats_file_key, temp_file)
                        temp_file_path = temp_file.name

                    # Send the email using Airflow's EmailOperator with CSV attachment
                    email_op = EmailOperator(
                        task_id="send_input_stats_email_with_attachment",
                        to=recipients,
                        subject=f"*** Digital Taxonomy Input Statistics *** - {mask}",
                        html_content=f"""
                        <h2>Digital Taxonomy Input Statistics Report - {mask}</h2>
                        <p>Please find attached the consolidated input statistics report covering all major input files:</p>
                        <ul>
                            <li>F35 - Consumer View (main file)</li>
                            <li>F15 - Email Prospects</li>
                            <li>F45 - CBAF Utility Data</li>
                            <li>R45 - Postcode Directory</li>
                            <li>YouGov - Survey Data</li>
                        </ul>
                        <p><em>This is an automated message from the Digital Taxonomy processing system.</em></p>
                        """,
                        files=[temp_file_path],
                        dag=dag,
                    )

                    email_op.execute(context=context)

                    # Clean up the temporary file
                    os.unlink(temp_file_path)

                    logging.info(f"Sent consolidated input stats email with CSV attachment")
                    return f"Sent consolidated input stats email with CSV attachment for {mask}"

                except Exception as csv_err:
                    logging.warning(f"Error with CSV file: {str(csv_err)}")

                    # LAST RESORT: Send basic email
                    basic_email = EmailOperator(
                        task_id="send_basic_input_email",
                        to=recipients,
                        subject=f"*** Digital Taxonomy Input Statistics Summary *** - {mask}",
                        html_content=f"""
                        <h2>Digital Taxonomy Input Statistics Summary</h2>
                        <p>Input statistics were collected for {mask} covering all major input files, but a detailed report is not available.</p>
                        <p>Statistics were collected for: F35, F15, F45, R45, and YouGov input files.</p>
                        <p>Please check the logs for more details.</p>
                        <p><em>This is an automated message from the Digital Taxonomy processing system.</em></p>
                        """,
                        dag=dag,
                    )

                    basic_email.execute(context=context)
                    logging.info(f"Sent basic input stats email")

                    return f"Sent basic input stats email for {mask}"

        except Exception as e:
            logging.error(f"Error sending consolidated input stats email: {str(e)}")
            return f"Error sending consolidated input stats email: {str(e)}"

    def send_completion_email(**context):
        """
        Send completion notification email with processing summary

        Args:
            context: Airflow task context

        Returns:
            Message indicating completion
        """
        # Get current date for email subject
        current_date = datetime.now()
        date_str = current_date.strftime("%Y-%m-%d")
        month_str = context["task_instance"].xcom_pull(
            key="month_yyyy_mm", task_ids="create_script_arguments"
        )

        # Get recipients from DAG params
        recipients = [context["params"].get("email_to", "kallusrujan.reddy@experian.com")]

        # Get final output paths
        output_paths = context["task_instance"].xcom_pull(
            key="DT_OUTPUT_PATHS", task_ids="create_script_arguments"
        )
        final_output_source = output_paths.get("final_output_source", "N/A")
        final_output_bucket = output_paths.get("final_output_bucket", "N/A")

        html_content = f"""
        <html>
        <body>
            <h2>*** Digital Taxonomy Processing Complete *** - {date_str}</h2>
            <p><strong>Processing Month:</strong> {month_str}</p>
            <p><strong>Output Locations:</strong></p>
            <ul>
                <li><strong>Internal Archive:</strong> {final_output_source}</li>
                <li><strong>Client Delivery:</strong> {final_output_bucket}</li>
            </ul>
            <p><strong>Status:</strong> Successfully Completed</p>
            <br>
            <h3>Processing Summary:</h3>
            <ul>
                <li>✅ F15 - Email Prospects Processed</li>
                <li>✅ F45 - CBAF Utility Data Processed</li>
                <li>✅ R45 - Postcode Directory Processed</li>
                <li>✅ Auto Segments - Mosaic Segments Processed</li>
                <li>✅ Boots Segments - Shopper Types Processed</li>
                <li>✅ Propensities - Millitiles & Cutoffs Processed</li>
                <li>✅ YouGov - Survey Data Processed</li>
                <li>✅ Mosaic 8 - Taxonomy Groups Processed</li>
                <li>✅ Main Processing - All audiences joined with F35</li>
                <li>✅ C-Variables - Taxonomy rules applied</li>
                <li>✅ Final Output - Digital taxonomy file created</li>
            </ul>
            <br>
            <p>The Digital Taxonomy processing has completed successfully.</p>
            <p>All component audiences have been processed and joined to create the final taxonomy.</p>
            <br>
            <p><em>This is an automated message from the Digital Taxonomy processing system.</em></p>
        </body>
        </html>
        """

        # Send the email
        email_op = EmailOperator(
            task_id="send_completion_email_task",
            to=recipients,
            subject=f"*** Digital Taxonomy Processing Complete *** - {date_str}",
            html_content=html_content,
            dag=dag,
        )

        email_op.execute(context=context)

        logging.info(f"Sent completion email for {date_str}")
        return f"Sent completion email for {date_str}"

    def send_failure_email(**context):
        """
        Send failure notification email when any task fails.
        Reads validation_result.json from S3 if available to include detailed reasons.

        Args:
            context: Airflow task context

        Returns:
            Message indicating completion
        """
        import boto3
        
        # Get current date for email subject
        current_date = datetime.now()
        date_str = current_date.strftime("%Y-%m-%d")
        month_str = context["task_instance"].xcom_pull(
            key="month_yyyy_mm", task_ids="create_script_arguments"
        )

        # Get recipients from DAG params
        recipients = [context["params"].get("email_to", "kallusrujan.reddy@experian.com")]

        # Get failed task info from context
        failed_task_ids = [
            task.task_id
            for task in context["dag_run"].get_task_instances()
            if task.state == "failed"
        ]
        
        # Try to read validation result from S3 for detailed reasons
        validation_reasons_html = ""
        validation_subject = None
        
        try:
            stats_bucket = context["task_instance"].xcom_pull(
                key="stats_bucket", task_ids="create_script_arguments"
            )
            current_month = month_str.replace("-", "") if month_str else ""
            
            if stats_bucket and current_month:
                s3 = boto3.client("s3")
                result_key = f"taxonomy_signoff/{current_month}/validation_result.json"
                
                try:
                    response = s3.get_object(Bucket=stats_bucket, Key=result_key)
                    validation_data = json.loads(response["Body"].read().decode("utf-8"))
                    
                    # Check if this was a signoff validation failure
                    if not validation_data.get("passed", True):
                        reasons = validation_data.get("reasons", [])
                        total_rows = validation_data.get("total_rows", 0)
                        
                        # Use the pre-formatted email if available
                        email_data = validation_data.get("email", {})
                        if email_data.get("subject"):
                            validation_subject = email_data.get("subject")
                        
                        # Build reasons HTML
                        if reasons:
                            validation_reasons_html = f"""
                            <h3 style="color: red;">⚠️ Signoff Validation Failed</h3>
                            <p><strong>❌ FILE NOT DELIVERED TO CLIENT</strong></p>
                            <p><strong>Total Rows:</strong> {total_rows:,}</p>
                            <p><strong>Validation Issues ({len(reasons)}):</strong></p>
                            <ul>
                            """
                            for reason in reasons:
                                validation_reasons_html += f"<li>{reason}</li>\n"
                            validation_reasons_html += "</ul>"
                            
                            # Add flagged columns detail if available
                            flagged_cols = validation_data.get("flagged_columns", [])
                            if flagged_cols:
                                validation_reasons_html += """
                                <h4>Flagged Columns Detail:</h4>
                                <table border="1" style="border-collapse: collapse;">
                                <tr><th>Column</th><th>Prev Nulls</th><th>Curr Nulls</th><th>Change</th><th>% Change</th></tr>
                                """
                                for col in flagged_cols[:20]:  # Limit to 20 columns
                                    validation_reasons_html += f"""
                                    <tr>
                                        <td>{col.get('column_name', 'N/A')}</td>
                                        <td>{col.get('prev_null_values', 0):,}</td>
                                        <td>{col.get('curr_null_values', 0):,}</td>
                                        <td>{col.get('diff_null_values', 0):+,}</td>
                                        <td>{col.get('pct_change_null_values', 0):+.1f}%</td>
                                    </tr>
                                    """
                                validation_reasons_html += "</table>"
                                if len(flagged_cols) > 20:
                                    validation_reasons_html += f"<p><em>...and {len(flagged_cols) - 20} more columns</em></p>"
                        
                        logging.info(f"Loaded validation result with {len(reasons)} reasons")
                        
                except Exception as e:
                    logging.warning(f"Could not load validation result: {e}")
                    
        except Exception as e:
            logging.warning(f"Error getting stats bucket: {e}")

        # Build email content
        html_content = f"""
        <html>
        <body>
            <h2 style="color: red;">*** Digital Taxonomy Processing FAILED *** - {date_str}</h2>
            <p><strong>Processing Month:</strong> {month_str}</p>
            <p><strong>Status:</strong> ❌ Processing Failed</p>
            <p><strong>Failed Tasks:</strong> {', '.join(failed_task_ids) if failed_task_ids else 'Unknown'}</p>
            {validation_reasons_html}
            <br>
            <p style="color: red;">The Digital Taxonomy processing has failed and requires attention.</p>
            <p>Please check the Airflow logs for more details on the failure.</p>
            <p><em>This is an automated message from the Digital Taxonomy processing system.</em></p>
        </body>
        </html>
        """
        
        # Use validation subject if available
        email_subject = validation_subject if validation_subject else f"*** Digital Taxonomy Processing FAILED *** - {date_str}"

        # Send the email
        email_op = EmailOperator(
            task_id="send_failure_email_task",
            to=recipients,
            subject=email_subject,
            html_content=html_content,
            dag=dag,
        )

        email_op.execute(context=context)

        logging.info(f"Sent failure email for {date_str}")
        return f"Sent failure email for {date_str}"

    # Define tasks

    # Start task
    start = DummyOperator(task_id="start")

    # Create script arguments
    task_create_arguments = PythonOperator(
        task_id="create_script_arguments",
        python_callable=create_script_arguments,
        trigger_rule="none_failed",
        dag=dag,
    )

    # Initialize EMR application
    task_initialise = PythonOperator(
        task_id="initialise",
        python_callable=initialise,
        trigger_rule="none_failed",
        dag=dag,
    )

    # Check if inputs exist
    check_inputs = PythonOperator(
        task_id="check_inputs",
        python_callable=check_inputs_exist,
        dag=dag,
    )

    # Handle case where inputs are missing
    inputs_missing = DummyOperator(
        task_id="inputs_missing",
        trigger_rule="all_skipped",  # Only runs if check_inputs is skipped
        dag=dag,
    )
    # Collect input statistics for each major file (run sequentially)
    task_collect_f35_stats = PythonOperator(
        task_id="collect_f35_stats",
        python_callable=collect_f35_stats,
        trigger_rule="none_failed",
        dag=dag,
    )

    task_collect_f15_stats = PythonOperator(
        task_id="collect_f15_stats",
        python_callable=collect_f15_stats,
        trigger_rule="none_failed",
        dag=dag,
    )

    task_collect_f45_stats = PythonOperator(
        task_id="collect_f45_stats",
        python_callable=collect_f45_stats,
        trigger_rule="none_failed",
        dag=dag,
    )

    task_collect_r45_stats = PythonOperator(
        task_id="collect_r45_stats",
        python_callable=collect_r45_stats,
        trigger_rule="none_failed",
        dag=dag,
    )

    task_collect_yougov_stats = PythonOperator(
        task_id="collect_yougov_stats",
        python_callable=collect_yougov_stats,
        trigger_rule="none_failed",
        dag=dag,
    )

    task_collect_adhoc_suppression_stats = PythonOperator(
        task_id="collect_adhoc_suppression_stats",
        python_callable=collect_adhoc_suppression_stats,
        trigger_rule="none_failed",
        dag=dag,
    )

    task_collect_20ci_stats = PythonOperator(
        task_id="collect_20ci_stats",
        python_callable=collect_20ci_stats,
        trigger_rule="none_failed",
        dag=dag,
    )

    task_collect_f35_mosaic_stats = PythonOperator(
        task_id="collect_f35_mosaic_stats",
        python_callable=collect_f35_mosaic_stats,
        trigger_rule="none_failed",
        dag=dag,
    )

    task_collect_a40_stats = PythonOperator(
        task_id="collect_a40_stats",
        python_callable=collect_a40_stats,
        trigger_rule="none_failed",
        dag=dag,
    )

    task_collect_a67_stats = PythonOperator(
        task_id="collect_a67_stats",
        python_callable=collect_a67_stats,
        trigger_rule="none_failed",
        dag=dag,
    )

    task_collect_a16_stats = PythonOperator(
        task_id="collect_a16_stats",
        python_callable=collect_a16_stats,
        trigger_rule="none_failed",
        dag=dag,
    )

    task_collect_a08_stats = PythonOperator(
        task_id="collect_a08_stats",
        python_callable=collect_a08_stats,
        trigger_rule="none_failed",
        dag=dag,
    )

    task_collect_a01_stats = PythonOperator(
        task_id="collect_a01_stats",
        python_callable=collect_a01_stats,
        trigger_rule="none_failed",
        dag=dag,
    )

    task_collect_a44_stats = PythonOperator(
        task_id="collect_a44_stats",
        python_callable=collect_a44_stats,
        trigger_rule="none_failed",
        dag=dag,
    )

    task_collect_core_propensities_millitiles_stats = PythonOperator(
        task_id="collect_core_propensities_millitiles_stats",
        python_callable=collect_core_propensities_millitiles_stats,
        trigger_rule="none_failed",
        dag=dag,
    )

    task_collect_core_propensities_cutoffs_stats = PythonOperator(
        task_id="collect_core_propensities_cutoffs_stats",
        python_callable=collect_core_propensities_cutoffs_stats,
        trigger_rule="none_failed",
        dag=dag,
    )

    task_collect_standard_audiences_millitiles_stats = PythonOperator(
        task_id="collect_standard_audiences_millitiles_stats",
        python_callable=collect_standard_audiences_millitiles_stats,
        trigger_rule="none_failed",
        dag=dag,
    )

    task_collect_standard_audiences_cutoffs_stats = PythonOperator(
        task_id="collect_standard_audiences_cutoffs_stats",
        python_callable=collect_standard_audiences_cutoffs_stats,
        trigger_rule="none_failed",
        dag=dag,
    )

    task_collect_mc_hh_lookup_stats = PythonOperator(
        task_id="collect_mc_hh_lookup_stats",
        python_callable=collect_mc_hh_lookup_stats,
        trigger_rule="none_failed",
        dag=dag,
    )

    task_collect_20ci_new_lookup_stats = PythonOperator(
        task_id="collect_20ci_new_lookup_stats",
        python_callable=collect_20ci_new_lookup_stats,
        trigger_rule="none_failed",
        dag=dag,
    )

    # Send consolidated input stats email (after all stats collection)
    task_send_input_stats_email = PythonOperator(
        task_id="send_input_stats_email",
        python_callable=send_input_stats_email,
        trigger_rule="none_failed",
        dag=dag,
    )
    # Processing tasks (run sequentially - one after another)
    task_run_f15_processing = PythonOperator(
        task_id="run_f15_processing",
        python_callable=run_f15_processing,
        trigger_rule="none_failed",
        dag=dag,
    )

    task_run_f45_processing = PythonOperator(
        task_id="run_f45_processing",
        python_callable=run_f45_processing,
        trigger_rule="none_failed",
        dag=dag,
    )

    task_run_r45_processing = PythonOperator(
        task_id="run_r45_processing",
        python_callable=run_r45_processing,
        trigger_rule="none_failed",
        dag=dag,
    )

    task_run_auto_segments_processing = PythonOperator(
        task_id="run_auto_segments_processing",
        python_callable=run_auto_segments_processing,
        trigger_rule="none_failed",
        dag=dag,
    )

    task_run_boots_segments_processing = PythonOperator(
        task_id="run_boots_segments_processing",
        python_callable=run_boots_segments_processing,
        trigger_rule="none_failed",
        dag=dag,
    )

    task_run_propensities_processing = PythonOperator(
        task_id="run_propensities_processing",
        python_callable=run_propensities_processing,
        trigger_rule="none_failed",
        dag=dag,
    )

    task_run_yougov_processing = PythonOperator(
        task_id="run_yougov_processing",
        python_callable=run_yougov_processing,
        trigger_rule="none_failed",
        dag=dag,
    )

    task_run_20ci_processing = PythonOperator(
        task_id="run_20ci_processing",
        python_callable=run_20ci_processing,
        trigger_rule="none_failed",
        dag=dag,
    )

    task_run_f35_mosaic_processing = PythonOperator(
        task_id="run_f35_mosaic_processing",
        python_callable=run_f35_mosaic_processing,
        trigger_rule="none_failed",
        dag=dag,
    )

    # Main processing task
    task_run_main_processing = PythonOperator(
        task_id="run_main_processing",
        python_callable=run_main_processing,
        trigger_rule="none_failed",
        execution_timeout=timedelta(hours=10),  # Allow 10 hours for execution
        dag=dag,
    )

    # Rename output files task - converts Spark part files to single .txt files
    task_rename_output_files = PythonOperator(
        task_id="rename_output_files",
        python_callable=rename_output_files,
        trigger_rule="none_failed",
        dag=dag,
    )

    # Send completion email
    task_send_completion_email = PythonOperator(
        task_id="send_completion_email",
        python_callable=send_completion_email,
        trigger_rule="none_failed",
        dag=dag,
    )

    # Send failure email - triggers when any task fails
    task_send_failure_email = PythonOperator(
        task_id="send_failure_email",
        python_callable=send_failure_email,
        trigger_rule="one_failed",  # Triggers when any upstream task fails
        dag=dag,
    )

    # Finalize EMR application
    task_finalise = PythonOperator(
        task_id="finalise",
        python_callable=finalise,
        trigger_rule="all_done",
        dag=dag,
    )

    start >> task_create_arguments >> task_initialise >> check_inputs

    (
        check_inputs
        >> task_collect_f35_stats
        >> task_collect_f15_stats
        >> task_collect_f45_stats
        >> task_collect_r45_stats
        >> task_collect_yougov_stats
        >> task_collect_adhoc_suppression_stats
        >> task_collect_20ci_stats
        >> task_collect_f35_mosaic_stats
        >> task_collect_a40_stats
        >> task_collect_a67_stats
        >> task_collect_a16_stats
        >> task_collect_a08_stats
        >> task_collect_a01_stats
        >> task_collect_a44_stats
        >> task_collect_core_propensities_millitiles_stats
        >> task_collect_core_propensities_cutoffs_stats
        >> task_collect_standard_audiences_millitiles_stats
        >> task_collect_standard_audiences_cutoffs_stats
        >> task_collect_mc_hh_lookup_stats
        >> task_collect_20ci_new_lookup_stats
    )

    task_collect_20ci_new_lookup_stats >> task_send_input_stats_email

    (
        task_send_input_stats_email
        >> task_run_f15_processing
        >> task_run_f45_processing
        >> task_run_r45_processing
        >> task_run_auto_segments_processing
        >> task_run_boots_segments_processing
        >> task_run_propensities_processing
        >> task_run_yougov_processing
        >> task_run_20ci_processing
        >> task_run_f35_mosaic_processing
    )

    task_run_f35_mosaic_processing >> task_run_main_processing

    task_run_main_processing >> task_rename_output_files >> task_send_completion_email >> task_finalise

    check_inputs >> inputs_missing >> task_finalise

    task_create_arguments >> task_send_failure_email
    task_initialise >> task_send_failure_email
    check_inputs >> task_send_failure_email
    task_collect_f35_stats >> task_send_failure_email
    task_collect_f15_stats >> task_send_failure_email
    task_collect_f45_stats >> task_send_failure_email
    task_collect_r45_stats >> task_send_failure_email
    task_collect_yougov_stats >> task_send_failure_email
    task_collect_adhoc_suppression_stats >> task_send_failure_email
    task_collect_20ci_stats >> task_send_failure_email
    task_collect_f35_mosaic_stats >> task_send_failure_email
    task_collect_a40_stats >> task_send_failure_email
    task_collect_a67_stats >> task_send_failure_email
    task_collect_a16_stats >> task_send_failure_email
    task_collect_a08_stats >> task_send_failure_email
    task_collect_a01_stats >> task_send_failure_email
    task_collect_a44_stats >> task_send_failure_email
    task_collect_core_propensities_millitiles_stats >> task_send_failure_email
    task_collect_core_propensities_cutoffs_stats >> task_send_failure_email
    task_collect_standard_audiences_millitiles_stats >> task_send_failure_email
    task_collect_standard_audiences_cutoffs_stats >> task_send_failure_email
    task_collect_mc_hh_lookup_stats >> task_send_failure_email
    task_collect_20ci_new_lookup_stats >> task_send_failure_email
    task_send_input_stats_email >> task_send_failure_email
    task_run_f15_processing >> task_send_failure_email
    task_run_f45_processing >> task_send_failure_email
    task_run_r45_processing >> task_send_failure_email
    task_run_auto_segments_processing >> task_send_failure_email
    task_run_boots_segments_processing >> task_send_failure_email
    task_run_propensities_processing >> task_send_failure_email
    task_run_yougov_processing >> task_send_failure_email
    task_run_20ci_processing >> task_send_failure_email
    task_run_f35_mosaic_processing >> task_send_failure_email
    task_run_main_processing >> task_send_failure_email
    task_rename_output_files >> task_send_failure_email

    task_send_failure_email >> task_finalise
