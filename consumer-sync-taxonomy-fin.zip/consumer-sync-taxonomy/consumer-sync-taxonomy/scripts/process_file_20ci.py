# %%
from pyspark.sql import functions as F
from utils.spark_session import get_spark_session
from utils.records import check_record_retention

import logging
# %%
def process_data(spark=None):
    if spark is None:
        spark = get_spark_session('Process TwentyCI')

    logging.getLogger(__name__)

    new_lookup = spark.read.csv(r"hdfs:///user/unity/match2/digitaltaxonomy/input/UPRN_HH_Lookup.csv", header=True)
    deduped = new_lookup.groupBy("cb_key_household", "AddressBaseUPRN").count()

    twentyci = spark.read.csv(r"hdfs:///user/unity/match2/digitaltaxonomy/input/TwentyCI_Experian_Digital_*", sep="\t", header=True)
    twentyci = twentyci.select("UPRN", "Tenure", "Trigger")

    conditions_trigger = {
        "C000718": "PreMover",
        "C000719": "MoveMaker",
        "C000720": "MovePlanner",
        "C000721": "Mover",
        "C000722": "MoveNestBuilder",
        "C000723": "MoveHomemaker"
    }

    conditions_tenure = {
        "C000724": "Rental",
        "C000725": "Sale"
    }

    for col_name, val in conditions_trigger.items():
        twentyci = twentyci.withColumn(col_name, F.when(F.col("Trigger") == val, F.lit(val)).otherwise(F.lit("")))

    for col_name, val in conditions_tenure.items():
        twentyci = twentyci.withColumn(col_name, F.when(F.col("Tenure") == val, F.lit(val)).otherwise(F.lit("")))

    join = twentyci.join(deduped, twentyci["UPRN"] == deduped["AddressBaseUPRN"], "inner")

    aggs_trigger = [F.max(F.col(c)).alias(c) for c in [*conditions_trigger.keys(), *conditions_tenure.keys()]]
    df = join.groupBy("cb_key_household").agg(*aggs_trigger)

    check_record_retention(twentyci, df, 90, "TwentyCI Processing")

    logging.info(f'Processed TwentyCI')
    return df

# %%
if __name__ == '__main__':
    process_data()