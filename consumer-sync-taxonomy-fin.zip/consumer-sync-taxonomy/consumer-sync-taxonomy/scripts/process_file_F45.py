# %%
from pyspark.sql.functions import trim, regexp_replace

from utils.spark_session import get_spark_session
from utils.records import check_record_retention

import logging
# %%
def process_data(spark=None):
    if spark is None:
        spark = get_spark_session("Process F45")

    logging.getLogger(__name__)
    input_path = r"hdfs:///user/unity/match2/digitaltaxonomy/input/F45.current.cbaf_utility_1.csv"

    # Read file and parse PC field for subsequent join down the process
    df_pre = spark.read.option("header", "true").csv(input_path)
    df = df_pre.drop("mailable_postcode")
    df = df.withColumn('Pcode_To_Match', trim(regexp_replace(df['postcode_bs_standard_8bytes'], ' ', '')))

    check_record_retention(df_pre, df, 90, "F45 Processing")

    logging.info(f"Processed the F45 file")
    return df
# %%
if __name__ == "__main__":
    process_data()