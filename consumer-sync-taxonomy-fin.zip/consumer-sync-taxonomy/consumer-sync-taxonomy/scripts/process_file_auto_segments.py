# %%
import pandas as pd
import glob
import os

from pyspark.sql.functions import length, col, isnan, substring, concat_ws, collect_list, when

from utils.spark_session import get_spark_session
from utils.records import check_record_retention

import logging
# %%
def process_data(spark=None):
    if spark is None:
        spark = get_spark_session("Process Auto Segments")

    logging.getLogger(__name__)

    input_pattern = r"/data/digitaltaxonomy/base/Digital_Taxonomy_Master_Layout*.xlsx"
    matching_files = glob.glob(input_pattern)
    print(f"matching files: {matching_files}")

    if not matching_files:
        raise FileNotFoundError(f"No files found matching pattern: {input_pattern}")
    
    input_path = max(matching_files, key=os.path.getmtime)
    print(f"Using file: {input_path}")
    
    # Read excel and drop needless cols
    rules = pd.read_excel(f"file://{input_path}", sheet_name="Auto Segment Selections NEW")
    rules = rules.astype(str)

    columns_to_drop = ["Segment Group No.", "Group name", "Segment name"]
    df_pre = rules.drop(columns=columns_to_drop)

    # Convert to Spark df
    df_pre = spark.createDataFrame(df_pre)
    df_pre = df_pre.withColumnRenamed("C-number", "Segment")

    # Transpose
    key_cols = ["Segment"]
    to_excl = ["Segment", "S-Number"]
    data_cols = [col for col in df_pre.columns if col not in to_excl]

    for column in data_cols:
        auto_segments = df_pre.withColumn(column, df_pre[column].cast("STRING"))

    stack_expr = ", ".join([f"'{column}', `{column}`" for column in data_cols])
    auto_segments = auto_segments.selectExpr(*[f"`{key}`" for key in key_cols], f"stack({len(data_cols)}, {stack_expr}) as (Name, Value)")

    # Drop and rename columns
    auto_segments = auto_segments.withColumnRenamed("Value", "Mosaic").drop("Name")
    auto_segments = auto_segments.filter(length(auto_segments.Mosaic) <= 3)

    # Filter out nulls & NaN values
    auto_segments = auto_segments.filter(
        (col("Segment").isNotNull()) &
        (~isnan(col("Segment"))) &
        (col("Mosaic").isNotNull()) & 
        (~isnan(col("Mosaic"))))

    # Add and reformat columns
    auto_segments = auto_segments.withColumn("Value", col("Segment"))
    auto_segments = auto_segments.withColumn("Mosaic", substring(col('Mosaic'), 2, 2))

    # Group by official name
    auto_segments = auto_segments.groupBy("Mosaic").pivot("Segment").agg(concat_ws(", ", collect_list("Value")))

    # Replace any non empty value of the df with "Y"
    df = auto_segments.select([when(col(c).isNotNull() & (col(c) != ""), "Y").otherwise(col(c)).alias(c) if c != "Mosaic" else col(c) for c in auto_segments.columns])

    check_record_retention(df_pre, df, 20, "Auto Segments Processing")

    logging.info(f"Processed the Auto Segments file")
    return df
# %%
if __name__ == "__main__":
    process_data()