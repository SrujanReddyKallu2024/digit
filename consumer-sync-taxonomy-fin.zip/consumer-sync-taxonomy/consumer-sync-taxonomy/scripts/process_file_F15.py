# %%
from pyspark.sql.functions import col, lit
from pyspark.sql.types import IntegerType, StringType

from utils.spark_session import get_spark_session
from utils.tools import inner_join, left_anti_join
from utils.dynamic_flag import dynamic_flag
from utils.records import check_record_retention

from pathlib import Path

import logging

parent_dir = str(Path(__file__).resolve().parents[1])
# %%
def process_data(spark=None):
    if spark is None:
        spark = get_spark_session("Process F15")

    logging.getLogger(__name__)
    input_path = r"hdfs:///user/unity/match2/digitaltaxonomy/input/F15_*_ChannelView_ProspectView.csv"

    df_pre = spark.read.csv(input_path, sep="|", header=True)
    df = df_pre.filter(col("email_contributor_sources").contains("X20A") | col("email_contributor_sources").contains("X42A") | col("email_contributor_sources").contains("X55A") | 
                   col("email_contributor_sources").contains("X21A") | col("email_contributor_sources").contains("X70A") | col("email_contributor_sources").contains("X22A"))

    mailable_universe_config = rf"{parent_dir}/config/suppressions.json"

    # Initialize an empty DataFrame for unmatching_df
    unmatching_df = spark.createDataFrame([], df.schema).withColumn("Count", lit(None).cast(IntegerType()))
    unmatching_df = unmatching_df.withColumn("Stage", lit(None).cast(StringType()))

    df, final_unmatching = dynamic_flag(mailable_universe_config, df, unmatching_df, inner_join, left_anti_join) #TODO: final_unmatching now yet used anywhere, can be leveraged for reporting
    df = df.select("cb_key_db_person")
    df = df.withColumn("Prospect Email", lit("Y"))

    check_record_retention(df_pre, df, 90, "F15 Processing")

    logging.info(f"Processed the F15 file")
    return df

# %%
if __name__ == "__main__":
    process_data()