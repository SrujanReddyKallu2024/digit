# %%
from utils.spark_session import get_spark_session
from utils.records import check_record_retention

import logging
# %%
def process_data(spark=None):
    if spark is None:
        spark = get_spark_session("Process YouGov")

    logging.getLogger(__name__)
    input_path = r"hdfs:///user/unity/match2/digitaltaxonomy/input/YouGov*.csv"

    df_pre = spark.read.option("header", "true").csv(input_path)

    for col_name in df_pre.columns:
        df_pre = df_pre.withColumnRenamed(col_name, col_name.strip())

    df = df_pre.replace("N", "", subset=None)

    check_record_retention(df_pre, df, 90, "YouGov Processing")

    logging.info(f"Processed the YouGov file")
    return df

# %%
if __name__ == "__main__":
    process_data()