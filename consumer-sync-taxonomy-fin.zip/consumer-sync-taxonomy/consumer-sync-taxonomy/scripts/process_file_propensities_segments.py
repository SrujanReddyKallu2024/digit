# %%
import os
import json
import logging

from pyspark.sql.functions import lit, col, when, input_file_name

from pathlib import Path

parent_dir = str(Path(__file__).resolve().parents[1])

from utils.spark_session import get_spark_session
from utils.tools import inner_join, left_join
# %%
def process_cutoffs(data_file_path, cutoffs_file_path, old_prefix, delimiter, output_folder):
    spark = get_spark_session("Process Cutoffs")

    data_df = spark.read.option("header", 'true').option("delimiter", f"{delimiter}").csv(data_file_path)
    rules_df = spark.read.option("header", 'true').csv(cutoffs_file_path)
        
    rules_dict = {row[rules_df.columns[0]]: row[rules_df.columns[1]] for row in rules_df.collect()}

    for var, cutoff in rules_dict.items():
        if var in data_df.columns:
            new_var = var.replace(old_prefix, "FLAG")
            data_df = data_df.withColumn(new_var, when(col(var) >= cutoff, "Y").otherwise(""))

    data_df.write.mode("overwrite").option("header", True).parquet(output_folder)
# %%
def process_files(input_csv_path, flagged_parquet_path, old_prefix, output_path):
    # Initialize Spark session
    spark = get_spark_session("Process files")
    
    # Get current month for MC column
    current_month = spark.sql("SELECT date_format(current_date(), 'MM') as month").collect()[0].month
    mc_column_value = f"MC_{current_month}"
    
    # Read CSV
    df = spark.read.csv(input_csv_path, header=True)
    df = df.withColumn("FileName", input_file_name())
    df = df.withColumn("Calculation", lit(mc_column_value))
    
    # Melt dataframe
    melt_columns = [col for col in df.columns if col != "cb_Key_Household"]
    stack_expr = f"stack({len(melt_columns)}, " + ", ".join([f"'{col}', {col}" for col in melt_columns]) + ") as (Name, Value)"
    df_melted = df.selectExpr("cb_Key_Household", stack_expr)
    
    # Filter for current MC column
    df_pivoted = df_melted.withColumn("Current_MC", when(col("Name") == mc_column_value, col("Name")).otherwise(""))
    df_filtered = df_pivoted.filter(col("Current_MC").isNotNull() & (col("Current_MC") != "")).drop("Name")
    df_filtered = df_filtered.withColumnRenamed("Value", "MCMATCH")
    unique = df_filtered.dropDuplicates(["cb_Key_Household"])
    
    # Read flagged parquet
    flagged = spark.read.parquet(flagged_parquet_path)
    
    # Perform join
    join_condition = unique["MCMATCH"] == flagged["MC"]
    join = inner_join(unique, flagged, join_condition)

    join = join.drop(*[y for y in join.columns if y.startswith(old_prefix)])
    renamed_cols = [col(col_name).alias(col_name[:-len('_millitile')] if col_name.endswith('_millitile') else col_name) for col_name in join.columns]
    join = join.select(*renamed_cols)
    join = join.toDF(*[col.replace("FLAG", old_prefix) if col.startswith("FLAG") else col for col in join.columns])

    # Write output
    join.write.mode("overwrite").parquet(output_path)
# %%
def process_data(spark=None):
    spark = get_spark_session("Process Propensities file")

    logging.getLogger(__name__)

    mosaic = '7'

    json_file_path = os.path.join(f"{parent_dir}/config", 'propensities.json')

    with open(json_file_path) as f:
        params = json.load(f)

    for iteration in params['iterations']:
        data_file_path = iteration['data_file_path']
        cutoffs_file_path = iteration['cutoffs_file_path']
        old_prefix = iteration['old_prefix']
        output_folder = iteration['output_folder']
        delimiter = iteration['delimiter']

        process_cutoffs(data_file_path, cutoffs_file_path, old_prefix, delimiter, output_folder)

    for iteration in params['iterations2']:
        input_csv_path = iteration['input_csv_path']
        flagged_parquet_path = iteration['flagged_parquet_path']
        old_prefix = iteration['old_prefix']
        output_path = iteration['output_path']

        process_files(input_csv_path, flagged_parquet_path, old_prefix, output_path)

    df = spark.read.csv("hdfs:///user/unity/match2/digitaltaxonomy/input/F35_*_P60_consview.csv", sep="|", header=True)
    df = df.select("cb_key_db_person", "cb_key_household", "mailable_postcode")

    f45 = spark.read.option("header", "true").csv("hdfs:///user/unity/match2/digitaltaxonomy/input/F45.current.cbaf_utility_1.csv")
    f45 = f45.select("mailable_postcode", f"pc_mosaic_uk_{mosaic}_type")

    join_condition = f45["mailable_postcode"] == df["mailable_postcode"]

    join = inner_join(f45, df, join_condition)

    prop_millitiles = spark.read.parquet(r"hdfs:///user/unity/match2/digitaltaxonomy/interim/Propensities_millitiles_flagged_HHkey")
    cons_dynamics_millitiles = spark.read.parquet(r"hdfs:///user/unity/match2/digitaltaxonomy/interim/ConsumerDynamics_millitiles_flagged_HHkey")

    cols_to_drop = ['MCMATCH', 'Current_MC', 'MC']
    prop_millitiles = prop_millitiles.drop(*cols_to_drop).withColumnRenamed("cb_Key_Household", "cb_Key_Household_1")
    cons_dynamics_millitiles = cons_dynamics_millitiles.drop(*cols_to_drop).withColumnRenamed("cb_Key_Household", "cb_Key_Household_1")

    df = left_join(join, prop_millitiles, join["cb_key_household"] == prop_millitiles["cb_Key_Household_1"])
    df = df.drop("cb_Key_Household_1")
    
    df = inner_join(df, cons_dynamics_millitiles, df["cb_key_household"] == cons_dynamics_millitiles["cb_Key_Household_1"])
    df = df.drop("cb_Key_Household_1", "mailable_postcode", "cb_key_household")

    logging.info(f"Processed the Propensities and Segments files")
    return df

if __name__ == "__main__":
    process_data()