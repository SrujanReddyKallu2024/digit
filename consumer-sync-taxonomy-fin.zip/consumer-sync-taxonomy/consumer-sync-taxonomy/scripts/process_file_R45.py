# %%
from pyspark.sql.functions import trim, regexp_replace

from utils.spark_session import get_spark_session
from utils.records import check_record_retention

import logging
# %%
def process_data(spark=None):
    if spark is None:
        spark = get_spark_session("Process R45")

    logging.getLogger(__name__)
    input_path = r"hdfs:///user/unity/match2/digitaltaxonomy/input/R45.PostcodeDirectory.2024.csv"

    df_pre = spark.read.option("header", "true").csv(input_path)
    keep_columns = ["Postcode (Standard 8 bytes)", "Region Code", "Region Desc", "BBC TV Code", "Channel 4 Area"]
    df = df_pre.select(*keep_columns)
    df = df.withColumn('Pcode_To_Match', trim(regexp_replace(df['Postcode (Standard 8 bytes)'], ' ', '')))

    check_record_retention(df_pre, df, 90, "R45 Postcode Directory Processing")

    logging.info(f"Processed the R45 Postcode directory file")
    return df

# %%
if __name__ == "__main__":
    process_data()