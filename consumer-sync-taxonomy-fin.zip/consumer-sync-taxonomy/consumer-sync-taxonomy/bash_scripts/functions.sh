#!/bin/bash

source /etc/profile.d/hadoop.sh

# Function to check if a file with a given name pattern in a given folder is older than 15 minutes
# Returns 0 if the file is older than 15 minutes, 1 otherwise
# Arguments: 1. Input folder , 2. File pattern
is_file_ingestible() {
    local folder=$1
    local pattern=$2

    # Get the latest file matching the pattern
    local latest_file=$(find "$folder" -name "*${pattern}*" -type f -printf '%T@ %p\n' | sort -n | tail -1 | cut -d' ' -f2-)

    # Check if no files found or if the file has a .inprogress extension
    if [ -z "$latest_file" ]; then
        echo "No files found matching the pattern."
        return 1
    elif [[ "$latest_file" == *.inprogress ]]; then
        echo "The latest file has a .inprogress extension."
        return 1
    else
        echo "Latest file found: $latest_file"
    fi

    # Get the current time and the file's modification time
    local current_time=$(date +%s)
    local file_mod_time=$(stat -c %Y "$latest_file")

    # Calculate the time difference in minutes
    local time_diff=$(( (current_time - file_mod_time) / 60 ))

    # Check if the time difference is greater than 15 minutes
    if [ $time_diff -gt 15 ]; then        
        return 0
    else
        echo "The file is newer than 15 minutes."
        return 1
    fi
}


# Function to copy files to HDFS
# Arguments: 1. Source file path, 2. Destination HDFS path
copy_to_hdfs() {
    local src=$1
    local dest=$2
    hdfs dfs -copyFromLocal "$src" "$dest" && echo "Copied $src to HDFS: $dest"
}


# Moves files from source to destination either in local or HDFS. 
# Doesn't move if file doesn't exist at source or it already exists at destination
# Arguments:
#   1. Source type (locals or hdfs)
#   2. Filename/filepattern
#   3. Source folder
#   4. Destination folder
move_file(){
    if [[ $1 == "locals" ]]; then
        mkdir -p $4
        echo "searching for files matching pattern"
        INPUT_FILES=$3/*$2*
        echo "moving local file"
        IFS=$'\n'
        for i in $INPUT_FILES
        do
            file_name=$(basename $i)
            if test -f "$i"; then
                if test -f "$4/$file_name"; then
                    echo "$file_name already exists in $4, cannot move"
                else
                    mv "$i" "$4"
                    echo "moved $i into $4"
                fi
            else
                echo "$i doesn't exist"
            fi
        done
        unset IFS
    else
        hdfs dfs -mkdir -p $4
        echo "moving HDFS file"
        INPUT_FILES=$(hdfs dfs -ls $3 | grep -E $(echo $2 | sed 's/\*/\.\*/g') | awk '{print $8}')
        for i in $INPUT_FILES
        do
            file_name=$(basename $i)
            if hdfs dfs -test -e $i; then
                if hdfs dfs -test -e $4/$file_name; then
                    echo "$file_name already exists in $4, will not move"
                else
                    hdfs dfs -mv $i $4
                    echo "moved $i into $4"
                fi
            else
                echo "$i doesn't exist"
            fi
        done
    fi
}


# Function to check if a file exists in HDFS
# Arguments: 1. HDFS file path
check_hdfs_file_exists() {
    local hdfs_file=$1
    if hdfs dfs -test -e "$hdfs_file"; then
        echo "File exists in HDFS: $hdfs_file"
        return 0
    else
        echo "File does not exist in HDFS: $hdfs_file"
        return 1
    fi
}


# Function to check if a file exists in local filesystem
# Arguments: 1. Local file path
check_local_file_exists() {
    local dirname=$(dirname "$1")
    local filepattern=$(basename "$1")
    local local_file=$(find "$dirname" -name "$filepattern" -type f | head -n 1)
    if [ -n "$local_file" ]; then
        echo "File exists in local filesystem: $local_file"
        return 0
    else
        echo "File does not exist in local filesystem: $local_file"
        return 1
    fi
}


# Function to check if a file exists in hdfs then delete it
# Arguments: 1. HDFS file path
delete_hdfs_file() {
    local hdfs_file=$1
    if check_hdfs_file_exists "$hdfs_file"; then
        echo "Deleting file in HDFS: $hdfs_file"
        hdfs dfs -rm "$hdfs_file"
    else
        echo "File does not exist in HDFS: $hdfs_file"
    fi
}


# Check if a process is already running, Returns 1 if process is running, 0 if not
# Arguments: 1. Path of temp lock file
can_process_run(){
    if [ -f $1 ]
    then
        return 1  
    else
        return 0
    fi
}


# Function to replace spaces in a string with %20
# Arguments: 1. Input string
replace_spaces() {
    local input="$1"
    echo "$input" | sed 's/ /%20/g'
}



# Function to extract 20ci zip files in input folder
# Arguments: 1. Input folder path  
extract_twentyci_zip() {
    local input_folder=$1
    local temp_extract_dir="/home/unity/testing/twentyci_extract_$$"
    
    # Find the most recent 20ci zip file by date in filename (YYYYMMDD)
    local latest_zip=$(find "$input_folder" -name "TwentyCI_Experian_Digital_*.zip" -type f | sort -t_ -k4 -r | head -1)
    
    if [ -z "$latest_zip" ]; then
        echo "No 20ci zip files found in $input_folder"
        return  # Not an error, just no files to process
    fi
    
    echo "Processing latest 20ci zip file: $latest_zip"
    zip_file="$latest_zip"
    # Create temporary extraction directory
    mkdir -p "$temp_extract_dir"
    
    # Extract the zip file
    if unzip -q "$zip_file" -d "$temp_extract_dir"; then
        # Find the .txt file in extracted contents
        local txt_file=$(find "$temp_extract_dir" -name "*.txt" -type f | head -1)
        
        if [ -n "$txt_file" ]; then
            # Move the txt file to input folder with same base name
            local base_name=$(basename "$zip_file" .zip)
            local target_file="${input_folder}/${base_name}.txt"
            
            mv "$txt_file" "$target_file"
            echo "Extracted latest 20ci file: $target_file"
        fi
    fi
    
    # Clean up temp directory
    rm -rf "$temp_extract_dir"
}


# Check if file exists in HDFS, if so check its last modified time and if it's greater than provided days then return 1
check_hdfs_file_validity() {
    local hdfs_file=$1
    local max_age_days=$2

    if check_hdfs_file_exists "$hdfs_file"; then
        local file_mod_time_ms=$(hdfs dfs -stat %Y "$hdfs_file")
        if [ -z "$file_mod_time_ms" ]; then
            echo "Could not get modification time for $hdfs_file"
            return 1
        fi
        local file_mod_time=$((file_mod_time_ms / 1000))
        local current_time=$(date +%s)
        local time_diff=$(( (current_time - file_mod_time) / 86400 ))

        if [ "$max_age_days" == "adhoc" ]; then
            echo "Ad-hoc file detected, skipping age check."
            return 0
        elif [ $time_diff -gt $max_age_days ]; then
            echo "File is older than $max_age_days days."
            return 1
        else
            echo "File is not older than $max_age_days days. Can be used"
            return 0
        fi
    else
        echo "File does not exist in HDFS: $hdfs_file"
        return 1
    fi
}