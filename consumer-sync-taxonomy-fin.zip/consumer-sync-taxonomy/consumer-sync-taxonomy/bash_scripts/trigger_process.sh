#!/bin/bash

source conf.sh
source functions.sh

LOGS_PATH="${LOGS_DIR}/digital_tax_${RUNDATE}.log"

# Function to trigger ingestion of data files into HDFS
# Arguments: 1. Process name, 2. File pattern
trigger_hdfs_ingestion(){
    local proc_name=$1
    local file_pattern=$2
    local in_file_folder=$3
    latest_file=""

    if [ -n "$3" ]; then
        in_file_folder="$3"
    else
        in_file_folder="$LOCAL_STS_INPUT_PATH"
    fi

    ingest_hdfs_data() {
        if is_file_ingestible "$in_file_folder" "${file_pattern}"; then
            echo "Triggering ${proc_name} ingestion..."
            # get latest file if multiple files exist            
            latest_file=$(basename $(find "$in_file_folder" -type f -name "*${file_pattern}*" | grep -v "inprogress" | sort | tail -n 1))
            spark-submit $REPO_DIR/utils/get_stats.py -m $RUNDATE -ip $in_file_folder -fp "${latest_file}" -et $MAILLIST

            echo "Checking for existing files with pattern ${file_pattern} in HDFS..."
            existing_files=$(hdfs dfs -ls "$HDFS_INPUT_PATH/*${file_pattern}*" 2>/dev/null | awk '{print $8}' | xargs -I {} basename {})

            if check_hdfs_file_exists "$HDFS_INPUT_PATH/${latest_file}"; then
                echo "${latest_file} already exists in ${HDFS_INPUT_PATH}, skipping ingestion"
                return 2
            elif [ -n "$existing_files" ]; then
                echo "Found existing files matching pattern ${file_pattern}, moving to backup..."
                for existing_file in $existing_files; do
                    echo "Moving existing file to backup in HDFS: $HDFS_INPUT_PATH/${existing_file}"
                    move_file "hdfs" "${existing_file}" "$HDFS_INPUT_PATH" "$HDFS_BKP_PATH"                    
                done
            else
                echo "No existing files matching pattern ${file_pattern} found in HDFS."                
            fi

            copy_to_hdfs "${in_file_folder}/${latest_file}" "$HDFS_INPUT_PATH/${latest_file}"     
        else
            echo "${proc_name} ingestion not triggered."
            return 2
        fi
    }

    check_hdfs_status() {
        ingest_hdfs_data
        local status=$?
        if [ $status -eq 0 ]; then            
            echo "${proc_name} ingestion completed successfully."
            move_file locals "${file_pattern}" "$in_file_folder" "$DATA_FROM_STS_BACKUP" #this will move all files including multiple
        elif [ $status -eq 2 ]; then
            echo "${proc_name} ingestion not triggered."
        else
            echo "${proc_name} ingestion failed. check logs at ${LOGS_PATH}" | mailx -r "process_monitor@experian.com" -s "${proc_name} ingestion failed." $MAILLIST
            return 1
        fi
    }

    check_hdfs_status
    
}


# Function to trigger ingestion for files in local
# Arguments: 1. Process name, 2. File pattern
trigger_local_ingestion() {
    local proc_name=$1
    local file_pattern=$2
    local in_file_folder=$3
    latest_file=""

    if [ -n "$3" ]; then
        in_file_folder="$3"
    else
        in_file_folder="$LOCAL_STS_INPUT_PATH"
    fi

    check_local_data() {
        if is_file_ingestible "$in_file_folder" "${file_pattern}"; then
            echo "Triggering ${proc_name} ingestion..."
            # get latest file if multiple files exist            
            latest_file=$(basename $(find "$in_file_folder" -type f -name "*${file_pattern}*" | grep -v "inprogress" | sort | tail -n 1))
            # Check if the file already exists in local input path
            if [ -f "${LOCAL_INPUT_PATH}/${latest_file}" ]; then
                echo "File ${latest_file} already exists in ${LOCAL_INPUT_PATH}, will move existing file to backup"
                move_file locals "${file_pattern}" "$LOCAL_INPUT_PATH" "$DATA_FROM_STS_BACKUP"
            fi
            spark-submit $REPO_DIR/utils/get_stats.py -m $RUNDATE -ip $in_file_folder -fp "${latest_file}" -et $MAILLIST
        else
            echo "${proc_name} ingestion not triggered."
            return 2
        fi
    }

    check_local_status() {
        check_local_data
        local status=$?
        if [ $status -eq 0 ]; then
            echo "${proc_name} ingestion completed successfully."
            move_file locals "${latest_file}" "$LOCAL_STS_INPUT_PATH" "$LOCAL_INPUT_PATH"
            move_file locals "${file_pattern}" "$LOCAL_INPUT_PATH" "$DATA_FROM_STS_BACKUP" #this will move all files including multiple
        elif [ $status -eq 2 ]; then
            echo "${proc_name} ingestion not triggered."
        else
            echo "${proc_name} ingestion failed. check logs at ${LOGS_PATH}" | mailx -r "process_monitor@experian.com" -s "${proc_name} ingestion failed." $MAILLIST
            return 1
        fi
    }
    
    check_local_status

}


## Ingest data
run_ingestion_process() {
    echo "Starting ingestion process..."
    local failure_count=0

    increment_failure_count() {
        failure_count=$((failure_count + 1))
    }

    # Run HDFS ingestion
    trigger_hdfs_ingestion "F35" "F35_*_P60_consview.csv" || increment_failure_count
    trigger_hdfs_ingestion "A40" "A40_*_address.csv" || increment_failure_count
    trigger_hdfs_ingestion "A67" "A67_*_cbaf_address.csv" || increment_failure_count
    trigger_hdfs_ingestion "A16" "A16_*_cbaf_utility.csv" || increment_failure_count
    trigger_hdfs_ingestion "A08" "A08_*_absm_master.csv" || increment_failure_count
    trigger_hdfs_ingestion "A01" "A01_*_emsf_master.csv" || increment_failure_count
    trigger_hdfs_ingestion "A44" "A44_*_cbaf_address.csv" || increment_failure_count    
    trigger_hdfs_ingestion "Suppressions" "ADHOC_SUPPRESSION.csv" || increment_failure_count
    trigger_hdfs_ingestion "R45" "R45.PostcodeDirectory" || increment_failure_count ##The name would change once Ross confirms
    trigger_hdfs_ingestion "F45" "F45.current.cbaf_utility_1.csv" || increment_failure_count
    trigger_hdfs_ingestion "F15" "F15_*_ChannelView_ProspectView.csv" || increment_failure_count    
    trigger_hdfs_ingestion "YouGov" "YouGov audiences" || increment_failure_count
    trigger_hdfs_ingestion "Core_Propensities_Millitiles_UK" "Core_Propensities_Millitiles_UK20" $LOCAL_ADHOC_INPUT_PATH || increment_failure_count
    trigger_hdfs_ingestion "Core_Propensities_FlagCutoffs" "Core_Propensities_FlagCutoffs_20" $LOCAL_ADHOC_INPUT_PATH || increment_failure_count
    trigger_hdfs_ingestion "Standard_Audiences_Millitiles" "Standard_Audiences20*_millitiles" || increment_failure_count
    trigger_hdfs_ingestion "Standard_Audiences_Cutoffs" "Standard_Audiences20*_cutoffs" || increment_failure_count
    trigger_hdfs_ingestion "mc_hh_Lookup" "mc_hh_Lookup" || increment_failure_count
    trigger_hdfs_ingestion "mosaic8" "F35_MosaicSuite" || increment_failure_count
    
    # Extract and ingest 20ci data
    echo "Processing 20ci zip files..."
    extract_twentyci_zip "$LOCAL_STS_INPUT_PATH"
    trigger_hdfs_ingestion "TwentyCI" "TwentyCI_Experian_Digital_*.txt" || increment_failure_count
    
    # Ingest UPRN HH Lookup (required for 20ci processing, updated annually)
    trigger_hdfs_ingestion "UPRN_HH_Lookup" "UPRN_HH_Lookup*.csv" $LOCAL_ADHOC_INPUT_PATH || increment_failure_count

    # Run local ingestion
    trigger_local_ingestion "Boots_Model_Segments_lookup" "Boots_Model_Segments_lookup.xlsx" || increment_failure_count
    trigger_local_ingestion "Digital_Taxonomy_Master_Layout" "Digital_Taxonomy_Master_Layout_*.xlsx" || increment_failure_count    

    # Return 1 if there were any failures
    if [ $failure_count -gt 0 ]; then
        return 1
    fi

    echo "Ingestion process completed successfully."
    return 0
}


check_files_exist() {
    check_hdfs_file_validity "$HDFS_INPUT_PATH/F35_*_P60_consview.csv" 15 &&
    check_hdfs_file_validity "$HDFS_INPUT_PATH/A40_*_address.csv" "adhoc" &&
    check_hdfs_file_validity "$HDFS_INPUT_PATH/A67_*_cbaf_address.csv" 15 &&
    check_hdfs_file_validity "$HDFS_INPUT_PATH/A16_*_cbaf_utility.csv" 15 &&
    check_hdfs_file_validity "$HDFS_INPUT_PATH/A08_*_absm_master.csv" 15 &&
    check_hdfs_file_validity "$HDFS_INPUT_PATH/A01_*_emsf_master.csv" 15 &&
    check_hdfs_file_validity "$HDFS_INPUT_PATH/A44_*_cbaf_address.csv" 15 &&
    check_hdfs_file_validity "$HDFS_INPUT_PATH/ADHOC_SUPPRESSION.csv" "adhoc" &&
    check_hdfs_file_validity "$HDFS_INPUT_PATH/R45.PostcodeDirectory*.csv" 350 &&
    check_hdfs_file_validity "$HDFS_INPUT_PATH/F45.current.cbaf_utility_1.csv" "adhoc" &&
    check_hdfs_file_validity "$HDFS_INPUT_PATH/F15_*_ChannelView_ProspectView.csv" 15 &&
    check_hdfs_file_validity "$HDFS_INPUT_PATH/YouGov audiences*" "adhoc" &&
    check_hdfs_file_validity "$HDFS_INPUT_PATH/Core_Propensities_Millitiles_UK20*" "adhoc" &&
    check_hdfs_file_validity "$HDFS_INPUT_PATH/Core_Propensities_FlagCutoffs_20*" "adhoc" &&
    check_hdfs_file_validity "$HDFS_INPUT_PATH/Standard_Audiences20*_millitiles*" 350 &&
    check_hdfs_file_validity "$HDFS_INPUT_PATH/Standard_Audiences20*_cutoffs*" 350 &&
    check_hdfs_file_validity "$HDFS_INPUT_PATH/mc_hh_Lookup*" 15 &&
    check_hdfs_file_validity "$HDFS_INPUT_PATH/F35_MosaicSuite*" "adhoc" &&
    check_hdfs_file_validity "$HDFS_INPUT_PATH/TwentyCI_Experian_Digital_*.txt" "adhoc" &&
    check_hdfs_file_validity "$HDFS_INPUT_PATH/UPRN_HH_Lookup*.csv" "adhoc" &&
    check_local_file_exists "$LOCAL_INPUT_PATH/Boots_Model_Segments_lookup.xlsx" &&
    check_local_file_exists "$LOCAL_INPUT_PATH/Digital_Taxonomy_Master_Layout_*.xlsx"
    if [ $? -ne 0 ]; then
        echo "Alert: One or more required files are missing. Please check the logs at ${LOGS_PATH}"
        return 2
    fi
    echo "All required files are present."
}


convert_file_format(){
    local in_dir=$1
    local final_file=$2
    
    {
        hdfs dfs -cat "${in_dir}/part-00000*" | head -n1 | tr -d '"'
        hdfs dfs -cat "${in_dir}/*" | \
        tr -d '"' | \
        awk 'NR==1{header=$0; next} $0!=header'
    } > "$final_file"
}

run_trigger(){
    if can_process_run $TAX_LOCK_FILE 
    then
        touch $TAX_LOCK_FILE && echo "created taxonomy lock file"
        hdfs dfs -mkdir -p "$HDFS_INPUT_PATH"
        hdfs dfs -mkdir -p "$HDFS_BKP_PATH"
        hdfs dfs -mkdir -p "$HDFS_OUTPUT_PATH"
        hdfs dfs -mkdir -p "$HDFS_INTERIM_PATH"
        mkdir -p "$LOCAL_INPUT_PATH"
        mkdir -p "$LOCAL_ADHOC_INPUT_PATH"
        mkdir -p "$LOCAL_TEMP_PATH"
        mkdir -p "$LOCAL_CD_OUT_PATH"
        run_ingestion_process
        if [ $? -ne 0 ]; then
            echo "Alert: ingestion of one or more files failed, please check logs at ${LOGS_PATH}"
            return 1
        fi
        check_files_exist
        if [ $? -ne 0 ]; then
            echo "Alert: Required files are missing, please check logs at ${LOGS_PATH}"
            rm $TAX_LOCK_FILE && echo "removed taxonomy lock file"
            return 2
        fi
        spark-submit --master yarn --queue $QUEUE1 $REPO_DIR/main.py
        if [ $? -ne 0 ]; then
            echo "Alert: main.py process failed, please check logs at ${LOGS_PATH}" | mailx -r "emsactivate@experian.com" -s "Digital Taxonomy process failed." $MAILLIST
            return 1
        fi
        convert_file_format "${HDFS_INTERIM_PATH}/pyspark_output" "${LOCAL_TEMP_PATH}/${DT_DATE_FORMAT}_Digital_taxonomy.txt"
        if [ $? -ne 0 ]; then
            echo "Alert: digital taxonomy file formatting failed, please check logs at ${LOGS_PATH}" | mailx -r "emsactivate@experian.com" -s "Digital Taxonomy process failed." $MAILLIST
            return 1
        fi
        cp "${LOCAL_TEMP_PATH}/${DT_DATE_FORMAT}_Digital_taxonomy.txt" $LOCAL_INTERNAL_TAX_PATH && echo "copied file to internal taxonomy path"
        cp "${LOCAL_TEMP_PATH}/${DT_DATE_FORMAT}_Digital_taxonomy.txt" $LOCAL_CD_OUT_PATH && echo "copied file to cd team outpath"
        sleep 300 ##added delay to allow time to copy files
        chown unity:stsgrp "$LOCAL_CD_OUT_PATH/*Digital_Taxonomy.txt"
        chmod 774 "$LOCAL_CD_OUT_PATH/*Digital_Taxonomy.txt"
        rm $TAX_LOCK_FILE && echo "removed taxonomy lock file"
    else
        echo "digital taxonomy process is already running on $RUNDATE"
    fi
}

run_trigger  2>&1 | grep -v 'INFO\|_JAVA_OPTIONS' | awk '{ print strftime("%Y-%m-%d %H:%M:%S"), $0; fflush(); }' >> "$LOGS_DIR/digital_tax_${RUNDATE}.log"