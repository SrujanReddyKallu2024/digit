import json

from pyspark.sql.functions import monotonically_increasing_id, col, lit, DataFrame

from utils.spark_session import get_spark_session

def dynamic_flag(config_path: str, matching_df: DataFrame, unmatching_df: DataFrame, inner_join, left_anti_join):
    spark = get_spark_session("Dynamic Flag")
    
    # Load the config from the JSON file
    with open(config_path, 'r') as f:
        config = json.load(f)

    # Initialize empty df to store cumulative results
    unmatching_union = spark.createDataFrame([], unmatching_df.schema)  # Stores unmatching rows for later use

    # Loop through each file configuration
    for file_config in config['files']:
        file_name = file_config['file_name']
        join_column = file_config['join_column']
        stage_name = file_config['stage_name']

        # Read the lookup DataFrame based on the file (adjust as needed)
        lookup_df = spark.read.csv(f"{file_name}", sep="|", header=True)  # Adjust to the actual file format/reading method

        # Preprocessing before filtering (occurs in each iteration)
        matching_df = matching_df.withColumn("NonRepeatableInputField", lit(""))
        matching_df = matching_df.withColumn("DJ_RecordID", monotonically_increasing_id())

        # Split matching and unmatching
        matching_df = matching_df.filter((col(f"{join_column}") != "") & (col(f"{join_column}") != "0"))
        unmatching_df = matching_df.filter((col(f"{join_column}") == "") | (col(f"{join_column}") == "0"))
        unmatching_df = unmatching_df.withColumn("Count", lit(0))

        # Rename the join column in the lookup DataFrame
        lookup_df = lookup_df.withColumnRenamed(join_column, f"{join_column}_1")

        # If count of matching_df is greater than or equal to 4 million, select distinct
        if matching_df.count() >= 4000000:
            lookup_df = lookup_df.select(f"{join_column}_1").distinct()

        # Perform the inner join
        joined_df = inner_join(matching_df, lookup_df, join_condition=matching_df[join_column] == lookup_df[f"{join_column}_1"])
        joined_df = joined_df.withColumn("Count", lit(1))
        joined_df = joined_df.drop(f"{join_column}_1")

        # Perform the anti join
        anti_joined_df = left_anti_join(matching_df, lookup_df, join_condition=matching_df[join_column] == lookup_df[f"{join_column}_1"])
        anti_joined_df = anti_joined_df.withColumn("Count", lit(0))
        anti_joined_df = anti_joined_df.drop(f"{join_column}_1")

        # Union the results
        union = joined_df.union(anti_joined_df).union(unmatching_df)
        union = union.drop("NonRepeatableInputField", "DJ_RecordID")

        # Split into matching and unmatching
        new_matching_union = union.filter(col("Count") == lit(0)).drop("Count")  # Drop column from matching_union
        new_unmatching_union = union.filter(col("Count") != lit(0))  # Stored for later use
        new_unmatching_union = new_unmatching_union.withColumn("Stage", lit(stage_name))

        # Commented print statement for the matching and unmatching from any iteration (optional)
        #print(f"Iteration for {file_name} with stage: {stage_name}: Matching Rows: {new_matching_union.count()}, Unmatching Rows: {new_unmatching_union.count()}")

        # Collect all unmatching results for later use
        unmatching_union = unmatching_union.union(new_unmatching_union)

        # Update matching_df for the next iteration
        matching_df = new_matching_union  # Continue with the matching subset

    return matching_df, unmatching_union