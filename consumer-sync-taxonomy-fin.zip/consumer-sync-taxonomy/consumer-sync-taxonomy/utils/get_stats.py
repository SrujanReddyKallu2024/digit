import os
import sys
import functools
from datetime import datetime, timedelta
import pandas as pd
from pathlib import Path

script_dir = str(Path(os.path.dirname(__file__)).resolve())
parent_dir = str(Path(os.path.join(os.path.dirname(__file__), '..')).resolve())

import functions as func

LOGPATH = f"{parent_dir}/logs"
EMAIL_TO = "emsactivatealerts@experian.com" #set email to send stats to
STATS_PATH = "/user/unity/match2/stats"
MASK = datetime.now().strftime("%Y-%m-%d")  # default mask to today's date



def get_stats(mask, week_start_date, input_path, df, islocal):
    """
    gets the stats based on the ingested files
    returns pandas dataframe
    """    
    if islocal == "True":
        file_download_datetime = datetime.fromtimestamp(os.path.getctime(input_path)).strftime("%Y-%m-%d %H:%M:%S")
    else:
        file_download_datetime = func.get_creation_date(input_path)
    stats_dict = {
        "date":mask,
        "week_start_date": week_start_date,
        "file_name": os.path.split(input_path)[-1],
        "file_creation_time" : file_download_datetime,
        "file_size" : func.get_size(input_path, islocal),
        "record_counts" : df.count(),
    }
    return pd.DataFrame([stats_dict])


def logic_main(ctx, logger, mask, input_folder, file_pattern, stats_path, islocal, email_to):
    logger.info(f"running stats process for {mask}")
    mask_date = datetime.strptime(mask, "%Y-%m-%d").date()
    week_start_date = (mask_date - timedelta(days=mask_date.weekday())).strftime("%Y-%m-%d") if mask_date.weekday()!=0 else mask

    valid_files = func.get_valid_files(input_folder, file_pattern, islocal)    
    logger.info(f"number of valid files found for generating stats: {len(valid_files)}")
    
    # #for to_id5 files the week start date would be the succeeding week start date
    # if file_pattern and (file_pattern in ["to_id5__"]):
    #     week_start_date = (datetime.strptime(week_start_date, "%Y-%m-%d").date() + timedelta(days=7)).strftime("%Y-%m-%d")  
    
    stats_output = f"{stats_path}/{week_start_date}/pipeline_stats__{week_start_date}.csv"

    alertval = 0
    if len(valid_files)!=0:
        if sys.platform[:3] != "win":
            stat_output_flag = False
        else:
            stat_output_flag = islocal
        previous_stats_check = func.check_path_exists(stats_output, stat_output_flag)
        logger.info(f"previous stats file for the same data exists: {previous_stats_check}")

        dfs = []
        if previous_stats_check:
            previous_stats =  func.check_and_read_file(ctx, stats_output, file_ext="csv")
            logger.info(f"read previous stats file from {stats_output}")
            dfs.append(previous_stats)
            
        for i in valid_files:
            file_ext = os.path.split(i)[-1].split(".")[-1]            
            if sys.platform[:3] != "win" and islocal=="True":
                filepath = "file://" + i
            else:
                filepath = i
            
            input_df = func.check_and_read_file(ctx, filepath, file_ext, delim="|")
            logger.info(f"read {file_ext} file")

            if input_df:
                stats_df = ctx.createDataFrame(get_stats(mask, week_start_date, i, input_df, islocal))
                logger.info(f"created stats data for {i}")
                dfs.append(stats_df)
            else:                
                logger.error(f"couldn't generate stats as {i} is not valid")                    
                alertval = 1
        
        if len(dfs)!=0:
            initial_stats = functools.reduce(DataFrame.union, dfs).cache()
            logger.info(f"created stats data for all files in {input_folder}, record_count: {initial_stats.count()}")
            
            final_stats = initial_stats.dropDuplicates(subset=["week_start_date", "file_name", "record_counts"])
            logger.info("removed duplicate stats")

            final_stats = final_stats.orderBy("date",ascending=False)
            logger.info("ordered stats such that latest stats appear first")

            if previous_stats_check:
                same_stats_flag = func.check_dfs_equal(previous_stats, final_stats)
                logger.info(f"previous stats and today's stats are the same: {same_stats_flag}")
            else:
                same_stats_flag = False                
            
            if same_stats_flag==False:
                final_stats.repartition(1).write.csv(stats_output, header=True, mode="overwrite")
                logger.info("all stats data written out")
                
                func.send_email(email_to, final_stats.toPandas().to_html(index=False), "Stats generated successfully", mask)
                logger.info("sent stats via email")
            else:
                logger.info("didn't write out stats as they were exactly the same")
        else:
            logger.error("no previous stats found and no stats generated even though valid files exist")
            alertval = 2            
        
        #alerting emails
        if alertval == 1:
            func.send_email(email_to, False, "Couldn't generate stats for an invalid file found in ingest folder", mask)
        elif alertval == 2:
            func.send_email(email_to, False, "No previous stats found and no stats generated even though valid files exist", mask)
        else:
            logger.info("no alerts raised")
    else:
        logger.info("no valid files found for generating stats")


if __name__ == "__main__":
    from pyspark.sql import SparkSession, DataFrame    
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument(
        "-ip", "--input_folder", type=str,
        help="input path in local"
    )
    parser.add_argument(
        "-sp", "--stats_path", type=str,
        help="stats output folder path", default=STATS_PATH
    )
    parser.add_argument(
        "-m", "--mask", type=str,
        help="date for which process is run", default=MASK
    )
    parser.add_argument(
        "-l", "--islocal", type=str,
        help="flag to check if input file is in local fs or hdfs", default="True"
    )
    parser.add_argument(
        "-fp", "--file_pattern", type=str,
        help="string to search for in filenames within the input folder", default=False
    )
    parser.add_argument(
        "-et", "--email_to", type=str,
        help="email recepients", default=EMAIL_TO
    )
    args = parser.parse_args()

    # setting a variable to the name of the script
    if "__file__" not in dir():
        name = "debug"
    else:
        name = os.path.basename(__file__)

    logger = func.LogConfig(
        "{path}/log-{name}-{mask}.log".format(
            path=LOGPATH, name=name, mask=args.mask
        )
    ).generate_logger(name)
    
    spark = SparkSession.builder.appName(name).getOrCreate()
    #process starts here
    logic_main(spark, logger, args.mask, args.input_folder, args.file_pattern, args.stats_path, args.islocal, args.email_to)
    spark.stop()
    

    